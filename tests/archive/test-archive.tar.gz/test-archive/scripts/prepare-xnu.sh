#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUNDLE_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)

XNU_URL=${XNU_URL:-https://github.com/apple-oss-distributions/xnu.git}
XNU_REF=${XNU_REF:-f6217f891ac0bb64f3d375211650a4c1ff8ca1ea}
XNU_SRC=${XNU_SRC:-"$BUNDLE_ROOT/work/xnu"}

if [ -d "$XNU_SRC/iokit/DriverKit" ]; then
	printf '%s\n' "$XNU_SRC"
	exit 0
fi

mkdir -p "$(dirname -- "$XNU_SRC")"
git clone "$XNU_URL" "$XNU_SRC"
git -C "$XNU_SRC" checkout "$XNU_REF"

printf '%s\n' "$XNU_SRC"
