#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUNDLE_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
LOCAL_DIR=${LOCAL_DIR:-"$BUNDLE_ROOT/xnu-driverkit/generated-local-output/DriverKit"}
XCODE_DIR=${XCODE_DIR:-"$BUNDLE_ROOT/xnu-driverkit/xcode-output/DriverKit"}
DIFF_DIR=${DIFF_DIR:-"$BUNDLE_ROOT/xnu-driverkit/diffs"}

mkdir -p "$DIFF_DIR"
checked=0
failed=0

while IFS= read -r name; do
	for ext in h iig.cpp edits; do
		checked=$((checked + 1))
		if diff -u "$XCODE_DIR/$name.$ext" "$LOCAL_DIR/$name.$ext" > "$DIFF_DIR/$name.$ext.diff"; then
			rm -f "$DIFF_DIR/$name.$ext.diff"
		else
			failed=$((failed + 1))
			printf 'DIFF %s.%s\n' "$name" "$ext"
		fi
	done
done < "$BUNDLE_ROOT/xnu-driverkit/manifests/cases.list"

printf 'CHECKED=%s FAIL=%s\n' "$checked" "$failed"
test "$failed" -eq 0
