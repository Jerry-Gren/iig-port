#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUNDLE_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
IIG_TOOL=${IIG_TOOL:-}
OUT_DIR=${OUT_DIR:-"$BUNDLE_ROOT/behavior/generated-local-output/DriverKit"}

if [ -z "$IIG_TOOL" ] || [ ! -x "$IIG_TOOL" ]; then
	printf 'set IIG_TOOL to a compiled iig executable\n' >&2
	exit 1
fi

XNU_SRC=${XNU_SRC:-$("$SCRIPT_DIR/prepare-xnu.sh")}
mkdir -p "$OUT_DIR"

while IFS= read -r name; do
	input=$BUNDLE_ROOT/behavior/cases/DriverKit/$name.iig
	"$IIG_TOOL" \
		--def "$input" \
		--header "$OUT_DIR/$name.h" \
		--impl "$OUT_DIR/$name.iig.cpp" \
		--edits "$OUT_DIR/$name.edits" \
		--framework-name DriverKit \
		-- \
		-I"$BUNDLE_ROOT/support/include" \
		-I"$BUNDLE_ROOT/behavior/cases" \
		-I"$BUNDLE_ROOT/behavior/include" \
		-I"$XNU_SRC/iokit" \
		-I"$XNU_SRC/osfmk" \
		-I"$XNU_SRC/bsd" \
		-I"$XNU_SRC/libkern" \
		-I"$XNU_SRC/EXTERNAL_HEADERS" \
		-x c++ \
		-std=gnu++2b \
		-fblocks \
		-D__IIG=1 \
		-DDRIVERKIT_PRIVATE=1 \
		-DPRIVATE_WIFI_ONLY=1 \
		-DXNU_PLATFORM_MacOSX=1
done < "$BUNDLE_ROOT/behavior/manifests/cases.list"

printf 'generated behavior output: %s\n' "$OUT_DIR"
