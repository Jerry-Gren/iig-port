# IIG Standalone Verification

Date: 2026-08-12

This bundle verifies a compiled IIG-compatible executable without depending on
a surrounding build tree. Set `IIG_TOOL` to the executable under test. The
scripts clone XNU automatically, or reuse an existing checkout when `XNU_SRC`
is set.

## Contents

- `behavior/cases/DriverKit/`: standalone behavior inputs in the default
  passing set.
- `behavior/xcode-output/DriverKit/`: Xcode iig reference output for the
  default behavior set.
- `behavior/manifests/cases.list`: exact default behavior set.
- `behavior/include/DriverKit/`: helper `.iig` files used by behavior inputs.
- `behavior/pending/`: complete input/reference-output pairs that currently
  expose known local differences and are not part of the default passing set.
- `xnu-driverkit/manifests/cases.list`: the 18 XNU DriverKit `.iig` inputs
  exercised from a cloned XNU checkout.
- `xnu-driverkit/xcode-output/DriverKit/`: Xcode iig `.h`, `.iig.cpp`, and
  `.edits` reference output for those 18 XNU DriverKit inputs.
- `support/include/`: small host parsing headers used before the XNU include
  paths.

## Run

```sh
IIG_TOOL=/path/to/iig scripts/generate-behavior-local.sh
scripts/compare-behavior-output.sh

IIG_TOOL=/path/to/iig scripts/generate-xnu-driverkit-local.sh
scripts/compare-xnu-driverkit-output.sh
```

To avoid cloning XNU, point `XNU_SRC` at an existing checkout:

```sh
IIG_TOOL=/path/to/iig XNU_SRC=/path/to/xnu scripts/generate-behavior-local.sh
IIG_TOOL=/path/to/iig XNU_SRC=/path/to/xnu scripts/generate-xnu-driverkit-local.sh
```

Default XNU source:

```text
https://github.com/apple-oss-distributions/xnu.git
```

Default XNU revision:

```text
f6217f891ac0bb64f3d375211650a4c1ff8ca1ea
```
