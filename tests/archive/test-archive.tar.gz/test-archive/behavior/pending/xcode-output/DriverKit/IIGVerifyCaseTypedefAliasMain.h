/* iig(DriverKit-440) generated from IIGVerifyCaseTypedefAliasMain.iig */

/* IIGVerifyCaseTypedefAliasMain.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */
#include <DriverKit/IIGVerifyTypedefAliasMiddle.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASETYPEDEFALIASMAIN_H
#define _DRIVERKIT_IIGVerifyCASETYPEDEFALIASMAIN_H

typedef IIGVerifyCaseTypedefAliasMiddleWords IIGVerifyCaseTypedefAliasMainWords;

/* source class IIGVerifyCaseTypedefAliasMain IIGVerifyCaseTypedefAliasMain.iig:9-18 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseTypedefAliasMain : public OSObject
{
public:
	virtual kern_return_t
	AliasChainInput(const IIGVerifyCaseTypedefAliasMainWords words,
	    uint32_t wordsCount) LOCAL;

	virtual kern_return_t
	AliasChainOutput(uint32_t wordsCount,
	    IIGVerifyCaseTypedefAliasMainWords words) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseTypedefAliasMain IIGVerifyCaseTypedefAliasMain.iig:9-18 */

#define IIGVerifyCaseTypedefAliasMain_AliasChainInput_ID            0x9dba654c34aac433ULL
#define IIGVerifyCaseTypedefAliasMain_AliasChainOutput_ID            0x866d267ca6d7df85ULL

#define IIGVerifyCaseTypedefAliasMain_AliasChainInput_Args \
        const unsigned short * words, \
        uint32_t wordsCount

#define IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Args \
        uint32_t wordsCount, \
        unsigned short * words

#define IIGVerifyCaseTypedefAliasMain_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseTypedefAliasMain * self, const IORPC rpc);\
\
    kern_return_t\
    AliasChainInput(\
        const unsigned short * words,\
        uint32_t wordsCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasChainOutput(\
        uint32_t wordsCount,\
        unsigned short * words,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    AliasChainInput_Impl(IIGVerifyCaseTypedefAliasMain_AliasChainInput_Args);\
\
    kern_return_t\
    AliasChainOutput_Impl(IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*AliasChainInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefAliasMain_AliasChainInput_Args);\
    static kern_return_t\
    AliasChainInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasChainInput_Handler func);\
\
    typedef kern_return_t (*AliasChainOutput_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Args);\
    static kern_return_t\
    AliasChainOutput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasChainOutput_Handler func);\
\


#define IIGVerifyCaseTypedefAliasMain_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseTypedefAliasMain_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseTypedefAliasMainMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseTypedefAliasMain_Class;

class IIGVerifyCaseTypedefAliasMainMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseTypedefAliasMainInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseTypedefAliasMain_IVars;
struct IIGVerifyCaseTypedefAliasMain_LocalIVars;

class IIGVerifyCaseTypedefAliasMain : public OSObject, public IIGVerifyCaseTypedefAliasMainInterface
{
#if !KERNEL
    friend class IIGVerifyCaseTypedefAliasMainMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseTypedefAliasMain_DECLARE_IVARS
IIGVerifyCaseTypedefAliasMain_DECLARE_IVARS
#else /* IIGVerifyCaseTypedefAliasMain_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseTypedefAliasMain_IVars * ivars;
        IIGVerifyCaseTypedefAliasMain_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseTypedefAliasMain_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseTypedefAliasMainMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseTypedefAliasMain_Methods
    IIGVerifyCaseTypedefAliasMain_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseTypedefAliasMain.iig:20- */

#endif /* _DRIVERKIT_IIGVerifyCASETYPEDEFALIASMAIN_H */
