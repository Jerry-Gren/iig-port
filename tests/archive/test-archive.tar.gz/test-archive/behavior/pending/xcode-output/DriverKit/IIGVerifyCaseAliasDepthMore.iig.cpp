/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseAliasDepthMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseAliasDepthMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseAliasDepthMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[2];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Invocation;
struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned short *  values;
#if !defined(__LP64__)
    uint32_t __valuesPad;
#endif /* !defined(__LP64__) */
    unsigned short __values[5];
    uint32_t  valuesCount;
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Invocation;
struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[5];
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Invocation;
struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  valuesCount;
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  valuesCount;
    unsigned short *  values;
#if !defined(__LP64__)
    uint32_t __valuesPad;
#endif /* !defined(__LP64__) */
    unsigned short __values[7];
};
#pragma pack(4)
struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseAliasDepthMore_QueueNames  ""

#define IIGVerifyCaseAliasDepthMore_MethodNames  ""

#define IIGVerifyCaseAliasDepthMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseAliasDepthMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseAliasDepthMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseAliasDepthMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t
OSClassDescription_IIGVerifyCaseAliasDepthMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseAliasDepthMore_t),
        .name                    = "IIGVerifyCaseAliasDepthMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseAliasDepthMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseAliasDepthMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseAliasDepthMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAliasDepthMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseAliasDepthMore_QueueNames,
    .methodNames     = IIGVerifyCaseAliasDepthMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseAliasDepthMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseAliasDepthMoreMetaClass;

static kern_return_t
IIGVerifyCaseAliasDepthMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseAliasDepthMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseAliasDepthMore.base,
    .metaPointer       = &gIIGVerifyCaseAliasDepthMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseAliasDepthMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseAliasDepthMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseAliasDepthMore_Declaration;
const void * const
gIIGVerifyCaseAliasDepthMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseAliasDepthMore_Class;

static kern_return_t
IIGVerifyCaseAliasDepthMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseAliasDepthMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseAliasDepthMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseAliasDepthMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseAliasDepthMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::_Dispatch(IIGVerifyCaseAliasDepthMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseAliasDepthMore_InlineMacroAlias_ID:
        {
            ret = IIGVerifyCaseAliasDepthMore::InlineMacroAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseAliasDepthMore::InlineMacroAlias_Handler, *self, &IIGVerifyCaseAliasDepthMore::InlineMacroAlias_Impl));
            break;
        }
        case IIGVerifyCaseAliasDepthMore_InlineEnumAlias_ID:
        {
            ret = IIGVerifyCaseAliasDepthMore::InlineEnumAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseAliasDepthMore::InlineEnumAlias_Handler, *self, &IIGVerifyCaseAliasDepthMore::InlineEnumAlias_Impl));
            break;
        }
        case IIGVerifyCaseAliasDepthMore_OutputLocalAlias_ID:
        {
            ret = IIGVerifyCaseAliasDepthMore::OutputLocalAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseAliasDepthMore::OutputLocalAlias_Handler, *self, &IIGVerifyCaseAliasDepthMore::OutputLocalAlias_Impl));
            break;
        }
        case IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_ID:
        {
            ret = IIGVerifyCaseAliasDepthMore::OutputIncludedAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseAliasDepthMore::OutputIncludedAlias_Handler, *self, &IIGVerifyCaseAliasDepthMore::OutputIncludedAlias_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseAliasDepthMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseAliasDepthMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::InlineMacroAlias(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_InlineMacroAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseAliasDepthMore_InlineMacroAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::InlineEnumAlias(
        const unsigned short * values,
        uint32_t valuesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_InlineEnumAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.values = NULL;

    if (valuesCount > (sizeof(msg->content.__values) / sizeof(msg->content.__values[0]))) return kIOReturnOverrun;
    bcopy(values, &msg->content.__values[0], valuesCount * sizeof(msg->content.__values[0]));

    msg->content.valuesCount = valuesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseAliasDepthMore_InlineEnumAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::OutputLocalAlias(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_OutputLocalAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseAliasDepthMore_OutputLocalAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::OutputIncludedAlias(
        uint32_t valuesCount,
        unsigned short * values,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.valuesCount = valuesCount;

    if (*valuesCount > (sizeof(rpl->content.__values) / sizeof(rpl->content.__values[0]))) return kIOReturnOverrun;
    msg->content.valuesCount = *valuesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.valuesCount < *valuesCount) *valuesCount = rpl->content.valuesCount;
        bcopy(&rpl->content.__values[0], values, *valuesCount * sizeof(rpl->content.__values[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::InlineMacroAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineMacroAlias_Handler func)
{
    IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_InlineMacroAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::InlineEnumAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineEnumAlias_Handler func)
{
    IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t valuesCount = (sizeof(MESSAGE_CONTENT(__values)) / sizeof(MESSAGE_CONTENT(__values[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(valuesCount) >= 0 && valuesCount > MESSAGE_CONTENT(valuesCount)) valuesCount = MESSAGE_CONTENT(valuesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__values[0]),
        valuesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_InlineEnumAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::OutputLocalAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputLocalAlias_Handler func)
{
    IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_OutputLocalAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseAliasDepthMore::OutputIncludedAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputIncludedAlias_Handler func)
{
    IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t valuesCount = (sizeof(MESSAGE_CONTENT(__values)) / sizeof(MESSAGE_CONTENT(__values[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(valuesCount) >= 0 && valuesCount > MESSAGE_CONTENT(valuesCount)) valuesCount = MESSAGE_CONTENT(valuesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        valuesCount,
        &reply->content.__values[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Rpl_ObjRefs;

    return (ret);
}



