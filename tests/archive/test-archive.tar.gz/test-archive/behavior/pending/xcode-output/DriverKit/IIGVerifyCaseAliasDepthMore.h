/* iig(DriverKit-440) generated from IIGVerifyCaseAliasDepthMore.iig */

/* IIGVerifyCaseAliasDepthMore.iig:1-17 */
#include <DriverKit/OSObject.h>  /* .iig include */
#include <DriverKit/IIGVerifyAliasDepthMiddle.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEALIASDEPTHMORE_H
#define _DRIVERKIT_IIGVerifyCASEALIASDEPTHMORE_H

#define IIGVerifyCaseAliasDepthMacroBase 2
#define IIGVerifyCaseAliasDepthMacroAlias IIGVerifyCaseAliasDepthMacroBase

enum {
	kIIGVerifyCaseAliasDepthEnumBase = 5,
	kIIGVerifyCaseAliasDepthEnumAlias = kIIGVerifyCaseAliasDepthEnumBase,
};

typedef uint32_t IIGVerifyCaseAliasDepthLocalWords[kIIGVerifyCaseAliasDepthEnumAlias];
typedef IIGVerifyAliasDepthMiddleWords IIGVerifyCaseAliasDepthIncludedWords;

/* source class IIGVerifyCaseAliasDepthMore IIGVerifyCaseAliasDepthMore.iig:18-35 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseAliasDepthMore : public OSObject
{
public:
	virtual kern_return_t
	InlineMacroAlias(const uint8_t bytes[IIGVerifyCaseAliasDepthMacroAlias],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineEnumAlias(const uint16_t values[kIIGVerifyCaseAliasDepthEnumAlias],
	    uint32_t valuesCount) LOCAL;

	virtual kern_return_t
	OutputLocalAlias(uint32_t wordsCount,
	    IIGVerifyCaseAliasDepthLocalWords words) LOCAL;

	virtual kern_return_t
	OutputIncludedAlias(uint32_t valuesCount,
	    IIGVerifyCaseAliasDepthIncludedWords values) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseAliasDepthMore IIGVerifyCaseAliasDepthMore.iig:18-35 */

#define IIGVerifyCaseAliasDepthMore_InlineMacroAlias_ID            0x9b61425b91a829d8ULL
#define IIGVerifyCaseAliasDepthMore_InlineEnumAlias_ID            0xb386b318e6365debULL
#define IIGVerifyCaseAliasDepthMore_OutputLocalAlias_ID            0xbd2a84f3c4e1d80eULL
#define IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_ID            0xa7e249e5488830f4ULL

#define IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Args \
        const unsigned short * values, \
        uint32_t valuesCount

#define IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Args \
        uint32_t valuesCount, \
        unsigned short * values

#define IIGVerifyCaseAliasDepthMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseAliasDepthMore * self, const IORPC rpc);\
\
    kern_return_t\
    InlineMacroAlias(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineEnumAlias(\
        const unsigned short * values,\
        uint32_t valuesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputLocalAlias(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputIncludedAlias(\
        uint32_t valuesCount,\
        unsigned short * values,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InlineMacroAlias_Impl(IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Args);\
\
    kern_return_t\
    InlineEnumAlias_Impl(IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Args);\
\
    kern_return_t\
    OutputLocalAlias_Impl(IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Args);\
\
    kern_return_t\
    OutputIncludedAlias_Impl(IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InlineMacroAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseAliasDepthMore_InlineMacroAlias_Args);\
    static kern_return_t\
    InlineMacroAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineMacroAlias_Handler func);\
\
    typedef kern_return_t (*InlineEnumAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseAliasDepthMore_InlineEnumAlias_Args);\
    static kern_return_t\
    InlineEnumAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineEnumAlias_Handler func);\
\
    typedef kern_return_t (*OutputLocalAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseAliasDepthMore_OutputLocalAlias_Args);\
    static kern_return_t\
    OutputLocalAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputLocalAlias_Handler func);\
\
    typedef kern_return_t (*OutputIncludedAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseAliasDepthMore_OutputIncludedAlias_Args);\
    static kern_return_t\
    OutputIncludedAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputIncludedAlias_Handler func);\
\


#define IIGVerifyCaseAliasDepthMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseAliasDepthMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseAliasDepthMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseAliasDepthMore_Class;

class IIGVerifyCaseAliasDepthMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseAliasDepthMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseAliasDepthMore_IVars;
struct IIGVerifyCaseAliasDepthMore_LocalIVars;

class IIGVerifyCaseAliasDepthMore : public OSObject, public IIGVerifyCaseAliasDepthMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseAliasDepthMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseAliasDepthMore_DECLARE_IVARS
IIGVerifyCaseAliasDepthMore_DECLARE_IVARS
#else /* IIGVerifyCaseAliasDepthMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseAliasDepthMore_IVars * ivars;
        IIGVerifyCaseAliasDepthMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseAliasDepthMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseAliasDepthMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseAliasDepthMore_Methods
    IIGVerifyCaseAliasDepthMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseAliasDepthMore.iig:37- */

#endif /* _DRIVERKIT_IIGVerifyCASEALIASDEPTHMORE_H */
