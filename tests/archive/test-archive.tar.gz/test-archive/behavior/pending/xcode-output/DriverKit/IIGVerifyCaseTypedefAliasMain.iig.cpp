/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseTypedefAliasMain.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseTypedefAliasMain.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseTypedefAliasMain.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned short *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned short __words[9];
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefAliasMain_AliasChainInput_Invocation;
struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned short *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned short __words[9];
};
#pragma pack(4)
struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseTypedefAliasMain_QueueNames  ""

#define IIGVerifyCaseTypedefAliasMain_MethodNames  ""

#define IIGVerifyCaseTypedefAliasMainMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseTypedefAliasMain_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseTypedefAliasMain_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseTypedefAliasMainMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t
OSClassDescription_IIGVerifyCaseTypedefAliasMain =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseTypedefAliasMain_t),
        .name                    = "IIGVerifyCaseTypedefAliasMain",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseTypedefAliasMain_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseTypedefAliasMain_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseTypedefAliasMainMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefAliasMain_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseTypedefAliasMain_QueueNames,
    .methodNames     = IIGVerifyCaseTypedefAliasMain_MethodNames,
    .metaMethodNames = IIGVerifyCaseTypedefAliasMainMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseTypedefAliasMainMetaClass;

static kern_return_t
IIGVerifyCaseTypedefAliasMain_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseTypedefAliasMain_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseTypedefAliasMain.base,
    .metaPointer       = &gIIGVerifyCaseTypedefAliasMainMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseTypedefAliasMain),

    .resv2             = {0},

    .New               = &IIGVerifyCaseTypedefAliasMain_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseTypedefAliasMain_Declaration;
const void * const
gIIGVerifyCaseTypedefAliasMain_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseTypedefAliasMain_Class;

static kern_return_t
IIGVerifyCaseTypedefAliasMain_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseTypedefAliasMainMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedefAliasMainMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseTypedefAliasMain) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseTypedefAliasMain::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseTypedefAliasMain::_Dispatch(IIGVerifyCaseTypedefAliasMain * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseTypedefAliasMain_AliasChainInput_ID:
        {
            ret = IIGVerifyCaseTypedefAliasMain::AliasChainInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefAliasMain::AliasChainInput_Handler, *self, &IIGVerifyCaseTypedefAliasMain::AliasChainInput_Impl));
            break;
        }
        case IIGVerifyCaseTypedefAliasMain_AliasChainOutput_ID:
        {
            ret = IIGVerifyCaseTypedefAliasMain::AliasChainOutput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefAliasMain::AliasChainOutput_Handler, *self, &IIGVerifyCaseTypedefAliasMain::AliasChainOutput_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseTypedefAliasMain::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseTypedefAliasMainMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefAliasMain::AliasChainInput(
        const unsigned short * words,
        uint32_t wordsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefAliasMain_AliasChainInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.words = NULL;

    if (wordsCount > (sizeof(msg->content.__words) / sizeof(msg->content.__words[0]))) return kIOReturnOverrun;
    bcopy(words, &msg->content.__words[0], wordsCount * sizeof(msg->content.__words[0]));

    msg->content.wordsCount = wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefAliasMain_AliasChainInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefAliasMain::AliasChainOutput(
        uint32_t wordsCount,
        unsigned short * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefAliasMain_AliasChainOutput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefAliasMain_AliasChainOutput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefAliasMain::AliasChainInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasChainInput_Handler func)
{
    IIGVerifyCaseTypedefAliasMain_AliasChainInput_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefAliasMain_AliasChainInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__words[0]),
        wordsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefAliasMain_AliasChainInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefAliasMain_AliasChainInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefAliasMain::AliasChainOutput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasChainOutput_Handler func)
{
    IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefAliasMain_AliasChainOutput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefAliasMain_AliasChainOutput_Rpl_ObjRefs;

    return (ret);
}



