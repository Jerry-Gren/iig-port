/* iig(DriverKit-440) generated from IIGVerifyCaseStringConstSpellingsMore.iig */

/* IIGVerifyCaseStringConstSpellingsMore.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESTRINGCONSTSPELLINGSMORE_H
#define _DRIVERKIT_IIGVerifyCASESTRINGCONSTSPELLINGSMORE_H

typedef char IIGVerifyAliasChar;
typedef const char IIGVerifyAliasConstCharMore;

/* source class IIGVerifyCaseStringConstSpellingsMore IIGVerifyCaseStringConstSpellingsMore.iig:9-25 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseStringConstSpellingsMore : public OSObject
{
public:
	virtual kern_return_t
	LeadingConst(const char name[32]) LOCAL;

	virtual kern_return_t
	TrailingConst(char const name[33]) LOCAL;

	virtual kern_return_t
	AliasLeadingConst(const IIGVerifyAliasChar name[34]) LOCAL;

	virtual kern_return_t
	AliasTrailingConst(IIGVerifyAliasChar const name[35]) LOCAL;

	virtual kern_return_t
	AliasConstElement(IIGVerifyAliasConstCharMore name[36]) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseStringConstSpellingsMore IIGVerifyCaseStringConstSpellingsMore.iig:9-25 */

#define IIGVerifyCaseStringConstSpellingsMore_LeadingConst_ID            0x965442230606eda9ULL
#define IIGVerifyCaseStringConstSpellingsMore_TrailingConst_ID            0xa2a8ce86e303ac90ULL
#define IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_ID            0xeba8572f95a4dd9aULL
#define IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_ID            0xae8f37815e5d0b90ULL
#define IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_ID            0xf2805a0e07104a13ULL

#define IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Args \
        const char * name

#define IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Args \
        const char * name

#define IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Args \
        const char * name

#define IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Args \
        const char * name

#define IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Args \
        const char * name

#define IIGVerifyCaseStringConstSpellingsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseStringConstSpellingsMore * self, const IORPC rpc);\
\
    kern_return_t\
    LeadingConst(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TrailingConst(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasLeadingConst(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasTrailingConst(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasConstElement(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    LeadingConst_Impl(IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Args);\
\
    kern_return_t\
    TrailingConst_Impl(IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Args);\
\
    kern_return_t\
    AliasLeadingConst_Impl(IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Args);\
\
    kern_return_t\
    AliasTrailingConst_Impl(IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Args);\
\
    kern_return_t\
    AliasConstElement_Impl(IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*LeadingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Args);\
    static kern_return_t\
    LeadingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        LeadingConst_Handler func);\
\
    typedef kern_return_t (*TrailingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Args);\
    static kern_return_t\
    TrailingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TrailingConst_Handler func);\
\
    typedef kern_return_t (*AliasLeadingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Args);\
    static kern_return_t\
    AliasLeadingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasLeadingConst_Handler func);\
\
    typedef kern_return_t (*AliasTrailingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Args);\
    static kern_return_t\
    AliasTrailingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasTrailingConst_Handler func);\
\
    typedef kern_return_t (*AliasConstElement_Handler)(OSMetaClassBase * target, IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Args);\
    static kern_return_t\
    AliasConstElement_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasConstElement_Handler func);\
\


#define IIGVerifyCaseStringConstSpellingsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseStringConstSpellingsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseStringConstSpellingsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseStringConstSpellingsMore_Class;

class IIGVerifyCaseStringConstSpellingsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseStringConstSpellingsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseStringConstSpellingsMore_IVars;
struct IIGVerifyCaseStringConstSpellingsMore_LocalIVars;

class IIGVerifyCaseStringConstSpellingsMore : public OSObject, public IIGVerifyCaseStringConstSpellingsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseStringConstSpellingsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseStringConstSpellingsMore_DECLARE_IVARS
IIGVerifyCaseStringConstSpellingsMore_DECLARE_IVARS
#else /* IIGVerifyCaseStringConstSpellingsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseStringConstSpellingsMore_IVars * ivars;
        IIGVerifyCaseStringConstSpellingsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseStringConstSpellingsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseStringConstSpellingsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseStringConstSpellingsMore_Methods
    IIGVerifyCaseStringConstSpellingsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseStringConstSpellingsMore.iig:27- */

#endif /* _DRIVERKIT_IIGVerifyCASESTRINGCONSTSPELLINGSMORE_H */
