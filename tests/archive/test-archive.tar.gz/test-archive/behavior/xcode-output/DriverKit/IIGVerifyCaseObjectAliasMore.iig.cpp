/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseObjectAliasMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseObjectAliasMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseObjectAliasMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseObjectAliasMore_InputAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectAliasMore_InputAlias_Msg_ObjRefs (2)

struct IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseObjectAliasMore_InputAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectAliasMore_InputAlias_Invocation;
struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectAliasMore_OutputAlias_Invocation;
struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef __objects[3];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objects__descriptor[3];
};
struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objects__descriptor[3];
    IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_ObjRefs (3)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectAliasMore_ArrayAlias_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseObjectAliasMore_QueueNames  ""

#define IIGVerifyCaseObjectAliasMore_MethodNames  ""

#define IIGVerifyCaseObjectAliasMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseObjectAliasMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseObjectAliasMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseObjectAliasMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t
OSClassDescription_IIGVerifyCaseObjectAliasMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseObjectAliasMore_t),
        .name                    = "IIGVerifyCaseObjectAliasMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseObjectAliasMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseObjectAliasMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseObjectAliasMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectAliasMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseObjectAliasMore_QueueNames,
    .methodNames     = IIGVerifyCaseObjectAliasMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseObjectAliasMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseObjectAliasMoreMetaClass;

static kern_return_t
IIGVerifyCaseObjectAliasMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseObjectAliasMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseObjectAliasMore.base,
    .metaPointer       = &gIIGVerifyCaseObjectAliasMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseObjectAliasMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseObjectAliasMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseObjectAliasMore_Declaration;
const void * const
gIIGVerifyCaseObjectAliasMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseObjectAliasMore_Class;

static kern_return_t
IIGVerifyCaseObjectAliasMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseObjectAliasMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseObjectAliasMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseObjectAliasMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseObjectAliasMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::_Dispatch(IIGVerifyCaseObjectAliasMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseObjectAliasMore_InputAlias_ID:
        {
            ret = IIGVerifyCaseObjectAliasMore::InputAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectAliasMore::InputAlias_Handler, *self, &IIGVerifyCaseObjectAliasMore::InputAlias_Impl));
            break;
        }
        case IIGVerifyCaseObjectAliasMore_OutputAlias_ID:
        {
            ret = IIGVerifyCaseObjectAliasMore::OutputAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectAliasMore::OutputAlias_Handler, *self, &IIGVerifyCaseObjectAliasMore::OutputAlias_Impl));
            break;
        }
        case IIGVerifyCaseObjectAliasMore_ArrayAlias_ID:
        {
            ret = IIGVerifyCaseObjectAliasMore::ArrayAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectAliasMore::ArrayAlias_Handler, *self, &IIGVerifyCaseObjectAliasMore::ArrayAlias_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseObjectAliasMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseObjectAliasMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::InputAlias(
        IIGVerifyAliasObject object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectAliasMore_InputAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectAliasMore_InputAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectAliasMore_InputAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectAliasMore_InputAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.object = (OSObjectRef) object;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectAliasMore_InputAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::OutputAlias(
        IIGVerifyAliasObjectOut object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectAliasMore_OutputAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectAliasMore_OutputAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::ArrayAlias(
        OSObject ** objects,
        uint32_t objectsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectAliasMore_ArrayAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    if (*objectsCount > (sizeof(rpl->content.__objects) / sizeof(rpl->content.__objects[0]))) return kIOReturnOverrun;
    msg->content.objectsCount = *objectsCount;

    msg->content.objectsCount = objectsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectAliasMore_ArrayAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 3) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.objectsCount < *objectsCount) *objectsCount = rpl->content.objectsCount;
        for (unsigned int idx = 0; idx < *objectsCount; idx++)
        {
           objects[idx] = OSDynamicCast(OSObject, (OSObject *) rpl->content.__objects[idx]);
        }
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::InputAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputAlias_Handler func)
{
    IIGVerifyCaseObjectAliasMore_InputAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectAliasMore_InputAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectAliasMore_InputAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectAliasMore_InputAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSObject * object;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectAliasMore_InputAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectAliasMore_InputAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    object = OSDynamicCast(OSObject, (OSObject *) MESSAGE_CONTENT(object));
    if (!object && MESSAGE_CONTENT(object)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectAliasMore_InputAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectAliasMore_InputAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::OutputAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputAlias_Handler func)
{
    IIGVerifyCaseObjectAliasMore_OutputAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectAliasMore_OutputAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectAliasMore_OutputAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectAliasMore_OutputAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectAliasMore_OutputAlias_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectAliasMore::ArrayAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ArrayAlias_Handler func)
{
    IIGVerifyCaseObjectAliasMore_ArrayAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    OSObject * objects[3] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectAliasMore_ArrayAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if __LP64__
    objects = (OSObject **)(uintptr_t) &reply->content.__objects[0];
#endif /* __LP64__ */

    ret = (*func)(target,
        objects,
        objectsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectAliasMore_ArrayAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 3;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectAliasMore_ArrayAlias_Rpl_ObjRefs;
    for (unsigned int idx = 0; idx < 3; idx++)
    {
        reply->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
#if !__LP64__
        reply->content.__objects[idx] = (OSObjectRef)(uintptr_t) objects[idx];
#endif /* !_LP64__ */
    }

    return (ret);
}



