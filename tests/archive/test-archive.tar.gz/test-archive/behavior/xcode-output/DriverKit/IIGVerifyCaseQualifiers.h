/* iig(DriverKit-440) generated from IIGVerifyCaseQualifiers.iig */

/* IIGVerifyCaseQualifiers.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEQUALIFIERS_H
#define _DRIVERKIT_IIGVerifyCASEQUALIFIERS_H

/* source class IIGVerifyCaseQualifiersBase IIGVerifyCaseQualifiers.iig:6-13 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseQualifiersBase : public OSObject
{
public:
	virtual kern_return_t
	OverrideMe(uint64_t value) LOCAL = 0;

	virtual kern_return_t
	ConstStatus(uint64_t * value) const LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseQualifiersBase IIGVerifyCaseQualifiers.iig:6-13 */

#define IIGVerifyCaseQualifiersBase_OverrideMe_ID            0x90b088d80908f62bULL
#define IIGVerifyCaseQualifiersBase_ConstStatus_ID            0x8cc74c0251f5fc64ULL

#define IIGVerifyCaseQualifiersBase_OverrideMe_Args \
        uint64_t value

#define IIGVerifyCaseQualifiersBase_ConstStatus_Args \
        uint64_t * value

#define IIGVerifyCaseQualifiersBase_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseQualifiersBase * self, const IORPC rpc);\
\
    kern_return_t\
    OverrideMe(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ConstStatus(\
        uint64_t * value,\
        OSDispatchMethod supermethod = NULL) const;\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    ConstStatus_Impl(IIGVerifyCaseQualifiersBase_ConstStatus_Args) const;\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*OverrideMe_Handler)(OSMetaClassBase * target, IIGVerifyCaseQualifiersBase_OverrideMe_Args);\
    static kern_return_t\
    OverrideMe_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OverrideMe_Handler func);\
\
    typedef kern_return_t (*ConstStatus_Handler)(OSMetaClassBase * target, IIGVerifyCaseQualifiersBase_ConstStatus_Args);\
    static kern_return_t\
    ConstStatus_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstStatus_Handler func);\
\


#define IIGVerifyCaseQualifiersBase_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseQualifiersBase_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseQualifiersBaseMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseQualifiersBase_Class;

class IIGVerifyCaseQualifiersBaseMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseQualifiersBaseInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseQualifiersBase_IVars;
struct IIGVerifyCaseQualifiersBase_LocalIVars;

class IIGVerifyCaseQualifiersBase : public OSObject, public IIGVerifyCaseQualifiersBaseInterface
{
#if !KERNEL
    friend class IIGVerifyCaseQualifiersBaseMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseQualifiersBase_DECLARE_IVARS
IIGVerifyCaseQualifiersBase_DECLARE_IVARS
#else /* IIGVerifyCaseQualifiersBase_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseQualifiersBase_IVars * ivars;
        IIGVerifyCaseQualifiersBase_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseQualifiersBase_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseQualifiersBaseMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseQualifiersBase_Methods
    IIGVerifyCaseQualifiersBase_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */


/* source class IIGVerifyCaseQualifiers IIGVerifyCaseQualifiers.iig:16-26 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseQualifiers : public IIGVerifyCaseQualifiersBase
{
public:
	virtual kern_return_t
	OverrideMe(uint64_t value) override LOCAL;

	virtual kern_return_t
	ConstStatus(uint64_t * value) const override LOCAL;

	virtual bool
	BoolStatus(uint64_t value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseQualifiers IIGVerifyCaseQualifiers.iig:16-26 */

#define IIGVerifyCaseQualifiers_BoolStatus_ID            0xf4a3e57d576031f4ULL

#define IIGVerifyCaseQualifiers_OverrideMe_Args \
        uint64_t value

#define IIGVerifyCaseQualifiers_ConstStatus_Args \
        uint64_t * value

#define IIGVerifyCaseQualifiers_BoolStatus_Args \
        uint64_t value

#define IIGVerifyCaseQualifiers_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseQualifiers * self, const IORPC rpc);\
\
    bool\
    BoolStatus(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    OverrideMe_Impl(IIGVerifyCaseQualifiersBase_OverrideMe_Args);\
\
    kern_return_t\
    ConstStatus_Impl(IIGVerifyCaseQualifiersBase_ConstStatus_Args) const;\
\
    bool\
    BoolStatus_Impl(IIGVerifyCaseQualifiers_BoolStatus_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef bool (*BoolStatus_Handler)(OSMetaClassBase * target, IIGVerifyCaseQualifiers_BoolStatus_Args);\
    static kern_return_t\
    BoolStatus_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        BoolStatus_Handler func);\
\


#define IIGVerifyCaseQualifiers_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseQualifiers_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseQualifiersMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseQualifiers_Class;

class IIGVerifyCaseQualifiersMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseQualifiersInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseQualifiers_IVars;
struct IIGVerifyCaseQualifiers_LocalIVars;

class IIGVerifyCaseQualifiers : public IIGVerifyCaseQualifiersBase, public IIGVerifyCaseQualifiersInterface
{
#if !KERNEL
    friend class IIGVerifyCaseQualifiersMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseQualifiers_DECLARE_IVARS
IIGVerifyCaseQualifiers_DECLARE_IVARS
#else /* IIGVerifyCaseQualifiers_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseQualifiers_IVars * ivars;
        IIGVerifyCaseQualifiers_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseQualifiers_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseQualifiersMetaClass; };
#endif /* KERNEL */

    using super = IIGVerifyCaseQualifiersBase;

#if !KERNEL
    IIGVerifyCaseQualifiers_Methods
    IIGVerifyCaseQualifiers_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseQualifiers.iig:28- */

#endif /* _DRIVERKIT_IIGVerifyCASEQUALIFIERS_H */
