/* iig(DriverKit-440) generated from IIGVerifyCaseTypedActionsMore.iig */

/* IIGVerifyCaseTypedActionsMore.iig:1-5 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASETYPEDACTIONSMORE_H
#define _DRIVERKIT_IIGVerifyCASETYPEDACTIONSMORE_H

/* source class IIGVerifyCaseTypedActionsMore IIGVerifyCaseTypedActionsMore.iig:6-23 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseTypedActionsMore : public OSObject
{
public:
	virtual void
	Completion(OSAction * action TARGET,
	    kern_return_t status,
	    uint64_t token) REPLY LOCAL;

	virtual kern_return_t
	Submit(OSAction * completion TYPE(IIGVerifyCaseTypedActionsMore::Completion),
	    uint64_t token) LOCAL;

	virtual void
	KernelCompletion(OSAction * action TARGET,
	    kern_return_t status,
	    uint64_t token)
	    KERNEL
	    TYPE(IIGVerifyCaseTypedActionsMore::Completion);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseTypedActionsMore IIGVerifyCaseTypedActionsMore.iig:6-23 */

#define IIGVerifyCaseTypedActionsMore_Completion_ID            0xa27f0e4e9d38dca7ULL
#define IIGVerifyCaseTypedActionsMore_Submit_ID            0xf585cf2e17bbcfe7ULL
#define IIGVerifyCaseTypedActionsMore_KernelCompletion_ID            0xe1ab1019baf5ebccULL

#define IIGVerifyCaseTypedActionsMore_Completion_Args \
        OSAction * action, \
        kern_return_t status, \
        uint64_t token

#define IIGVerifyCaseTypedActionsMore_Submit_Args \
        OSAction * completion, \
        uint64_t token

#define IIGVerifyCaseTypedActionsMore_KernelCompletion_Args \
        OSAction * action, \
        kern_return_t status, \
        uint64_t token

#define IIGVerifyCaseTypedActionsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseTypedActionsMore * self, const IORPC rpc);\
\
    kern_return_t\
    Completion(\
        IORPC rpc,\
        OSAction * action,\
        kern_return_t status,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    Submit(\
        OSAction * completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CreateActionKernelCompletion(size_t referenceSize, OSAction ** action);\
\
\
protected:\
    /* _Impl methods */\
\
    void\
    Completion_Impl(IIGVerifyCaseTypedActionsMore_Completion_Args);\
\
    kern_return_t\
    Submit_Impl(IIGVerifyCaseTypedActionsMore_Submit_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef void (*Completion_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedActionsMore_Completion_Args);\
    static kern_return_t\
    Completion_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Completion_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    Completion_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Completion_Handler func);\
\
    typedef kern_return_t (*Submit_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedActionsMore_Submit_Args);\
    static kern_return_t\
    Submit_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Submit_Handler func);\
\


#define IIGVerifyCaseTypedActionsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    void\
    KernelCompletion_Impl(IIGVerifyCaseTypedActionsMore_KernelCompletion_Args);\
\


#define IIGVerifyCaseTypedActionsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseTypedActionsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseTypedActionsMore_Class;

class IIGVerifyCaseTypedActionsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseTypedActionsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseTypedActionsMore_IVars;
struct IIGVerifyCaseTypedActionsMore_LocalIVars;

class IIGVerifyCaseTypedActionsMore : public OSObject, public IIGVerifyCaseTypedActionsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseTypedActionsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseTypedActionsMore_DECLARE_IVARS
IIGVerifyCaseTypedActionsMore_DECLARE_IVARS
#else /* IIGVerifyCaseTypedActionsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseTypedActionsMore_IVars * ivars;
        IIGVerifyCaseTypedActionsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseTypedActionsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseTypedActionsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseTypedActionsMore_Methods
    IIGVerifyCaseTypedActionsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#define OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass;
extern const OSClassLoadInformation OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Class;

class OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

class  __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionInterface : public OSInterface
{
public:
};

struct OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_IVars;
struct OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_LocalIVars;

class __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion : public OSAction, public OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionInterface
{
#if KERNEL
    OSDeclareDefaultStructorsWithDispatch(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion);
#endif /* KERNEL */

#if !KERNEL
    friend class OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass;
#endif /* !KERNEL */

public:
#ifdef OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_DECLARE_IVARS
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_DECLARE_IVARS
#else /* OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_DECLARE_IVARS */
    union
    {
        OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_IVars * ivars;
        OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_LocalIVars * lvars;
    };
#endif /* OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_DECLARE_IVARS */
#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass; };
    virtual const OSMetaClass *
    getMetaClass() const APPLE_KEXT_OVERRIDE { return gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass; };
#endif /* KERNEL */

    using super = OSAction;

#if !KERNEL
    OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Methods
#endif /* !KERNEL */

    OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_VirtualMethods
};

#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseTypedActionsMore.iig:25- */

#endif /* _DRIVERKIT_IIGVerifyCASETYPEDACTIONSMORE_H */
