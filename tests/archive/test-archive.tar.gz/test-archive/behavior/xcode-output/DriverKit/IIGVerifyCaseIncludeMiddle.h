/* iig(DriverKit-440) generated from IIGVerifyCaseIncludeMiddle.iig */

/* IIGVerifyCaseIncludeMiddle.iig:1- */
#include <DriverKit/IIGVerifyCaseIncludeLeaf.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEINCLUDEMIDDLE_H
#define _DRIVERKIT_IIGVerifyCASEINCLUDEMIDDLE_H

typedef uint64_t IIGVerifyCaseMiddleScalars[3];

#endif /* _DRIVERKIT_IIGVerifyCASEINCLUDEMIDDLE_H */
