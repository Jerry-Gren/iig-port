/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseRetainedPrefixEdgesMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseRetainedPrefixEdgesMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyRetainedPrefixSerializable.h>
#include <DriverKit/IIGVerifyCaseRetainedPrefixEdgesMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Invocation;
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Invocation;
struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Invocation;
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Invocation;
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyRetainedPrefixSerializable * object;
#if !defined(__LP64__)
    uint32_t __objectPad;
#endif /* !defined(__LP64__) */
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_ool_descriptor_t  object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_ool_descriptor_t  object__descriptor;
    IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyRetainedPrefixSerializable_QueueNames  ""

#define IIGVerifyRetainedPrefixSerializable_MethodNames  ""

#define IIGVerifyRetainedPrefixSerializableMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyRetainedPrefixSerializable_QueueNames)];
    char               methodNames[sizeof(IIGVerifyRetainedPrefixSerializable_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyRetainedPrefixSerializableMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t
OSClassDescription_IIGVerifyRetainedPrefixSerializable =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyRetainedPrefixSerializable_t),
        .name                    = "IIGVerifyRetainedPrefixSerializable",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyRetainedPrefixSerializable_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyRetainedPrefixSerializable_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyRetainedPrefixSerializableMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyRetainedPrefixSerializable_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyRetainedPrefixSerializable_QueueNames,
    .methodNames     = IIGVerifyRetainedPrefixSerializable_MethodNames,
    .metaMethodNames = IIGVerifyRetainedPrefixSerializableMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyRetainedPrefixSerializableMetaClass;

static kern_return_t
IIGVerifyRetainedPrefixSerializable_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyRetainedPrefixSerializable_Class = 
{
    .description       = &OSClassDescription_IIGVerifyRetainedPrefixSerializable.base,
    .metaPointer       = &gIIGVerifyRetainedPrefixSerializableMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyRetainedPrefixSerializable),

    .resv2             = {0},

    .New               = &IIGVerifyRetainedPrefixSerializable_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyRetainedPrefixSerializable_Declaration;
const void * const
gIIGVerifyRetainedPrefixSerializable_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyRetainedPrefixSerializable_Class;

static kern_return_t
IIGVerifyRetainedPrefixSerializable_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyRetainedPrefixSerializableMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyRetainedPrefixSerializableMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyRetainedPrefixSerializable) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyRetainedPrefixSerializable::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyRetainedPrefixSerializable::_Dispatch(IIGVerifyRetainedPrefixSerializable * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyRetainedPrefixSerializable::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyRetainedPrefixSerializableMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseRetainedPrefixEdgesMore_QueueNames  ""

#define IIGVerifyCaseRetainedPrefixEdgesMore_MethodNames  ""

#define IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t
OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t),
        .name                    = "IIGVerifyCaseRetainedPrefixEdgesMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseRetainedPrefixEdgesMore_QueueNames,
    .methodNames     = IIGVerifyCaseRetainedPrefixEdgesMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseRetainedPrefixEdgesMoreMetaClass;

static kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseRetainedPrefixEdgesMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseRetainedPrefixEdgesMore.base,
    .metaPointer       = &gIIGVerifyCaseRetainedPrefixEdgesMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseRetainedPrefixEdgesMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseRetainedPrefixEdgesMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseRetainedPrefixEdgesMore_Declaration;
const void * const
gIIGVerifyCaseRetainedPrefixEdgesMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseRetainedPrefixEdgesMore_Class;

static kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseRetainedPrefixEdgesMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::_Dispatch(IIGVerifyCaseRetainedPrefixEdgesMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixEdgesMore::GETObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixEdgesMore::GETObject_Handler, *self, &IIGVerifyCaseRetainedPrefixEdgesMore::GETObject_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixEdgesMore::GetterObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixEdgesMore::GetterObject_Handler, *self, &IIGVerifyCaseRetainedPrefixEdgesMore::GetterObject_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixEdgesMore::ForgetObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixEdgesMore::ForgetObject_Handler, *self, &IIGVerifyCaseRetainedPrefixEdgesMore::ForgetObject_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixEdgesMore::GetAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixEdgesMore::GetAlias_Handler, *self, &IIGVerifyCaseRetainedPrefixEdgesMore::GetAlias_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixEdgesMore::GetSerializable_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixEdgesMore::GetSerializable_Handler, *self, &IIGVerifyCaseRetainedPrefixEdgesMore::GetSerializable_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GETObject(
        OSObject ** object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GetterObject(
        OSObject ** object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::ForgetObject(
        OSObject ** object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GetAlias(
        IIGVerifyRetainedObjectOutAlias object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GetSerializable(
        IIGVerifyRetainedSerializableAlias * object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(IIGVerifyRetainedPrefixSerializable, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GETObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        GETObject_Handler func)
{
    IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GetterObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        GetterObject_Handler func)
{
    IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::ForgetObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ForgetObject_Handler func)
{
    IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GetAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        GetAlias_Handler func)
{
    IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixEdgesMore::GetSerializable_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        GetSerializable_Handler func)
{
    IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    reply->object__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    reply->object__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Rpl_Content, object);
    reply->object__descriptor.size = 0;

    return (ret);
}



