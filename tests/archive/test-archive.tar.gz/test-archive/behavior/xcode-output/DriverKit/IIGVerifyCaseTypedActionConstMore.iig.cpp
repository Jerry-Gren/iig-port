/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseTypedActionConstMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseTypedActionConstMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseTypedActionConstMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseTypedActionConstMore_Completion_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionConstMore_Completion_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseTypedActionConstMore_Completion_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseTypedActionConstMore_Completion_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionConstMore_Completion_Msg_ObjRefs (2)

struct IIGVerifyCaseTypedActionConstMore_Completion_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionConstMore_Completion_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedActionConstMore_Completion_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedActionConstMore_Completion_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionConstMore_Completion_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionConstMore_Completion_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedActionConstMore_Completion_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedActionConstMore_Completion_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionConstMore_Completion_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedActionConstMore_Completion_Invocation;
struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSAction  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedActionConstMore_SubmitConst_Invocation;
struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
};
struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
    IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_ObjRefs (2)

struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseTypedActionConstMore_QueueNames  ""

#define IIGVerifyCaseTypedActionConstMore_MethodNames  ""

#define IIGVerifyCaseTypedActionConstMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseTypedActionConstMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseTypedActionConstMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseTypedActionConstMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t
OSClassDescription_IIGVerifyCaseTypedActionConstMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseTypedActionConstMore_t),
        .name                    = "IIGVerifyCaseTypedActionConstMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseTypedActionConstMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseTypedActionConstMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseTypedActionConstMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionConstMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseTypedActionConstMore_QueueNames,
    .methodNames     = IIGVerifyCaseTypedActionConstMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseTypedActionConstMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseTypedActionConstMoreMetaClass;

static kern_return_t
IIGVerifyCaseTypedActionConstMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseTypedActionConstMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseTypedActionConstMore.base,
    .metaPointer       = &gIIGVerifyCaseTypedActionConstMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseTypedActionConstMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseTypedActionConstMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseTypedActionConstMore_Declaration;
const void * const
gIIGVerifyCaseTypedActionConstMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseTypedActionConstMore_Class;

static kern_return_t
IIGVerifyCaseTypedActionConstMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseTypedActionConstMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedActionConstMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseTypedActionConstMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseTypedActionConstMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::_Dispatch(IIGVerifyCaseTypedActionConstMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseTypedActionConstMore_Completion_ID:
        {
            ret = IIGVerifyCaseTypedActionConstMore::Completion_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionConstMore::Completion_Handler, *self, &IIGVerifyCaseTypedActionConstMore::Completion_Impl));
            break;
        }
        case IIGVerifyCaseTypedActionConstMore_SubmitConst_ID:
        {
            ret = IIGVerifyCaseTypedActionConstMore::SubmitConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionConstMore::SubmitConst_Handler, *self, &IIGVerifyCaseTypedActionConstMore::SubmitConst_Impl));
            break;
        }
        case IIGVerifyCaseTypedActionConstMore_SubmitTopConst_ID:
        {
            ret = IIGVerifyCaseTypedActionConstMore::SubmitTopConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionConstMore::SubmitTopConst_Handler, *self, &IIGVerifyCaseTypedActionConstMore::SubmitTopConst_Impl));
            break;
        }
#if KERNEL
        case IIGVerifyCaseTypedActionConstMore_KernelCompletion_ID:
        {
            ret = IIGVerifyCaseTypedActionConstMore::Completion_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionConstMore::Completion_Handler, *self, &IIGVerifyCaseTypedActionConstMore::KernelCompletion_Impl), OSTypeID(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion));
            break;
        }
#endif /* !KERNEL */

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseTypedActionConstMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseTypedActionConstMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::Completion(
        IORPC rpc,
        OSAction * action,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseTypedActionConstMore_Completion_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedActionConstMore_Completion_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedActionConstMore_Completion_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.token = token;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::SubmitConst(
        const OSAction * completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedActionConstMore_SubmitConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.completion = *completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedActionConstMore_SubmitConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::SubmitTopConst(
        OSAction *const completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedActionConstMore_SubmitTopConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->completion__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.completion = (OSObjectRef) completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedActionConstMore_SubmitTopConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::CreateActionKernelCompletion(size_t referenceSize, OSAction ** action)
{
    kern_return_t ret;

#if defined(IOKIT_ENABLE_SHARED_PTR)
    OSSharedPtr<OSString>
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
    OSString *
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    typeName = OSString::withCString("OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion");
    if (!typeName) {
        return kIOReturnNoMemory;
    }
    ret = OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion::CreateWithTypeName(this,
                           IIGVerifyCaseTypedActionConstMore_KernelCompletion_ID,
                           IIGVerifyCaseTypedActionConstMore_Completion_ID,
                           referenceSize,
#if defined(IOKIT_ENABLE_SHARED_PTR)
                           typeName.get(),
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
                           typeName,
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
                           action);

#if !defined(IOKIT_ENABLE_SHARED_PTR)
    typeName->release();
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::Completion_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Completion_Handler func)
{
    return IIGVerifyCaseTypedActionConstMore::Completion_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::Completion_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Completion_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseTypedActionConstMore_Completion_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedActionConstMore_Completion_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedActionConstMore_Completion_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedActionConstMore_Completion_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedActionConstMore_Completion_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedActionConstMore_Completion_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedActionConstMore_Completion_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(token));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::SubmitConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitConst_Handler func)
{
    IIGVerifyCaseTypedActionConstMore_SubmitConst_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedActionConstMore_SubmitConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(completion),
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedActionConstMore_SubmitConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedActionConstMore_SubmitConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionConstMore::SubmitTopConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitTopConst_Handler func)
{
    IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSAction * completion;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    completion = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(completion));
    if (!completion && MESSAGE_CONTENT(completion)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        completion,
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedActionConstMore_SubmitTopConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Rpl_ObjRefs;

    return (ret);
}

#if KERNEL
OSDefineMetaClassAndStructors(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion, OSAction);
#endif /* KERNEL */

#if !KERNEL

#define OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_QueueNames  ""

#define OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_MethodNames  ""

#define OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass_MethodNames  ""

struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_QueueNames)];
    char               methodNames[sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_MethodNames)];
    char               metaMethodNames[sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass_MethodNames)];
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t
OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t),
        .name                    = "OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion",
        .superName               = "OSAction",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t, metaMethodOptions),
        .queueNamesSize       = sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t, queueNames),
        .methodNamesSize         = sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t, methodNames),
        .metaMethodNamesSize     = sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_QueueNames,
    .methodNames     = OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_MethodNames,
    .metaMethodNames = OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass_MethodNames,
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
OSMetaClass * gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_New(OSMetaClass * instance);

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const OSClassLoadInformation
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Class = 
{
    .description       = &OSClassDescription_OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion.base,
    .metaPointer       = &gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion),

    .resv2             = {0},

    .New               = &OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_New,
    .resv3             = {0},

};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
extern const void * const
gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Declaration;
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const void * const
gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Declaration
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Class;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_New(OSMetaClass * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass::New(OSObject * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion::_Dispatch(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSAction::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



