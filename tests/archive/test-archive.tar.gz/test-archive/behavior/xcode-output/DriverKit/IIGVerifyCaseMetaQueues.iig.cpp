/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseMetaQueues.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseMetaQueues.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseMetaQueues.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseMetaQueues_StaticA_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_StaticA_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMetaQueues_StaticA_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMetaQueues_StaticA_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_StaticA_Msg_ObjRefs (1)

struct IIGVerifyCaseMetaQueues_StaticA_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_StaticA_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMetaQueues_StaticA_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMetaQueues_StaticA_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_StaticA_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_StaticA_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMetaQueues_StaticA_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMetaQueues_StaticA_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_StaticA_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMetaQueues_StaticA_Invocation;
struct IIGVerifyCaseMetaQueues_StaticB_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_StaticB_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMetaQueues_StaticB_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMetaQueues_StaticB_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_StaticB_Msg_ObjRefs (1)

struct IIGVerifyCaseMetaQueues_StaticB_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_StaticB_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMetaQueues_StaticB_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMetaQueues_StaticB_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_StaticB_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_StaticB_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMetaQueues_StaticB_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMetaQueues_StaticB_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_StaticB_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMetaQueues_StaticB_Invocation;
struct IIGVerifyCaseMetaQueues_InstanceB_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_InstanceB_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMetaQueues_InstanceB_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMetaQueues_InstanceB_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_InstanceB_Msg_ObjRefs (1)

struct IIGVerifyCaseMetaQueues_InstanceB_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_InstanceB_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMetaQueues_InstanceB_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMetaQueues_InstanceB_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_InstanceB_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_InstanceB_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMetaQueues_InstanceB_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMetaQueues_InstanceB_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_InstanceB_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMetaQueues_InstanceB_Invocation;
struct IIGVerifyCaseMetaQueues_InstanceA_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_InstanceA_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMetaQueues_InstanceA_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMetaQueues_InstanceA_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_InstanceA_Msg_ObjRefs (1)

struct IIGVerifyCaseMetaQueues_InstanceA_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMetaQueues_InstanceA_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMetaQueues_InstanceA_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMetaQueues_InstanceA_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMetaQueues_InstanceA_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_InstanceA_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMetaQueues_InstanceA_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMetaQueues_InstanceA_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMetaQueues_InstanceA_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMetaQueues_InstanceA_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseMetaQueues_QueueNames  "" \
    "\025"IIGVerifyMetaQueueA"" \
    "\025"IIGVerifyMetaQueueB""

#define IIGVerifyCaseMetaQueues_MethodNames  "" \
    "\011InstanceA" \
    "\011InstanceB"

#define IIGVerifyCaseMetaQueuesMetaClass_MethodNames  "" \
    "\007StaticA" \
    "\007StaticB"

struct OSClassDescription_IIGVerifyCaseMetaQueues_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 2];
    uint64_t           metaMethodOptions[2 * 2];
    char               queueNames[sizeof(IIGVerifyCaseMetaQueues_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseMetaQueues_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseMetaQueuesMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseMetaQueues_t
OSClassDescription_IIGVerifyCaseMetaQueues =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseMetaQueues_t),
        .name                    = "IIGVerifyCaseMetaQueues",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 2,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMetaQueues_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 2,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMetaQueues_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseMetaQueues_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMetaQueues_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseMetaQueues_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMetaQueues_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseMetaQueuesMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMetaQueues_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseMetaQueues_InstanceA_ID,
        IIGVerifyCaseMetaQueues_InstanceB_ID,
        0x0000000000000000,
        0x0000000000000001,
    },
    .metaMethodOptions =
    {
        IIGVerifyCaseMetaQueues_StaticA_ID,
        IIGVerifyCaseMetaQueues_StaticB_ID,
        0x0000000000000000,
        0x0000000000000001,
    },
    .queueNames      = IIGVerifyCaseMetaQueues_QueueNames,
    .methodNames     = IIGVerifyCaseMetaQueues_MethodNames,
    .metaMethodNames = IIGVerifyCaseMetaQueuesMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseMetaQueuesMetaClass;

static kern_return_t
IIGVerifyCaseMetaQueues_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseMetaQueues_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseMetaQueues.base,
    .metaPointer       = &gIIGVerifyCaseMetaQueuesMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseMetaQueues),

    .resv2             = {0},

    .New               = &IIGVerifyCaseMetaQueues_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseMetaQueues_Declaration;
const void * const
gIIGVerifyCaseMetaQueues_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseMetaQueues_Class;

static kern_return_t
IIGVerifyCaseMetaQueues_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseMetaQueuesMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseMetaQueuesMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseMetaQueues) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseMetaQueues::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseMetaQueues::_Dispatch(IIGVerifyCaseMetaQueues * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseMetaQueues_InstanceB_ID:
        {
            ret = IIGVerifyCaseMetaQueues::InstanceB_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseMetaQueues::InstanceB_Handler, *self, &IIGVerifyCaseMetaQueues::InstanceB_Impl));
            break;
        }
        case IIGVerifyCaseMetaQueues_InstanceA_ID:
        {
            ret = IIGVerifyCaseMetaQueues::InstanceA_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseMetaQueues::InstanceA_Handler, *self, &IIGVerifyCaseMetaQueues::InstanceA_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseMetaQueues::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseMetaQueuesMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseMetaQueues_StaticA_ID:
            ret = IIGVerifyCaseMetaQueues::StaticA_Invoke(rpc, &IIGVerifyCaseMetaQueues::StaticA_Impl);
            break;
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseMetaQueues_StaticB_ID:
            ret = IIGVerifyCaseMetaQueues::StaticB_Invoke(rpc, &IIGVerifyCaseMetaQueues::StaticB_Impl);
            break;
#endif /* !KERNEL */

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::StaticA_Call(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMetaQueues_StaticA_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMetaQueues_StaticA_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMetaQueues_StaticA_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMetaQueues_StaticA_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMetaQueues_StaticA_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseMetaQueues);
    msg->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_StaticA_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseMetaQueues)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMetaQueues_StaticA_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMetaQueues_StaticA_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::StaticB_Call(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMetaQueues_StaticB_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMetaQueues_StaticB_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMetaQueues_StaticB_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMetaQueues_StaticB_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMetaQueues_StaticB_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseMetaQueues);
    msg->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_StaticB_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseMetaQueues)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMetaQueues_StaticB_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMetaQueues_StaticB_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::InstanceB(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMetaQueues_InstanceB_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMetaQueues_InstanceB_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMetaQueues_InstanceB_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMetaQueues_InstanceB_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMetaQueues_InstanceB_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_InstanceB_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMetaQueues_InstanceB_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMetaQueues_InstanceB_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::InstanceA(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMetaQueues_InstanceA_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMetaQueues_InstanceA_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMetaQueues_InstanceA_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMetaQueues_InstanceA_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMetaQueues_InstanceA_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_InstanceA_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMetaQueues_InstanceA_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMetaQueues_InstanceA_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::StaticA_Invoke(const IORPC _rpc,
        StaticA_Handler func)
{
    IIGVerifyCaseMetaQueues_StaticA_Invocation rpc = { _rpc };
    IIGVerifyCaseMetaQueues_StaticA_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMetaQueues_StaticA_Msg *         message = rpc.message;
    const IIGVerifyCaseMetaQueues_StaticA_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMetaQueues_StaticA_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMetaQueues_StaticA_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMetaQueues_StaticA_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMetaQueues_StaticA_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_StaticA_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::StaticB_Invoke(const IORPC _rpc,
        StaticB_Handler func)
{
    IIGVerifyCaseMetaQueues_StaticB_Invocation rpc = { _rpc };
    IIGVerifyCaseMetaQueues_StaticB_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMetaQueues_StaticB_Msg *         message = rpc.message;
    const IIGVerifyCaseMetaQueues_StaticB_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMetaQueues_StaticB_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMetaQueues_StaticB_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMetaQueues_StaticB_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMetaQueues_StaticB_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_StaticB_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::InstanceB_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceB_Handler func)
{
    IIGVerifyCaseMetaQueues_InstanceB_Invocation rpc = { _rpc };
    IIGVerifyCaseMetaQueues_InstanceB_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMetaQueues_InstanceB_Msg *         message = rpc.message;
    const IIGVerifyCaseMetaQueues_InstanceB_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMetaQueues_InstanceB_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMetaQueues_InstanceB_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMetaQueues_InstanceB_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMetaQueues_InstanceB_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_InstanceB_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseMetaQueues::InstanceA_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceA_Handler func)
{
    IIGVerifyCaseMetaQueues_InstanceA_Invocation rpc = { _rpc };
    IIGVerifyCaseMetaQueues_InstanceA_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMetaQueues_InstanceA_Msg *         message = rpc.message;
    const IIGVerifyCaseMetaQueues_InstanceA_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMetaQueues_InstanceA_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMetaQueues_InstanceA_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMetaQueues_InstanceA_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMetaQueues_InstanceA_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMetaQueues_InstanceA_Rpl_ObjRefs;

    return (ret);
}



