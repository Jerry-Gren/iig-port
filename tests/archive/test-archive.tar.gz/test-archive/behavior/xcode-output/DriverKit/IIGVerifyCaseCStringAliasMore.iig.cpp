/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseCStringAliasMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseCStringAliasMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseCStringAliasMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    char  name;
};
#pragma pack(4)
struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCStringAliasMore_CStringAlias_Invocation;
struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[32];
};
#pragma pack(4)
struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseCStringAliasMore_QueueNames  ""

#define IIGVerifyCaseCStringAliasMore_MethodNames  ""

#define IIGVerifyCaseCStringAliasMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseCStringAliasMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseCStringAliasMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseCStringAliasMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t
OSClassDescription_IIGVerifyCaseCStringAliasMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseCStringAliasMore_t),
        .name                    = "IIGVerifyCaseCStringAliasMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseCStringAliasMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseCStringAliasMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseCStringAliasMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCStringAliasMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseCStringAliasMore_QueueNames,
    .methodNames     = IIGVerifyCaseCStringAliasMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseCStringAliasMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseCStringAliasMoreMetaClass;

static kern_return_t
IIGVerifyCaseCStringAliasMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseCStringAliasMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseCStringAliasMore.base,
    .metaPointer       = &gIIGVerifyCaseCStringAliasMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseCStringAliasMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseCStringAliasMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseCStringAliasMore_Declaration;
const void * const
gIIGVerifyCaseCStringAliasMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseCStringAliasMore_Class;

static kern_return_t
IIGVerifyCaseCStringAliasMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseCStringAliasMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseCStringAliasMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseCStringAliasMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseCStringAliasMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseCStringAliasMore::_Dispatch(IIGVerifyCaseCStringAliasMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseCStringAliasMore_CStringAlias_ID:
        {
            ret = IIGVerifyCaseCStringAliasMore::CStringAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCStringAliasMore::CStringAlias_Handler, *self, &IIGVerifyCaseCStringAliasMore::CStringAlias_Impl));
            break;
        }
        case IIGVerifyCaseCStringAliasMore_CStringArrayAlias_ID:
        {
            ret = IIGVerifyCaseCStringAliasMore::CStringArrayAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCStringAliasMore::CStringArrayAlias_Handler, *self, &IIGVerifyCaseCStringAliasMore::CStringArrayAlias_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseCStringAliasMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseCStringAliasMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseCStringAliasMore::CStringAlias(
        IIGVerifyAliasCString name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCStringAliasMore_CStringAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = *name;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCStringAliasMore_CStringAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCStringAliasMore::CStringArrayAlias(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCStringAliasMore_CStringArrayAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCStringAliasMore_CStringArrayAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCStringAliasMore::CStringAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CStringAlias_Handler func)
{
    IIGVerifyCaseCStringAliasMore_CStringAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCStringAliasMore_CStringAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCStringAliasMore_CStringAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(name));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCStringAliasMore_CStringAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCStringAliasMore_CStringAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCStringAliasMore::CStringArrayAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CStringArrayAlias_Handler func)
{
    IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCStringAliasMore_CStringArrayAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Rpl_ObjRefs;

    return (ret);
}



