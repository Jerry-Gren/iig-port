/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseTypedefDepth.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseTypedefDepth.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseTypedefDepth.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseTypedefDepth_AliasInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[6];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefDepth_AliasInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefDepth_AliasInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefDepth_AliasInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefDepth_AliasInput_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefDepth_AliasInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefDepth_AliasInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefDepth_AliasInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefDepth_AliasInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefDepth_AliasInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefDepth_AliasInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefDepth_AliasInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefDepth_AliasInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefDepth_AliasInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefDepth_AliasInput_Invocation;
struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefDepth_AliasOutput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefDepth_AliasOutput_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned char *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned char __words[6];
};
#pragma pack(4)
struct IIGVerifyCaseTypedefDepth_AliasOutput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefDepth_AliasOutput_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseTypedefDepth_QueueNames  ""

#define IIGVerifyCaseTypedefDepth_MethodNames  ""

#define IIGVerifyCaseTypedefDepthMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseTypedefDepth_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseTypedefDepth_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseTypedefDepth_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseTypedefDepthMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseTypedefDepth_t
OSClassDescription_IIGVerifyCaseTypedefDepth =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseTypedefDepth_t),
        .name                    = "IIGVerifyCaseTypedefDepth",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefDepth_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefDepth_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseTypedefDepth_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefDepth_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseTypedefDepth_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefDepth_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseTypedefDepthMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefDepth_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseTypedefDepth_QueueNames,
    .methodNames     = IIGVerifyCaseTypedefDepth_MethodNames,
    .metaMethodNames = IIGVerifyCaseTypedefDepthMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseTypedefDepthMetaClass;

static kern_return_t
IIGVerifyCaseTypedefDepth_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseTypedefDepth_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseTypedefDepth.base,
    .metaPointer       = &gIIGVerifyCaseTypedefDepthMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseTypedefDepth),

    .resv2             = {0},

    .New               = &IIGVerifyCaseTypedefDepth_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseTypedefDepth_Declaration;
const void * const
gIIGVerifyCaseTypedefDepth_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseTypedefDepth_Class;

static kern_return_t
IIGVerifyCaseTypedefDepth_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseTypedefDepthMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedefDepthMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseTypedefDepth) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseTypedefDepth::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseTypedefDepth::_Dispatch(IIGVerifyCaseTypedefDepth * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseTypedefDepth_AliasInput_ID:
        {
            ret = IIGVerifyCaseTypedefDepth::AliasInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefDepth::AliasInput_Handler, *self, &IIGVerifyCaseTypedefDepth::AliasInput_Impl));
            break;
        }
        case IIGVerifyCaseTypedefDepth_AliasOutput_ID:
        {
            ret = IIGVerifyCaseTypedefDepth::AliasOutput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefDepth::AliasOutput_Handler, *self, &IIGVerifyCaseTypedefDepth::AliasOutput_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseTypedefDepth::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseTypedefDepthMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefDepth::AliasInput(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefDepth_AliasInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefDepth_AliasInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefDepth_AliasInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefDepth_AliasInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefDepth_AliasInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefDepth_AliasInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefDepth_AliasInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefDepth_AliasInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefDepth::AliasOutput(
        uint32_t wordsCount,
        unsigned char * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefDepth_AliasOutput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefDepth_AliasOutput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefDepth_AliasOutput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefDepth_AliasOutput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefDepth_AliasOutput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefDepth::AliasInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasInput_Handler func)
{
    IIGVerifyCaseTypedefDepth_AliasInput_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefDepth_AliasInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefDepth_AliasInput_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefDepth_AliasInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefDepth_AliasInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefDepth_AliasInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefDepth_AliasInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefDepth_AliasInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefDepth_AliasInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefDepth::AliasOutput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasOutput_Handler func)
{
    IIGVerifyCaseTypedefDepth_AliasOutput_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefDepth_AliasOutput_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefDepth_AliasOutput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefDepth_AliasOutput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefDepth_AliasOutput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefDepth_AliasOutput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefDepth_AliasOutput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefDepth_AliasOutput_Rpl_ObjRefs;

    return (ret);
}



