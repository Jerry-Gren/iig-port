/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseRemoteStaticMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseRemoteStaticMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseRemoteStaticMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_ObjRefs (1)

struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRemoteStaticMore_StaticRemote_Invocation;
struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_ObjRefs (1)

struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_Content
{
    IORPCMessage __hdr;
    uint64_t __replyBuffer[8];
};
#pragma pack(4)
struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Invocation;
struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_ObjRefs (1)

struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRemoteStaticMore_InstanceRemote_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseRemoteStaticMore_QueueNames  ""

#define IIGVerifyCaseRemoteStaticMore_MethodNames  ""

#define IIGVerifyCaseRemoteStaticMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseRemoteStaticMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseRemoteStaticMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseRemoteStaticMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t
OSClassDescription_IIGVerifyCaseRemoteStaticMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseRemoteStaticMore_t),
        .name                    = "IIGVerifyCaseRemoteStaticMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseRemoteStaticMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseRemoteStaticMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseRemoteStaticMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteStaticMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseRemoteStaticMore_QueueNames,
    .methodNames     = IIGVerifyCaseRemoteStaticMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseRemoteStaticMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseRemoteStaticMoreMetaClass;

static kern_return_t
IIGVerifyCaseRemoteStaticMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseRemoteStaticMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseRemoteStaticMore.base,
    .metaPointer       = &gIIGVerifyCaseRemoteStaticMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseRemoteStaticMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseRemoteStaticMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseRemoteStaticMore_Declaration;
const void * const
gIIGVerifyCaseRemoteStaticMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseRemoteStaticMore_Class;

static kern_return_t
IIGVerifyCaseRemoteStaticMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseRemoteStaticMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseRemoteStaticMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseRemoteStaticMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseRemoteStaticMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::_Dispatch(IIGVerifyCaseRemoteStaticMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseRemoteStaticMore_InstanceRemote_ID:
        {
            ret = IIGVerifyCaseRemoteStaticMore::InstanceRemote_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRemoteStaticMore::InstanceRemote_Handler, *self, &IIGVerifyCaseRemoteStaticMore::InstanceRemote_Impl));
            break;
        }
#endif /* !KERNEL */

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseRemoteStaticMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseRemoteStaticMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseRemoteStaticMore_StaticRemote_ID:
            ret = IIGVerifyCaseRemoteStaticMore::StaticRemote_Invoke(rpc, &IIGVerifyCaseRemoteStaticMore::StaticRemote_Impl);
            break;
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_ID:
            ret = IIGVerifyCaseRemoteStaticMore::StaticInvokeReply_Invoke(rpc, &IIGVerifyCaseRemoteStaticMore::StaticInvokeReply_Impl);
            break;
#endif /* !KERNEL */

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::StaticRemote(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRemoteStaticMore_StaticRemote_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseRemoteStaticMore);
    msg->content.__hdr.objectRefs = IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseRemoteStaticMore)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRemoteStaticMore_StaticRemote_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::StaticInvokeReply(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseRemoteStaticMore);
    msg->content.__hdr.objectRefs = IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseRemoteStaticMore)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        if (rpl->mach.msgh.msgh_size < (sizeof(IORPCMessageMach) + sizeof(IORPCMessage))) { ret = kIOReturnIPCError; break; };
        if (rpl->mach.msgh_body.msgh_descriptor_count >= 1)
        {
            if (rpl->mach.msgh.msgh_size < (sizeof(IORPCMessageMach) + sizeof(mach_msg_port_descriptor_t) + sizeof(IORPCMessage))) { ret = kIOReturnIPCError; break; };
        }
        else
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (ret == kIOReturnSuccess) {
            IORPCMessage * message;
            OSObject     * object;

#ifdef KERNEL
            message = rpc.kernelContent;
#else /* KERNEL */
            message = IORPCMessageFromMach(rpc.reply, false);
#endif /* KERNEL */
            if ((rpc.reply->msgh_body.msgh_descriptor_count < 1) || !(kIORPCMessageOneway & message->flags)) {
               ret = kIOReturnIPCError;
            } else {
              object  = (typeof(object)) message->objects[0];
              if (!object) ret = kIOReturnIPCError;
              else
              {
                  rpc.sendSize  = rpc.replySize;
                  rpc.replySize = 0;
                  rpc.reply     = NULL;

                  ret = object->Invoke(rpc);
              }
          }
        }
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::InstanceRemote(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRemoteStaticMore_InstanceRemote_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRemoteStaticMore_InstanceRemote_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::StaticRemote_Invoke(const IORPC _rpc,
        StaticRemote_Handler func)
{
    IIGVerifyCaseRemoteStaticMore_StaticRemote_Invocation rpc = { _rpc };
    IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg *         message = rpc.message;
    const IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRemoteStaticMore_StaticRemote_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRemoteStaticMore_StaticRemote_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRemoteStaticMore_StaticRemote_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::StaticInvokeReply_Invoke(const IORPC _rpc,
        StaticInvokeReply_Handler func)
{
    IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Invocation rpc = { _rpc };
    IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg *         message = rpc.message;
    const IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(        rpc.rpc,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    IORPCMessage * replyMessage;

#ifdef KERNEL
    replyMessage = rpc.rpc.kernelContent;
#else /* KERNEL */
    replyMessage = IORPCMessageFromMach(rpc.rpc.reply, false);
#endif /* KERNEL */
    if ((rpc.rpc.reply->msgh_body.msgh_descriptor_count < 1)  || !(kIORPCMessageOneway & replyMessage->flags)) ret = kIOReturnIPCError;

    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteStaticMore::InstanceRemote_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceRemote_Handler func)
{
    IIGVerifyCaseRemoteStaticMore_InstanceRemote_Invocation rpc = { _rpc };
    IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg *         message = rpc.message;
    const IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRemoteStaticMore_InstanceRemote_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRemoteStaticMore_InstanceRemote_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRemoteStaticMore_InstanceRemote_Rpl_ObjRefs;

    return (ret);
}



