/* iig(DriverKit-440) generated from IIGVerifyCaseExtensions.iig */

/* IIGVerifyCaseExtensions.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEEXTENSIONS_H
#define _DRIVERKIT_IIGVerifyCASEEXTENSIONS_H

/* source class IIGVerifyCaseExtensionBase IIGVerifyCaseExtensions.iig:6-10 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseExtensionBase : public OSObject
{
public:
	virtual kern_return_t
	BaseLocal(uint64_t value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseExtensionBase IIGVerifyCaseExtensions.iig:6-10 */

#define IIGVerifyCaseExtensionBase_ExtraSecond_ID            0x8e5ab3356299ad3bULL
#define IIGVerifyCaseExtensionBase_ExtraFirst_ID            0x8a5c32df563ab53bULL
#define IIGVerifyCaseExtensionBase_BaseLocal_ID            0xa17660782eba19c4ULL

#define IIGVerifyCaseExtensionBase_ExtraSecond_Args \
        uint64_t value

#define IIGVerifyCaseExtensionBase_ExtraFirst_Args \
        uint64_t value

#define IIGVerifyCaseExtensionBase_BaseLocal_Args \
        uint64_t value

#define IIGVerifyCaseExtensionBase_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseExtensionBase * self, const IORPC rpc);\
\
    kern_return_t\
    ExtraSecond(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ExtraFirst(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    BaseLocal(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    ExtraSecond_Impl(IIGVerifyCaseExtensionBase_ExtraSecond_Args);\
\
    kern_return_t\
    ExtraFirst_Impl(IIGVerifyCaseExtensionBase_ExtraFirst_Args);\
\
    kern_return_t\
    BaseLocal_Impl(IIGVerifyCaseExtensionBase_BaseLocal_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*ExtraSecond_Handler)(OSMetaClassBase * target, IIGVerifyCaseExtensionBase_ExtraSecond_Args);\
    static kern_return_t\
    ExtraSecond_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ExtraSecond_Handler func);\
\
    typedef kern_return_t (*ExtraFirst_Handler)(OSMetaClassBase * target, IIGVerifyCaseExtensionBase_ExtraFirst_Args);\
    static kern_return_t\
    ExtraFirst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ExtraFirst_Handler func);\
\
    typedef kern_return_t (*BaseLocal_Handler)(OSMetaClassBase * target, IIGVerifyCaseExtensionBase_BaseLocal_Args);\
    static kern_return_t\
    BaseLocal_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        BaseLocal_Handler func);\
\


#define IIGVerifyCaseExtensionBase_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseExtensionBase_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseExtensionBaseMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseExtensionBase_Class;

class IIGVerifyCaseExtensionBaseMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseExtensionBaseInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseExtensionBase_IVars;
struct IIGVerifyCaseExtensionBase_LocalIVars;

class IIGVerifyCaseExtensionBase : public OSObject, public IIGVerifyCaseExtensionBaseInterface
{
#if !KERNEL
    friend class IIGVerifyCaseExtensionBaseMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseExtensionBase_DECLARE_IVARS
IIGVerifyCaseExtensionBase_DECLARE_IVARS
#else /* IIGVerifyCaseExtensionBase_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseExtensionBase_IVars * ivars;
        IIGVerifyCaseExtensionBase_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseExtensionBase_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseExtensionBaseMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseExtensionBase_Methods
    IIGVerifyCaseExtensionBase_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */




/* source class IIGVerifyCaseExtensionChild IIGVerifyCaseExtensions.iig:27-31 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseExtensionChild : public IIGVerifyCaseExtensionBase
{
public:
	virtual kern_return_t
	ChildLocal(uint64_t value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseExtensionChild IIGVerifyCaseExtensions.iig:27-31 */

#define IIGVerifyCaseExtensionChild_ChildLocal_ID            0x996b691ab291184bULL

#define IIGVerifyCaseExtensionChild_ChildLocal_Args \
        uint64_t value

#define IIGVerifyCaseExtensionChild_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseExtensionChild * self, const IORPC rpc);\
\
    kern_return_t\
    ChildLocal(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    ChildLocal_Impl(IIGVerifyCaseExtensionChild_ChildLocal_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*ChildLocal_Handler)(OSMetaClassBase * target, IIGVerifyCaseExtensionChild_ChildLocal_Args);\
    static kern_return_t\
    ChildLocal_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ChildLocal_Handler func);\
\


#define IIGVerifyCaseExtensionChild_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseExtensionChild_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseExtensionChildMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseExtensionChild_Class;

class IIGVerifyCaseExtensionChildMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseExtensionChildInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseExtensionChild_IVars;
struct IIGVerifyCaseExtensionChild_LocalIVars;

class IIGVerifyCaseExtensionChild : public IIGVerifyCaseExtensionBase, public IIGVerifyCaseExtensionChildInterface
{
#if !KERNEL
    friend class IIGVerifyCaseExtensionChildMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseExtensionChild_DECLARE_IVARS
IIGVerifyCaseExtensionChild_DECLARE_IVARS
#else /* IIGVerifyCaseExtensionChild_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseExtensionChild_IVars * ivars;
        IIGVerifyCaseExtensionChild_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseExtensionChild_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseExtensionChildMetaClass; };
#endif /* KERNEL */

    using super = IIGVerifyCaseExtensionBase;

#if !KERNEL
    IIGVerifyCaseExtensionChild_Methods
    IIGVerifyCaseExtensionChild_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseExtensions.iig:33- */

#endif /* _DRIVERKIT_IIGVerifyCASEEXTENSIONS_H */
