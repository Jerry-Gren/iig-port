/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseStaticVoid.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseStaticVoid.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseStaticVoid.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseStaticVoid_StaticVoid_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_StaticVoid_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStaticVoid_StaticVoid_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStaticVoid_StaticVoid_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_StaticVoid_Msg_ObjRefs (1)

struct IIGVerifyCaseStaticVoid_StaticVoid_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_StaticVoid_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStaticVoid_StaticVoid_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStaticVoid_StaticVoid_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_StaticVoid_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_StaticVoid_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticVoid_StaticVoid_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticVoid_StaticVoid_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_StaticVoid_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticVoid_StaticVoid_Invocation;
struct IIGVerifyCaseStaticVoid_StaticHost_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_StaticHost_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStaticVoid_StaticHost_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStaticVoid_StaticHost_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_StaticHost_Msg_ObjRefs (1)

struct IIGVerifyCaseStaticVoid_StaticHost_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_StaticHost_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStaticVoid_StaticHost_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStaticVoid_StaticHost_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_StaticHost_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_StaticHost_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticVoid_StaticHost_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticVoid_StaticHost_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_StaticHost_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticVoid_StaticHost_Invocation;
struct IIGVerifyCaseStaticVoid_StaticQueued_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_StaticQueued_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStaticVoid_StaticQueued_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStaticVoid_StaticQueued_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_StaticQueued_Msg_ObjRefs (1)

struct IIGVerifyCaseStaticVoid_StaticQueued_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_StaticQueued_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStaticVoid_StaticQueued_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStaticVoid_StaticQueued_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_StaticQueued_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_StaticQueued_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticVoid_StaticQueued_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticVoid_StaticQueued_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_StaticQueued_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticVoid_StaticQueued_Invocation;
struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStaticVoid_InstanceVoid_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_InstanceVoid_Msg_ObjRefs (1)

struct IIGVerifyCaseStaticVoid_InstanceVoid_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStaticVoid_InstanceVoid_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStaticVoid_InstanceVoid_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStaticVoid_InstanceVoid_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticVoid_InstanceVoid_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticVoid_InstanceVoid_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticVoid_InstanceVoid_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseStaticVoid_QueueNames  "" \
    "\032"IIGVerifyCaseStaticQueue""

#define IIGVerifyCaseStaticVoid_MethodNames  ""

#define IIGVerifyCaseStaticVoidMetaClass_MethodNames  "" \
    "\014StaticQueued"

struct OSClassDescription_IIGVerifyCaseStaticVoid_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 1];
    char               queueNames[sizeof(IIGVerifyCaseStaticVoid_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseStaticVoid_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseStaticVoidMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseStaticVoid_t
OSClassDescription_IIGVerifyCaseStaticVoid =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseStaticVoid_t),
        .name                    = "IIGVerifyCaseStaticVoid",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticVoid_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 1,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticVoid_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseStaticVoid_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticVoid_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseStaticVoid_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticVoid_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseStaticVoidMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticVoid_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
        IIGVerifyCaseStaticVoid_StaticQueued_ID,
        0x0000000000000000,
    },
    .queueNames      = IIGVerifyCaseStaticVoid_QueueNames,
    .methodNames     = IIGVerifyCaseStaticVoid_MethodNames,
    .metaMethodNames = IIGVerifyCaseStaticVoidMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseStaticVoidMetaClass;

static kern_return_t
IIGVerifyCaseStaticVoid_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseStaticVoid_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseStaticVoid.base,
    .metaPointer       = &gIIGVerifyCaseStaticVoidMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseStaticVoid),

    .resv2             = {0},

    .New               = &IIGVerifyCaseStaticVoid_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseStaticVoid_Declaration;
const void * const
gIIGVerifyCaseStaticVoid_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseStaticVoid_Class;

static kern_return_t
IIGVerifyCaseStaticVoid_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseStaticVoidMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStaticVoidMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseStaticVoid) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseStaticVoid::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseStaticVoid::_Dispatch(IIGVerifyCaseStaticVoid * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseStaticVoid_InstanceVoid_ID:
        {
            ret = IIGVerifyCaseStaticVoid::InstanceVoid_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStaticVoid::InstanceVoid_Handler, *self, &IIGVerifyCaseStaticVoid::InstanceVoid_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseStaticVoid::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseStaticVoidMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseStaticVoid_StaticVoid_ID:
            ret = IIGVerifyCaseStaticVoid::StaticVoid_Invoke(rpc, &IIGVerifyCaseStaticVoid::StaticVoid_Impl);
            break;
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseStaticVoid_StaticHost_ID:
            ret = IIGVerifyCaseStaticVoid::StaticHost_Invoke(rpc, &IIGVerifyCaseStaticVoid::StaticHost_Impl);
            break;
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseStaticVoid_StaticQueued_ID:
            ret = IIGVerifyCaseStaticVoid::StaticQueued_Invoke(rpc, &IIGVerifyCaseStaticVoid::StaticQueued_Impl);
            break;
#endif /* !KERNEL */

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

void
IIGVerifyCaseStaticVoid::StaticVoid_Call(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticVoid_StaticVoid_Msg_With_Content msg;
    } buf;
    struct IIGVerifyCaseStaticVoid_StaticVoid_Msg_With_Content * msg = &buf.msg;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticVoid_StaticVoid_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseStaticVoid);
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticVoid_StaticVoid_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = NULL, .sendSize = sizeof(*msg), .replySize = 0, .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = NULL, .sendSize = sizeof(*msg), .replySize = 0 };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseStaticVoid)->Invoke(rpc);

}

kern_return_t
IIGVerifyCaseStaticVoid::StaticHost_Call(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticVoid_StaticHost_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStaticVoid_StaticHost_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStaticVoid_StaticHost_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStaticVoid_StaticHost_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 1*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticVoid_StaticHost_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseStaticVoid);
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticVoid_StaticHost_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseStaticVoid)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStaticVoid_StaticHost_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStaticVoid_StaticHost_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStaticVoid::StaticQueued_Call(
        uint64_t value)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticVoid_StaticQueued_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStaticVoid_StaticQueued_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStaticVoid_StaticQueued_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStaticVoid_StaticQueued_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticVoid_StaticQueued_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseStaticVoid);
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticVoid_StaticQueued_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseStaticVoid)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStaticVoid_StaticQueued_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStaticVoid_StaticQueued_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

void
IIGVerifyCaseStaticVoid::InstanceVoid(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticVoid_InstanceVoid_Msg_With_Content msg;
    } buf;
    struct IIGVerifyCaseStaticVoid_InstanceVoid_Msg_With_Content * msg = &buf.msg;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticVoid_InstanceVoid_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticVoid_InstanceVoid_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = NULL, .sendSize = sizeof(*msg), .replySize = 0, .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = NULL, .sendSize = sizeof(*msg), .replySize = 0 };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

}

kern_return_t
IIGVerifyCaseStaticVoid::StaticVoid_Invoke(const IORPC _rpc,
        StaticVoid_Handler func)
{
    IIGVerifyCaseStaticVoid_StaticVoid_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticVoid_StaticVoid_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticVoid_StaticVoid_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticVoid_StaticVoid_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticVoid_StaticVoid_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticVoid_StaticVoid_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticVoid_StaticVoid_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    (*func)(        MESSAGE_CONTENT(value));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStaticVoid::StaticHost_Invoke(const IORPC _rpc,
        StaticHost_Handler func)
{
    IIGVerifyCaseStaticVoid_StaticHost_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticVoid_StaticHost_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticVoid_StaticHost_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticVoid_StaticHost_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticVoid_StaticHost_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticVoid_StaticHost_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticVoid_StaticHost_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStaticVoid_StaticHost_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStaticVoid_StaticHost_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStaticVoid::StaticQueued_Invoke(const IORPC _rpc,
        StaticQueued_Handler func)
{
    IIGVerifyCaseStaticVoid_StaticQueued_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticVoid_StaticQueued_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticVoid_StaticQueued_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticVoid_StaticQueued_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticVoid_StaticQueued_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticVoid_StaticQueued_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticVoid_StaticQueued_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStaticVoid_StaticQueued_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStaticVoid_StaticQueued_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStaticVoid::InstanceVoid_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceVoid_Handler func)
{
    IIGVerifyCaseStaticVoid_InstanceVoid_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticVoid_InstanceVoid_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticVoid_InstanceVoid_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticVoid_InstanceVoid_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticVoid_InstanceVoid_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticVoid_InstanceVoid_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticVoid_InstanceVoid_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    (*func)(target,
        MESSAGE_CONTENT(value));


    return (kIOReturnSuccess);
}



