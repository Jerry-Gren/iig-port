/* iig(DriverKit-440) generated from IIGVerifyCaseSerializableConcreteMore.iig */

/* IIGVerifyCaseSerializableConcreteMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESERIALIZABLECONCRETEMORE_H
#define _DRIVERKIT_IIGVerifyCASESERIALIZABLECONCRETEMORE_H

/* source class IIGVerifyCaseSerializablePayload IIGVerifyCaseSerializableConcreteMore.iig:6-7 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class IIG_SERIALIZABLE IIGVerifyCaseSerializablePayload : public OSObject
{
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseSerializablePayload IIGVerifyCaseSerializableConcreteMore.iig:6-7 */


#define IIGVerifyCaseSerializablePayload_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseSerializablePayload * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyCaseSerializablePayload_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseSerializablePayload_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseSerializablePayloadMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseSerializablePayload_Class;

class IIGVerifyCaseSerializablePayloadMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseSerializablePayloadInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseSerializablePayload_IVars;
struct IIGVerifyCaseSerializablePayload_LocalIVars;

class IIGVerifyCaseSerializablePayload : public OSObject, public IIGVerifyCaseSerializablePayloadInterface
{
#if !KERNEL
    friend class IIGVerifyCaseSerializablePayloadMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseSerializablePayload_DECLARE_IVARS
IIGVerifyCaseSerializablePayload_DECLARE_IVARS
#else /* IIGVerifyCaseSerializablePayload_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseSerializablePayload_IVars * ivars;
        IIGVerifyCaseSerializablePayload_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseSerializablePayload_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseSerializablePayloadMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseSerializablePayload_Methods
    IIGVerifyCaseSerializablePayload_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */


/* source class IIGVerifyCaseConcretePayload IIGVerifyCaseSerializableConcreteMore.iig:10-11 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class IIG_SERIALIZABLE IIG_CONCRETE IIGVerifyCaseConcretePayload : public OSObject
{
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseConcretePayload IIGVerifyCaseSerializableConcreteMore.iig:10-11 */


#define IIGVerifyCaseConcretePayload_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseConcretePayload * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyCaseConcretePayload_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseConcretePayload_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseConcretePayloadMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseConcretePayload_Class;

class IIGVerifyCaseConcretePayloadMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseConcretePayloadInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseConcretePayload_IVars;
struct IIGVerifyCaseConcretePayload_LocalIVars;

class IIGVerifyCaseConcretePayload : public OSObject, public IIGVerifyCaseConcretePayloadInterface
{
#if !KERNEL
    friend class IIGVerifyCaseConcretePayloadMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseConcretePayload_DECLARE_IVARS
IIGVerifyCaseConcretePayload_DECLARE_IVARS
#else /* IIGVerifyCaseConcretePayload_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseConcretePayload_IVars * ivars;
        IIGVerifyCaseConcretePayload_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseConcretePayload_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseConcretePayloadMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseConcretePayload_Methods
    IIGVerifyCaseConcretePayload_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */


/* source class IIGVerifyCaseSerializableConcreteMore IIGVerifyCaseSerializableConcreteMore.iig:14-24 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseSerializableConcreteMore : public OSObject
{
public:
	virtual kern_return_t
	SendPayload(IIGVerifyCaseSerializablePayload * payload) LOCAL;

	virtual kern_return_t
	CopyPayload(IIGVerifyCaseSerializablePayload ** payload) LOCAL;

	virtual kern_return_t
	SendConcrete(IIGVerifyCaseConcretePayload * payload) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseSerializableConcreteMore IIGVerifyCaseSerializableConcreteMore.iig:14-24 */

#define IIGVerifyCaseSerializableConcreteMore_SendPayload_ID            0xa1c7991a5466f650ULL
#define IIGVerifyCaseSerializableConcreteMore_CopyPayload_ID            0x84ee9f6c940b604dULL
#define IIGVerifyCaseSerializableConcreteMore_SendConcrete_ID            0xc2ceed47316af4b8ULL

#define IIGVerifyCaseSerializableConcreteMore_SendPayload_Args \
        IIGVerifyCaseSerializablePayload * payload

#define IIGVerifyCaseSerializableConcreteMore_CopyPayload_Args \
        IIGVerifyCaseSerializablePayload ** payload

#define IIGVerifyCaseSerializableConcreteMore_SendConcrete_Args \
        IIGVerifyCaseConcretePayload * payload

#define IIGVerifyCaseSerializableConcreteMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseSerializableConcreteMore * self, const IORPC rpc);\
\
    kern_return_t\
    SendPayload(\
        IIGVerifyCaseSerializablePayload * payload,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CopyPayload(\
        IIGVerifyCaseSerializablePayload ** payload,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SendConcrete(\
        IIGVerifyCaseConcretePayload * payload,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    SendPayload_Impl(IIGVerifyCaseSerializableConcreteMore_SendPayload_Args);\
\
    kern_return_t\
    CopyPayload_Impl(IIGVerifyCaseSerializableConcreteMore_CopyPayload_Args);\
\
    kern_return_t\
    SendConcrete_Impl(IIGVerifyCaseSerializableConcreteMore_SendConcrete_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*SendPayload_Handler)(OSMetaClassBase * target, IIGVerifyCaseSerializableConcreteMore_SendPayload_Args);\
    static kern_return_t\
    SendPayload_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SendPayload_Handler func);\
\
    typedef kern_return_t (*CopyPayload_Handler)(OSMetaClassBase * target, IIGVerifyCaseSerializableConcreteMore_CopyPayload_Args);\
    static kern_return_t\
    CopyPayload_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CopyPayload_Handler func);\
\
    typedef kern_return_t (*SendConcrete_Handler)(OSMetaClassBase * target, IIGVerifyCaseSerializableConcreteMore_SendConcrete_Args);\
    static kern_return_t\
    SendConcrete_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SendConcrete_Handler func);\
\


#define IIGVerifyCaseSerializableConcreteMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseSerializableConcreteMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseSerializableConcreteMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseSerializableConcreteMore_Class;

class IIGVerifyCaseSerializableConcreteMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseSerializableConcreteMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseSerializableConcreteMore_IVars;
struct IIGVerifyCaseSerializableConcreteMore_LocalIVars;

class IIGVerifyCaseSerializableConcreteMore : public OSObject, public IIGVerifyCaseSerializableConcreteMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseSerializableConcreteMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseSerializableConcreteMore_DECLARE_IVARS
IIGVerifyCaseSerializableConcreteMore_DECLARE_IVARS
#else /* IIGVerifyCaseSerializableConcreteMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseSerializableConcreteMore_IVars * ivars;
        IIGVerifyCaseSerializableConcreteMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseSerializableConcreteMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseSerializableConcreteMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseSerializableConcreteMore_Methods
    IIGVerifyCaseSerializableConcreteMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseSerializableConcreteMore.iig:26- */

#endif /* _DRIVERKIT_IIGVerifyCASESERIALIZABLECONCRETEMORE_H */
