/* iig(DriverKit-440) generated from IIGVerifyCaseRetainedPrefixMore.iig */

/* IIGVerifyCaseRetainedPrefixMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASERETAINEDPREFIXMORE_H
#define _DRIVERKIT_IIGVerifyCASERETAINEDPREFIXMORE_H

/* source class IIGVerifyCaseRetainedPrefixMore IIGVerifyCaseRetainedPrefixMore.iig:6-19 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseRetainedPrefixMore : public OSObject
{
public:
	virtual kern_return_t
	GetUpperObject(OSObject ** object) LOCAL;

	virtual kern_return_t
	getLowerObject(OSObject ** object) LOCAL;

	virtual kern_return_t
	CopyObject(OSObject ** object) LOCAL;

	virtual kern_return_t
	GetScalar(uint64_t * value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseRetainedPrefixMore IIGVerifyCaseRetainedPrefixMore.iig:6-19 */

#define IIGVerifyCaseRetainedPrefixMore_GetUpperObject_ID            0xbb5e13452933b9b0ULL
#define IIGVerifyCaseRetainedPrefixMore_getLowerObject_ID            0x91ca4dec279d01ffULL
#define IIGVerifyCaseRetainedPrefixMore_CopyObject_ID            0xb47285c932b015bcULL
#define IIGVerifyCaseRetainedPrefixMore_GetScalar_ID            0x80401d3512cb469aULL

#define IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Args \
        OSObject ** object

#define IIGVerifyCaseRetainedPrefixMore_getLowerObject_Args \
        OSObject ** object

#define IIGVerifyCaseRetainedPrefixMore_CopyObject_Args \
        OSObject ** object

#define IIGVerifyCaseRetainedPrefixMore_GetScalar_Args \
        uint64_t * value

#define IIGVerifyCaseRetainedPrefixMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseRetainedPrefixMore * self, const IORPC rpc);\
\
    kern_return_t\
    GetUpperObject(\
        __attribute__((os_returns_retained)) OSObject ** object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    getLowerObject(\
        __attribute__((os_returns_retained)) OSObject ** object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CopyObject(\
        OSObject ** object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    GetScalar(\
        uint64_t * value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    GetUpperObject_Impl(IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Args);\
\
    kern_return_t\
    getLowerObject_Impl(IIGVerifyCaseRetainedPrefixMore_getLowerObject_Args);\
\
    kern_return_t\
    CopyObject_Impl(IIGVerifyCaseRetainedPrefixMore_CopyObject_Args);\
\
    kern_return_t\
    GetScalar_Impl(IIGVerifyCaseRetainedPrefixMore_GetScalar_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*GetUpperObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Args);\
    static kern_return_t\
    GetUpperObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        GetUpperObject_Handler func);\
\
    typedef kern_return_t (*getLowerObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixMore_getLowerObject_Args);\
    static kern_return_t\
    getLowerObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        getLowerObject_Handler func);\
\
    typedef kern_return_t (*CopyObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixMore_CopyObject_Args);\
    static kern_return_t\
    CopyObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CopyObject_Handler func);\
\
    typedef kern_return_t (*GetScalar_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixMore_GetScalar_Args);\
    static kern_return_t\
    GetScalar_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        GetScalar_Handler func);\
\


#define IIGVerifyCaseRetainedPrefixMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseRetainedPrefixMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseRetainedPrefixMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseRetainedPrefixMore_Class;

class IIGVerifyCaseRetainedPrefixMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseRetainedPrefixMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseRetainedPrefixMore_IVars;
struct IIGVerifyCaseRetainedPrefixMore_LocalIVars;

class IIGVerifyCaseRetainedPrefixMore : public OSObject, public IIGVerifyCaseRetainedPrefixMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseRetainedPrefixMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseRetainedPrefixMore_DECLARE_IVARS
IIGVerifyCaseRetainedPrefixMore_DECLARE_IVARS
#else /* IIGVerifyCaseRetainedPrefixMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseRetainedPrefixMore_IVars * ivars;
        IIGVerifyCaseRetainedPrefixMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseRetainedPrefixMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseRetainedPrefixMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseRetainedPrefixMore_Methods
    IIGVerifyCaseRetainedPrefixMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseRetainedPrefixMore.iig:21- */

#endif /* _DRIVERKIT_IIGVerifyCASERETAINEDPREFIXMORE_H */
