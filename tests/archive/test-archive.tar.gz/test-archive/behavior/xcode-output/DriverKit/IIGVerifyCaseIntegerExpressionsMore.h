/* iig(DriverKit-440) generated from IIGVerifyCaseIntegerExpressionsMore.iig */

/* IIGVerifyCaseIntegerExpressionsMore.iig:1-20 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEINTEGEREXPRESSIONSMORE_H
#define _DRIVERKIT_IIGVerifyCASEINTEGEREXPRESSIONSMORE_H

#define IIGVerifyCaseIntegerExprBase 6
#define IIGVerifyCaseIntegerExprExtra 2
#define IIGVerifyCaseIntegerExprProduct (IIGVerifyCaseIntegerExprExtra * 3)
#define IIGVerifyCaseIntegerExprDifference (IIGVerifyCaseIntegerExprBase - IIGVerifyCaseIntegerExprExtra)
#define IIGVerifyCaseIntegerExprParens ((IIGVerifyCaseIntegerExprBase + IIGVerifyCaseIntegerExprExtra))

enum {
	kIIGVerifyCaseIntegerExprBase = 4,
	kIIGVerifyCaseIntegerExprDouble = kIIGVerifyCaseIntegerExprBase * 2,
	kIIGVerifyCaseIntegerExprMinus = kIIGVerifyCaseIntegerExprDouble - 3,
};

typedef uint32_t IIGVerifyCaseIntegerExprProductWords[IIGVerifyCaseIntegerExprProduct];
typedef uint32_t IIGVerifyCaseIntegerExprMinusWords[kIIGVerifyCaseIntegerExprMinus];

/* source class IIGVerifyCaseIntegerExpressionsMore IIGVerifyCaseIntegerExpressionsMore.iig:21-42 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseIntegerExpressionsMore : public OSObject
{
public:
	virtual kern_return_t
	InlineProduct(const uint8_t bytes[IIGVerifyCaseIntegerExprProduct],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineDifference(const uint8_t bytes[IIGVerifyCaseIntegerExprDifference],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineParens(const uint8_t bytes[IIGVerifyCaseIntegerExprParens],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	OutputProduct(uint32_t wordsCount,
	    IIGVerifyCaseIntegerExprProductWords words) LOCAL;

	virtual kern_return_t
	OutputEnumMinus(uint32_t wordsCount,
	    IIGVerifyCaseIntegerExprMinusWords words) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseIntegerExpressionsMore IIGVerifyCaseIntegerExpressionsMore.iig:21-42 */

#define IIGVerifyCaseIntegerExpressionsMore_InlineProduct_ID            0xc3313d4e75cae606ULL
#define IIGVerifyCaseIntegerExpressionsMore_InlineDifference_ID            0xec51fd686fe294d3ULL
#define IIGVerifyCaseIntegerExpressionsMore_InlineParens_ID            0xd3c38bf85f3f7dfdULL
#define IIGVerifyCaseIntegerExpressionsMore_OutputProduct_ID            0xd5d3d0ca3c2a4029ULL
#define IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_ID            0xfe1eb705ce1aad11ULL

#define IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerExpressionsMore_InlineParens_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseIntegerExpressionsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseIntegerExpressionsMore * self, const IORPC rpc);\
\
    kern_return_t\
    InlineProduct(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineDifference(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineParens(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputProduct(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputEnumMinus(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InlineProduct_Impl(IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Args);\
\
    kern_return_t\
    InlineDifference_Impl(IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Args);\
\
    kern_return_t\
    InlineParens_Impl(IIGVerifyCaseIntegerExpressionsMore_InlineParens_Args);\
\
    kern_return_t\
    OutputProduct_Impl(IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Args);\
\
    kern_return_t\
    OutputEnumMinus_Impl(IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InlineProduct_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Args);\
    static kern_return_t\
    InlineProduct_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineProduct_Handler func);\
\
    typedef kern_return_t (*InlineDifference_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Args);\
    static kern_return_t\
    InlineDifference_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineDifference_Handler func);\
\
    typedef kern_return_t (*InlineParens_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerExpressionsMore_InlineParens_Args);\
    static kern_return_t\
    InlineParens_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineParens_Handler func);\
\
    typedef kern_return_t (*OutputProduct_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Args);\
    static kern_return_t\
    OutputProduct_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputProduct_Handler func);\
\
    typedef kern_return_t (*OutputEnumMinus_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Args);\
    static kern_return_t\
    OutputEnumMinus_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputEnumMinus_Handler func);\
\


#define IIGVerifyCaseIntegerExpressionsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseIntegerExpressionsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseIntegerExpressionsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseIntegerExpressionsMore_Class;

class IIGVerifyCaseIntegerExpressionsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseIntegerExpressionsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseIntegerExpressionsMore_IVars;
struct IIGVerifyCaseIntegerExpressionsMore_LocalIVars;

class IIGVerifyCaseIntegerExpressionsMore : public OSObject, public IIGVerifyCaseIntegerExpressionsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseIntegerExpressionsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseIntegerExpressionsMore_DECLARE_IVARS
IIGVerifyCaseIntegerExpressionsMore_DECLARE_IVARS
#else /* IIGVerifyCaseIntegerExpressionsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseIntegerExpressionsMore_IVars * ivars;
        IIGVerifyCaseIntegerExpressionsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseIntegerExpressionsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseIntegerExpressionsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseIntegerExpressionsMore_Methods
    IIGVerifyCaseIntegerExpressionsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseIntegerExpressionsMore.iig:44- */

#endif /* _DRIVERKIT_IIGVerifyCASEINTEGEREXPRESSIONSMORE_H */
