/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseClassFactsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseClassFactsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyClassFactsSerializable.h>
#include <DriverKit/IIGVerifyCaseClassFactsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseClassFactsMore_MixFacts_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  object;
    IIGVerifyClassFactsSerializable * serializableOut;
#if !defined(__LP64__)
    uint32_t __serializableOutPad;
#endif /* !defined(__LP64__) */
    OSObject  constObject;
    IIGVerifyClassFactsSerializable  serializableIn;
    IIGVerifyClassFactsStruct  structIn;
};
#pragma pack(4)
struct IIGVerifyCaseClassFactsMore_MixFacts_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
    mach_msg_ool_descriptor_t  serializableOut__descriptor;
};
struct IIGVerifyCaseClassFactsMore_MixFacts_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
    mach_msg_ool_descriptor_t  serializableOut__descriptor;
    IIGVerifyCaseClassFactsMore_MixFacts_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseClassFactsMore_MixFacts_Msg_ObjRefs (3)

struct IIGVerifyCaseClassFactsMore_MixFacts_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  objectOut;
    IIGVerifyClassFactsStruct  structOut;
};
#pragma pack(4)
struct IIGVerifyCaseClassFactsMore_MixFacts_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objectOut__descriptor;
};
struct IIGVerifyCaseClassFactsMore_MixFacts_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objectOut__descriptor;
    IIGVerifyCaseClassFactsMore_MixFacts_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseClassFactsMore_MixFacts_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseClassFactsMore_MixFacts_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseClassFactsMore_MixFacts_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseClassFactsMore_MixFacts_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseClassFactsMore_MixFacts_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseClassFactsMore_MixFacts_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyClassFactsSerializable_QueueNames  ""

#define IIGVerifyClassFactsSerializable_MethodNames  ""

#define IIGVerifyClassFactsSerializableMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyClassFactsSerializable_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyClassFactsSerializable_QueueNames)];
    char               methodNames[sizeof(IIGVerifyClassFactsSerializable_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyClassFactsSerializableMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyClassFactsSerializable_t
OSClassDescription_IIGVerifyClassFactsSerializable =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyClassFactsSerializable_t),
        .name                    = "IIGVerifyClassFactsSerializable",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyClassFactsSerializable_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyClassFactsSerializable_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyClassFactsSerializable_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyClassFactsSerializable_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyClassFactsSerializable_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyClassFactsSerializable_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyClassFactsSerializableMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyClassFactsSerializable_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyClassFactsSerializable_QueueNames,
    .methodNames     = IIGVerifyClassFactsSerializable_MethodNames,
    .metaMethodNames = IIGVerifyClassFactsSerializableMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyClassFactsSerializableMetaClass;

static kern_return_t
IIGVerifyClassFactsSerializable_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyClassFactsSerializable_Class = 
{
    .description       = &OSClassDescription_IIGVerifyClassFactsSerializable.base,
    .metaPointer       = &gIIGVerifyClassFactsSerializableMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyClassFactsSerializable),

    .resv2             = {0},

    .New               = &IIGVerifyClassFactsSerializable_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyClassFactsSerializable_Declaration;
const void * const
gIIGVerifyClassFactsSerializable_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyClassFactsSerializable_Class;

static kern_return_t
IIGVerifyClassFactsSerializable_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyClassFactsSerializableMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyClassFactsSerializableMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyClassFactsSerializable) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyClassFactsSerializable::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyClassFactsSerializable::_Dispatch(IIGVerifyClassFactsSerializable * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyClassFactsSerializable::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyClassFactsSerializableMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseClassFactsMore_QueueNames  ""

#define IIGVerifyCaseClassFactsMore_MethodNames  ""

#define IIGVerifyCaseClassFactsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseClassFactsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseClassFactsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseClassFactsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseClassFactsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseClassFactsMore_t
OSClassDescription_IIGVerifyCaseClassFactsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseClassFactsMore_t),
        .name                    = "IIGVerifyCaseClassFactsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseClassFactsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseClassFactsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseClassFactsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseClassFactsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseClassFactsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseClassFactsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseClassFactsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseClassFactsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseClassFactsMore_QueueNames,
    .methodNames     = IIGVerifyCaseClassFactsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseClassFactsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseClassFactsMoreMetaClass;

static kern_return_t
IIGVerifyCaseClassFactsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseClassFactsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseClassFactsMore.base,
    .metaPointer       = &gIIGVerifyCaseClassFactsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseClassFactsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseClassFactsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseClassFactsMore_Declaration;
const void * const
gIIGVerifyCaseClassFactsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseClassFactsMore_Class;

static kern_return_t
IIGVerifyCaseClassFactsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseClassFactsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseClassFactsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseClassFactsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseClassFactsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseClassFactsMore::_Dispatch(IIGVerifyCaseClassFactsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseClassFactsMore_MixFacts_ID:
        {
            ret = IIGVerifyCaseClassFactsMore::MixFacts_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseClassFactsMore::MixFacts_Handler, *self, &IIGVerifyCaseClassFactsMore::MixFacts_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseClassFactsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseClassFactsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseClassFactsMore::MixFacts(
        IIGVerifyObjectAlias object,
        IIGVerifyObjectAlias * objectOut,
        IIGVerifyConstObjectAlias constObject,
        IIGVerifySerializableAlias serializableOut,
        IIGVerifyConstSerializableAlias serializableIn,
        IIGVerifyStructOutAlias structOut,
        IIGVerifyStructInAlias structIn,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseClassFactsMore_MixFacts_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseClassFactsMore_MixFacts_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseClassFactsMore_MixFacts_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseClassFactsMore_MixFacts_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseClassFactsMore_MixFacts_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseClassFactsMore_MixFacts_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 3;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.object = (OSObjectRef) object;

    msg->content.constObject = *constObject;

    msg->serializableOut__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->serializableOut__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->serializableOut__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseClassFactsMore_MixFacts_Msg_Content, serializableOut);
    msg->content.serializableOut = serializableOut;

    msg->content.serializableIn = *serializableIn;

    msg->content.structIn = *structIn;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseClassFactsMore_MixFacts_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseClassFactsMore_MixFacts_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *objectOut = OSDynamicCast(OSObject, (OSObject *) rpl->content.objectOut);
        if (rpl->content.objectOut && !*objectOut) ret = kIOReturnBadArgument;
        if (structOut) *structOut = rpl->content.structOut;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseClassFactsMore::MixFacts_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        MixFacts_Handler func)
{
    IIGVerifyCaseClassFactsMore_MixFacts_Invocation rpc = { _rpc };
    IIGVerifyCaseClassFactsMore_MixFacts_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseClassFactsMore_MixFacts_Msg *         message = rpc.message;
    const IIGVerifyCaseClassFactsMore_MixFacts_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseClassFactsMore_MixFacts_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSObject * object;

    if (3 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseClassFactsMore_MixFacts_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseClassFactsMore_MixFacts_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(serializableOut)) != NULL && OSDynamicCast(IIGVerifyClassFactsSerializable, (OSObject *) MESSAGE_CONTENT(serializableOut)) == NULL) { return kIOReturnBadArgument; } 
    object = OSDynamicCast(OSObject, (OSObject *) MESSAGE_CONTENT(object));
    if (!object && MESSAGE_CONTENT(object)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        object,
        (OSObject **)&reply->content.objectOut,
        &MESSAGE_CONTENT(constObject),
        MESSAGE_CONTENT(serializableOut),
        &MESSAGE_CONTENT(serializableIn),
        &reply->content.structOut,
        &MESSAGE_CONTENT(structIn));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseClassFactsMore_MixFacts_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseClassFactsMore_MixFacts_Rpl_ObjRefs;
    reply->objectOut__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}



