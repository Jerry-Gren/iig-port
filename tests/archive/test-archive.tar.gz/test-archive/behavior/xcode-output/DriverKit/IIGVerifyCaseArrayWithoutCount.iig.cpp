/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseArrayWithoutCount.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseArrayWithoutCount.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseArrayWithoutCount.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[4];
};
#pragma pack(4)
struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_ObjRefs (1)

struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Invocation;
struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[2];
};
#pragma pack(4)
struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[2];
};
struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[2];
    IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_ObjRefs (3)

struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseArrayWithoutCount_QueueNames  ""

#define IIGVerifyCaseArrayWithoutCount_MethodNames  ""

#define IIGVerifyCaseArrayWithoutCountMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseArrayWithoutCount_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseArrayWithoutCount_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseArrayWithoutCountMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t
OSClassDescription_IIGVerifyCaseArrayWithoutCount =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseArrayWithoutCount_t),
        .name                    = "IIGVerifyCaseArrayWithoutCount",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseArrayWithoutCount_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseArrayWithoutCount_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseArrayWithoutCountMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArrayWithoutCount_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseArrayWithoutCount_QueueNames,
    .methodNames     = IIGVerifyCaseArrayWithoutCount_MethodNames,
    .metaMethodNames = IIGVerifyCaseArrayWithoutCountMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseArrayWithoutCountMetaClass;

static kern_return_t
IIGVerifyCaseArrayWithoutCount_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseArrayWithoutCount_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseArrayWithoutCount.base,
    .metaPointer       = &gIIGVerifyCaseArrayWithoutCountMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseArrayWithoutCount),

    .resv2             = {0},

    .New               = &IIGVerifyCaseArrayWithoutCount_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseArrayWithoutCount_Declaration;
const void * const
gIIGVerifyCaseArrayWithoutCount_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseArrayWithoutCount_Class;

static kern_return_t
IIGVerifyCaseArrayWithoutCount_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseArrayWithoutCountMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseArrayWithoutCountMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseArrayWithoutCount) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseArrayWithoutCount::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseArrayWithoutCount::_Dispatch(IIGVerifyCaseArrayWithoutCount * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_ID:
        {
            ret = IIGVerifyCaseArrayWithoutCount::InlineInputNoCount_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseArrayWithoutCount::InlineInputNoCount_Handler, *self, &IIGVerifyCaseArrayWithoutCount::InlineInputNoCount_Impl));
            break;
        }
        case IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_ID:
        {
            ret = IIGVerifyCaseArrayWithoutCount::ObjectInputNoCount_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseArrayWithoutCount::ObjectInputNoCount_Handler, *self, &IIGVerifyCaseArrayWithoutCount::ObjectInputNoCount_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseArrayWithoutCount::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseArrayWithoutCountMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseArrayWithoutCount::InlineInputNoCount(
        const unsigned char * bytes,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseArrayWithoutCount::ObjectInputNoCount(
        OSObject ** const objects,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 3;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 2; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseArrayWithoutCount::InlineInputNoCount_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineInputNoCount_Handler func)
{
    IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Invocation rpc = { _rpc };
    IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg *         message = rpc.message;
    const IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseArrayWithoutCount::ObjectInputNoCount_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ObjectInputNoCount_Handler func)
{
    IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Invocation rpc = { _rpc };
    IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg *         message = rpc.message;
    const IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    OSObject * objects[2] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */

    if (3 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (OSObject *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (OSObject **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(OSObject, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        objects);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Rpl_ObjRefs;

    return (ret);
}



