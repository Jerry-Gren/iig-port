/* iig(DriverKit-440) generated from IIGVerifyCaseTypedefScalarMore.iig */

/* IIGVerifyCaseTypedefScalarMore.iig:1-12 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASETYPEDEFSCALARMORE_H
#define _DRIVERKIT_IIGVerifyCASETYPEDEFSCALARMORE_H

typedef uint32_t IIGVerifyAliasU32;
typedef IIGVerifyAliasU32 IIGVerifyAliasU32B;
typedef int64_t IIGVerifyAliasI64;
typedef IIGVerifyAliasI64 IIGVerifyAliasI64B;
typedef size_t IIGVerifyAliasSize;
typedef uintptr_t IIGVerifyAliasPointer;

/* source class IIGVerifyCaseTypedefScalarMore IIGVerifyCaseTypedefScalarMore.iig:13-32 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseTypedefScalarMore : public OSObject
{
public:
	virtual kern_return_t
	OutputAliases(IIGVerifyAliasU32B * word,
	    IIGVerifyAliasI64B * wide,
	    IIGVerifyAliasSize * size,
	    IIGVerifyAliasPointer * pointer) LOCAL;

	virtual kern_return_t
	InputAliases(IIGVerifyAliasU32B word,
	    IIGVerifyAliasI64B wide,
	    IIGVerifyAliasSize size,
	    IIGVerifyAliasPointer pointer) LOCAL;

	virtual kern_return_t
	ConstPointerAliases(const IIGVerifyAliasU32B * word,
	    const IIGVerifyAliasI64B * wide,
	    const IIGVerifyAliasSize * size,
	    const IIGVerifyAliasPointer * pointer) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseTypedefScalarMore IIGVerifyCaseTypedefScalarMore.iig:13-32 */

#define IIGVerifyCaseTypedefScalarMore_OutputAliases_ID            0xa094d0aa06355697ULL
#define IIGVerifyCaseTypedefScalarMore_InputAliases_ID            0xda0e4644041409d9ULL
#define IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_ID            0xbe2d1f7f5956273aULL

#define IIGVerifyCaseTypedefScalarMore_OutputAliases_Args \
        IIGVerifyAliasU32B * word, \
        IIGVerifyAliasI64B * wide, \
        IIGVerifyAliasSize * size, \
        IIGVerifyAliasPointer * pointer

#define IIGVerifyCaseTypedefScalarMore_InputAliases_Args \
        IIGVerifyAliasU32B word, \
        IIGVerifyAliasI64B wide, \
        IIGVerifyAliasSize size, \
        IIGVerifyAliasPointer pointer

#define IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Args \
        const IIGVerifyAliasU32B * word, \
        const IIGVerifyAliasI64B * wide, \
        const IIGVerifyAliasSize * size, \
        const IIGVerifyAliasPointer * pointer

#define IIGVerifyCaseTypedefScalarMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseTypedefScalarMore * self, const IORPC rpc);\
\
    kern_return_t\
    OutputAliases(\
        IIGVerifyAliasU32B * word,\
        IIGVerifyAliasI64B * wide,\
        IIGVerifyAliasSize * size,\
        IIGVerifyAliasPointer * pointer,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputAliases(\
        IIGVerifyAliasU32B word,\
        IIGVerifyAliasI64B wide,\
        IIGVerifyAliasSize size,\
        IIGVerifyAliasPointer pointer,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ConstPointerAliases(\
        const IIGVerifyAliasU32B * word,\
        const IIGVerifyAliasI64B * wide,\
        const IIGVerifyAliasSize * size,\
        const IIGVerifyAliasPointer * pointer,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    OutputAliases_Impl(IIGVerifyCaseTypedefScalarMore_OutputAliases_Args);\
\
    kern_return_t\
    InputAliases_Impl(IIGVerifyCaseTypedefScalarMore_InputAliases_Args);\
\
    kern_return_t\
    ConstPointerAliases_Impl(IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*OutputAliases_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefScalarMore_OutputAliases_Args);\
    static kern_return_t\
    OutputAliases_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputAliases_Handler func);\
\
    typedef kern_return_t (*InputAliases_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefScalarMore_InputAliases_Args);\
    static kern_return_t\
    InputAliases_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputAliases_Handler func);\
\
    typedef kern_return_t (*ConstPointerAliases_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Args);\
    static kern_return_t\
    ConstPointerAliases_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstPointerAliases_Handler func);\
\


#define IIGVerifyCaseTypedefScalarMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseTypedefScalarMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseTypedefScalarMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseTypedefScalarMore_Class;

class IIGVerifyCaseTypedefScalarMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseTypedefScalarMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseTypedefScalarMore_IVars;
struct IIGVerifyCaseTypedefScalarMore_LocalIVars;

class IIGVerifyCaseTypedefScalarMore : public OSObject, public IIGVerifyCaseTypedefScalarMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseTypedefScalarMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseTypedefScalarMore_DECLARE_IVARS
IIGVerifyCaseTypedefScalarMore_DECLARE_IVARS
#else /* IIGVerifyCaseTypedefScalarMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseTypedefScalarMore_IVars * ivars;
        IIGVerifyCaseTypedefScalarMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseTypedefScalarMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseTypedefScalarMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseTypedefScalarMore_Methods
    IIGVerifyCaseTypedefScalarMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseTypedefScalarMore.iig:34- */

#endif /* _DRIVERKIT_IIGVerifyCASETYPEDEFSCALARMORE_H */
