/* iig(DriverKit-440) generated from IIGVerifyCaseRetainedPrefixEdgesMore.iig */

/* IIGVerifyCaseRetainedPrefixEdgesMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASERETAINEDPREFIXEDGESMORE_H
#define _DRIVERKIT_IIGVerifyCASERETAINEDPREFIXEDGESMORE_H

/* source class IIGVerifyRetainedPrefixSerializable IIGVerifyCaseRetainedPrefixEdgesMore.iig:6-7 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class IIG_SERIALIZABLE IIGVerifyRetainedPrefixSerializable : public OSObject
{
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyRetainedPrefixSerializable IIGVerifyCaseRetainedPrefixEdgesMore.iig:6-7 */


#define IIGVerifyRetainedPrefixSerializable_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyRetainedPrefixSerializable * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyRetainedPrefixSerializable_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyRetainedPrefixSerializable_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyRetainedPrefixSerializableMetaClass;
extern const OSClassLoadInformation IIGVerifyRetainedPrefixSerializable_Class;

class IIGVerifyRetainedPrefixSerializableMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyRetainedPrefixSerializableInterface : public OSInterface
{
public:
};

struct IIGVerifyRetainedPrefixSerializable_IVars;
struct IIGVerifyRetainedPrefixSerializable_LocalIVars;

class IIGVerifyRetainedPrefixSerializable : public OSObject, public IIGVerifyRetainedPrefixSerializableInterface
{
#if !KERNEL
    friend class IIGVerifyRetainedPrefixSerializableMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyRetainedPrefixSerializable_DECLARE_IVARS
IIGVerifyRetainedPrefixSerializable_DECLARE_IVARS
#else /* IIGVerifyRetainedPrefixSerializable_DECLARE_IVARS */
    union
    {
        IIGVerifyRetainedPrefixSerializable_IVars * ivars;
        IIGVerifyRetainedPrefixSerializable_LocalIVars * lvars;
    };
#endif /* IIGVerifyRetainedPrefixSerializable_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyRetainedPrefixSerializableMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyRetainedPrefixSerializable_Methods
    IIGVerifyRetainedPrefixSerializable_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseRetainedPrefixEdgesMore.iig:9-13 */

typedef OSObject * IIGVerifyRetainedObjectAlias;
typedef IIGVerifyRetainedObjectAlias * IIGVerifyRetainedObjectOutAlias;
typedef IIGVerifyRetainedPrefixSerializable * IIGVerifyRetainedSerializableAlias;

/* source class IIGVerifyCaseRetainedPrefixEdgesMore IIGVerifyCaseRetainedPrefixEdgesMore.iig:14-30 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseRetainedPrefixEdgesMore : public OSObject
{
public:
	virtual kern_return_t
	GETObject(OSObject ** object) LOCAL;

	virtual kern_return_t
	GetterObject(OSObject ** object) LOCAL;

	virtual kern_return_t
	ForgetObject(OSObject ** object) LOCAL;

	virtual kern_return_t
	GetAlias(IIGVerifyRetainedObjectOutAlias object) LOCAL;

	virtual kern_return_t
	GetSerializable(IIGVerifyRetainedSerializableAlias * object) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseRetainedPrefixEdgesMore IIGVerifyCaseRetainedPrefixEdgesMore.iig:14-30 */

#define IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_ID            0x89e254cddb34c172ULL
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_ID            0xa2ae5b7b0e9efb16ULL
#define IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_ID            0x80f78c8188a7ccc8ULL
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_ID            0x8474708210ebe8deULL
#define IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_ID            0xe4f3eed24d39946bULL

#define IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Args \
        OSObject ** object

#define IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Args \
        OSObject ** object

#define IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Args \
        OSObject ** object

#define IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Args \
        IIGVerifyRetainedObjectOutAlias object

#define IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Args \
        IIGVerifyRetainedSerializableAlias * object

#define IIGVerifyCaseRetainedPrefixEdgesMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseRetainedPrefixEdgesMore * self, const IORPC rpc);\
\
    kern_return_t\
    GETObject(\
        OSObject ** object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    GetterObject(\
        __attribute__((os_returns_retained)) OSObject ** object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ForgetObject(\
        OSObject ** object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    GetAlias(\
        __attribute__((os_returns_retained)) IIGVerifyRetainedObjectOutAlias object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    GetSerializable(\
        IIGVerifyRetainedSerializableAlias * object,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    GETObject_Impl(IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Args);\
\
    kern_return_t\
    GetterObject_Impl(IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Args);\
\
    kern_return_t\
    ForgetObject_Impl(IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Args);\
\
    kern_return_t\
    GetAlias_Impl(IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Args);\
\
    kern_return_t\
    GetSerializable_Impl(IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*GETObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixEdgesMore_GETObject_Args);\
    static kern_return_t\
    GETObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        GETObject_Handler func);\
\
    typedef kern_return_t (*GetterObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixEdgesMore_GetterObject_Args);\
    static kern_return_t\
    GetterObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        GetterObject_Handler func);\
\
    typedef kern_return_t (*ForgetObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixEdgesMore_ForgetObject_Args);\
    static kern_return_t\
    ForgetObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ForgetObject_Handler func);\
\
    typedef kern_return_t (*GetAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixEdgesMore_GetAlias_Args);\
    static kern_return_t\
    GetAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        GetAlias_Handler func);\
\
    typedef kern_return_t (*GetSerializable_Handler)(OSMetaClassBase * target, IIGVerifyCaseRetainedPrefixEdgesMore_GetSerializable_Args);\
    static kern_return_t\
    GetSerializable_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        GetSerializable_Handler func);\
\


#define IIGVerifyCaseRetainedPrefixEdgesMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseRetainedPrefixEdgesMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseRetainedPrefixEdgesMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseRetainedPrefixEdgesMore_Class;

class IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseRetainedPrefixEdgesMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseRetainedPrefixEdgesMore_IVars;
struct IIGVerifyCaseRetainedPrefixEdgesMore_LocalIVars;

class IIGVerifyCaseRetainedPrefixEdgesMore : public OSObject, public IIGVerifyCaseRetainedPrefixEdgesMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseRetainedPrefixEdgesMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseRetainedPrefixEdgesMore_DECLARE_IVARS
IIGVerifyCaseRetainedPrefixEdgesMore_DECLARE_IVARS
#else /* IIGVerifyCaseRetainedPrefixEdgesMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseRetainedPrefixEdgesMore_IVars * ivars;
        IIGVerifyCaseRetainedPrefixEdgesMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseRetainedPrefixEdgesMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseRetainedPrefixEdgesMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseRetainedPrefixEdgesMore_Methods
    IIGVerifyCaseRetainedPrefixEdgesMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseRetainedPrefixEdgesMore.iig:32- */

#endif /* _DRIVERKIT_IIGVerifyCASERETAINEDPREFIXEDGESMORE_H */
