/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseStructAliasMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseStructAliasMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseStructAliasMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseStructAliasMore_InputAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyAliasStruct  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructAliasMore_InputAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructAliasMore_InputAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructAliasMore_InputAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructAliasMore_InputAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseStructAliasMore_InputAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructAliasMore_InputAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructAliasMore_InputAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructAliasMore_InputAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructAliasMore_InputAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructAliasMore_InputAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructAliasMore_InputAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructAliasMore_InputAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructAliasMore_InputAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructAliasMore_InputAlias_Invocation;
struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructAliasMore_OutputAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructAliasMore_OutputAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyAliasStruct  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructAliasMore_OutputAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructAliasMore_OutputAlias_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseStructAliasMore_QueueNames  ""

#define IIGVerifyCaseStructAliasMore_MethodNames  ""

#define IIGVerifyCaseStructAliasMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseStructAliasMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseStructAliasMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseStructAliasMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseStructAliasMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseStructAliasMore_t
OSClassDescription_IIGVerifyCaseStructAliasMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseStructAliasMore_t),
        .name                    = "IIGVerifyCaseStructAliasMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructAliasMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructAliasMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseStructAliasMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructAliasMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseStructAliasMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructAliasMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseStructAliasMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructAliasMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseStructAliasMore_QueueNames,
    .methodNames     = IIGVerifyCaseStructAliasMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseStructAliasMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseStructAliasMoreMetaClass;

static kern_return_t
IIGVerifyCaseStructAliasMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseStructAliasMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseStructAliasMore.base,
    .metaPointer       = &gIIGVerifyCaseStructAliasMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseStructAliasMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseStructAliasMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseStructAliasMore_Declaration;
const void * const
gIIGVerifyCaseStructAliasMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseStructAliasMore_Class;

static kern_return_t
IIGVerifyCaseStructAliasMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseStructAliasMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStructAliasMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseStructAliasMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseStructAliasMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseStructAliasMore::_Dispatch(IIGVerifyCaseStructAliasMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseStructAliasMore_InputAlias_ID:
        {
            ret = IIGVerifyCaseStructAliasMore::InputAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructAliasMore::InputAlias_Handler, *self, &IIGVerifyCaseStructAliasMore::InputAlias_Impl));
            break;
        }
        case IIGVerifyCaseStructAliasMore_OutputAlias_ID:
        {
            ret = IIGVerifyCaseStructAliasMore::OutputAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructAliasMore::OutputAlias_Handler, *self, &IIGVerifyCaseStructAliasMore::OutputAlias_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseStructAliasMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseStructAliasMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseStructAliasMore::InputAlias(
        IIGVerifyAliasStructIn value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructAliasMore_InputAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructAliasMore_InputAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructAliasMore_InputAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructAliasMore_InputAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructAliasMore_InputAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructAliasMore_InputAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructAliasMore_InputAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructAliasMore_InputAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructAliasMore::OutputAlias(
        IIGVerifyAliasStructOut value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructAliasMore_OutputAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructAliasMore_OutputAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructAliasMore_OutputAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructAliasMore_OutputAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructAliasMore_OutputAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (value) *value = rpl->content.value;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructAliasMore::InputAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputAlias_Handler func)
{
    IIGVerifyCaseStructAliasMore_InputAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseStructAliasMore_InputAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructAliasMore_InputAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseStructAliasMore_InputAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructAliasMore_InputAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructAliasMore_InputAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructAliasMore_InputAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructAliasMore_InputAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructAliasMore_InputAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructAliasMore::OutputAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputAlias_Handler func)
{
    IIGVerifyCaseStructAliasMore_OutputAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructAliasMore_OutputAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseStructAliasMore_OutputAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructAliasMore_OutputAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructAliasMore_OutputAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructAliasMore_OutputAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.value);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructAliasMore_OutputAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructAliasMore_OutputAlias_Rpl_ObjRefs;

    return (ret);
}



