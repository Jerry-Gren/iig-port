/* iig(DriverKit-440) generated from IIGVerifyCaseScalarSpellingsMore.iig */

/* IIGVerifyCaseScalarSpellingsMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESCALARSPELLINGSMORE_H
#define _DRIVERKIT_IIGVerifyCASESCALARSPELLINGSMORE_H

/* source class IIGVerifyCaseScalarSpellingsMore IIGVerifyCaseScalarSpellingsMore.iig:6-24 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseScalarSpellingsMore : public OSObject
{
public:
	virtual kern_return_t
	OutputSigned(int8_t * byte,
	    int16_t * half,
	    int32_t * word,
	    int64_t * wide) LOCAL;

	virtual kern_return_t
	OutputNative(size_t * size,
	    uintptr_t * pointer,
	    bool * flag) LOCAL;

	virtual kern_return_t
	InputSigned(int8_t byte,
	    int16_t half,
	    int32_t word,
	    int64_t wide) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseScalarSpellingsMore IIGVerifyCaseScalarSpellingsMore.iig:6-24 */

#define IIGVerifyCaseScalarSpellingsMore_OutputSigned_ID            0xbfdc9ab89842924aULL
#define IIGVerifyCaseScalarSpellingsMore_OutputNative_ID            0xe8080ba1cd4961eeULL
#define IIGVerifyCaseScalarSpellingsMore_InputSigned_ID            0x9b499ad1718a76deULL

#define IIGVerifyCaseScalarSpellingsMore_OutputSigned_Args \
        int8_t * byte, \
        int16_t * half, \
        int32_t * word, \
        int64_t * wide

#define IIGVerifyCaseScalarSpellingsMore_OutputNative_Args \
        size_t * size, \
        uintptr_t * pointer, \
        bool * flag

#define IIGVerifyCaseScalarSpellingsMore_InputSigned_Args \
        int8_t byte, \
        int16_t half, \
        int32_t word, \
        int64_t wide

#define IIGVerifyCaseScalarSpellingsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseScalarSpellingsMore * self, const IORPC rpc);\
\
    kern_return_t\
    OutputSigned(\
        int8_t * byte,\
        int16_t * half,\
        int32_t * word,\
        int64_t * wide,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputNative(\
        size_t * size,\
        uintptr_t * pointer,\
        bool * flag,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputSigned(\
        int8_t byte,\
        int16_t half,\
        int32_t word,\
        int64_t wide,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    OutputSigned_Impl(IIGVerifyCaseScalarSpellingsMore_OutputSigned_Args);\
\
    kern_return_t\
    OutputNative_Impl(IIGVerifyCaseScalarSpellingsMore_OutputNative_Args);\
\
    kern_return_t\
    InputSigned_Impl(IIGVerifyCaseScalarSpellingsMore_InputSigned_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*OutputSigned_Handler)(OSMetaClassBase * target, IIGVerifyCaseScalarSpellingsMore_OutputSigned_Args);\
    static kern_return_t\
    OutputSigned_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputSigned_Handler func);\
\
    typedef kern_return_t (*OutputNative_Handler)(OSMetaClassBase * target, IIGVerifyCaseScalarSpellingsMore_OutputNative_Args);\
    static kern_return_t\
    OutputNative_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputNative_Handler func);\
\
    typedef kern_return_t (*InputSigned_Handler)(OSMetaClassBase * target, IIGVerifyCaseScalarSpellingsMore_InputSigned_Args);\
    static kern_return_t\
    InputSigned_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputSigned_Handler func);\
\


#define IIGVerifyCaseScalarSpellingsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseScalarSpellingsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseScalarSpellingsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseScalarSpellingsMore_Class;

class IIGVerifyCaseScalarSpellingsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseScalarSpellingsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseScalarSpellingsMore_IVars;
struct IIGVerifyCaseScalarSpellingsMore_LocalIVars;

class IIGVerifyCaseScalarSpellingsMore : public OSObject, public IIGVerifyCaseScalarSpellingsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseScalarSpellingsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseScalarSpellingsMore_DECLARE_IVARS
IIGVerifyCaseScalarSpellingsMore_DECLARE_IVARS
#else /* IIGVerifyCaseScalarSpellingsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseScalarSpellingsMore_IVars * ivars;
        IIGVerifyCaseScalarSpellingsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseScalarSpellingsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseScalarSpellingsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseScalarSpellingsMore_Methods
    IIGVerifyCaseScalarSpellingsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseScalarSpellingsMore.iig:26- */

#endif /* _DRIVERKIT_IIGVerifyCASESCALARSPELLINGSMORE_H */
