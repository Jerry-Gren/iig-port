/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseObjectArrays.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseObjectArrays.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseObjectArrays.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseObjectArrays_InputObjects_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[4];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrays_InputObjects_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[4];
};
struct IIGVerifyCaseObjectArrays_InputObjects_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[4];
    IIGVerifyCaseObjectArrays_InputObjects_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrays_InputObjects_Msg_ObjRefs (5)

struct IIGVerifyCaseObjectArrays_InputObjects_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrays_InputObjects_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseObjectArrays_InputObjects_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseObjectArrays_InputObjects_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrays_InputObjects_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrays_InputObjects_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrays_InputObjects_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrays_InputObjects_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrays_InputObjects_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrays_InputObjects_Invocation;
struct IIGVerifyCaseObjectArrays_InputBuffers_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __buffers[2];
    uint32_t  buffersCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrays_InputBuffers_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t buffers__descriptor[2];
};
struct IIGVerifyCaseObjectArrays_InputBuffers_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t buffers__descriptor[2];
    IIGVerifyCaseObjectArrays_InputBuffers_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrays_InputBuffers_Msg_ObjRefs (3)

struct IIGVerifyCaseObjectArrays_InputBuffers_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  output;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrays_InputBuffers_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t output__descriptor;
};
struct IIGVerifyCaseObjectArrays_InputBuffers_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t output__descriptor;
    IIGVerifyCaseObjectArrays_InputBuffers_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrays_InputBuffers_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrays_InputBuffers_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrays_InputBuffers_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrays_InputBuffers_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrays_InputBuffers_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrays_InputBuffers_Invocation;
struct IIGVerifyCaseObjectArrays_SerializableArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSDictionary * dictionaries;
#if !defined(__LP64__)
    uint32_t __dictionariesPad;
#endif /* !defined(__LP64__) */
    uint32_t  dictionariesCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrays_SerializableArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  dictionaries__descriptor;
};
struct IIGVerifyCaseObjectArrays_SerializableArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  dictionaries__descriptor;
    IIGVerifyCaseObjectArrays_SerializableArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrays_SerializableArray_Msg_ObjRefs (2)

struct IIGVerifyCaseObjectArrays_SerializableArray_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrays_SerializableArray_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseObjectArrays_SerializableArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseObjectArrays_SerializableArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrays_SerializableArray_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrays_SerializableArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrays_SerializableArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrays_SerializableArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrays_SerializableArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrays_SerializableArray_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gIOServiceMetaClass;
extern OSMetaClass * gIOMemoryMapMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseObjectArrays_QueueNames  ""

#define IIGVerifyCaseObjectArrays_MethodNames  ""

#define IIGVerifyCaseObjectArraysMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseObjectArrays_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseObjectArrays_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseObjectArrays_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseObjectArraysMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseObjectArrays_t
OSClassDescription_IIGVerifyCaseObjectArrays =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseObjectArrays_t),
        .name                    = "IIGVerifyCaseObjectArrays",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrays_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrays_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseObjectArrays_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrays_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseObjectArrays_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrays_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseObjectArraysMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrays_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseObjectArrays_QueueNames,
    .methodNames     = IIGVerifyCaseObjectArrays_MethodNames,
    .metaMethodNames = IIGVerifyCaseObjectArraysMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseObjectArraysMetaClass;

static kern_return_t
IIGVerifyCaseObjectArrays_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseObjectArrays_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseObjectArrays.base,
    .metaPointer       = &gIIGVerifyCaseObjectArraysMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseObjectArrays),

    .resv2             = {0},

    .New               = &IIGVerifyCaseObjectArrays_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseObjectArrays_Declaration;
const void * const
gIIGVerifyCaseObjectArrays_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseObjectArrays_Class;

static kern_return_t
IIGVerifyCaseObjectArrays_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseObjectArraysMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseObjectArraysMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseObjectArrays) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseObjectArrays::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseObjectArrays::_Dispatch(IIGVerifyCaseObjectArrays * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseObjectArrays_InputObjects_ID:
        {
            ret = IIGVerifyCaseObjectArrays::InputObjects_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrays::InputObjects_Handler, *self, &IIGVerifyCaseObjectArrays::InputObjects_Impl));
            break;
        }
        case IIGVerifyCaseObjectArrays_InputBuffers_ID:
        {
            ret = IIGVerifyCaseObjectArrays::InputBuffers_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrays::InputBuffers_Handler, *self, &IIGVerifyCaseObjectArrays::InputBuffers_Impl));
            break;
        }
        case IIGVerifyCaseObjectArrays_SerializableArray_ID:
        {
            ret = IIGVerifyCaseObjectArrays::SerializableArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrays::SerializableArray_Handler, *self, &IIGVerifyCaseObjectArrays::SerializableArray_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseObjectArrays::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseObjectArraysMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrays::InputObjects(
        OSObject ** const objects,
        uint32_t objectsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrays_InputObjects_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrays_InputObjects_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrays_InputObjects_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrays_InputObjects_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrays_InputObjects_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrays_InputObjects_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 5;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 4; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

    msg->content.objectsCount = objectsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrays_InputObjects_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrays_InputObjects_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrays::InputBuffers(
        IOBufferMemoryDescriptor ** const buffers,
        uint32_t buffersCount,
        OSObject ** output,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrays_InputBuffers_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrays_InputBuffers_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrays_InputBuffers_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrays_InputBuffers_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrays_InputBuffers_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrays_InputBuffers_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 3;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 2; idx++) msg->buffers__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (buffersCount > (sizeof(msg->content.__buffers) / sizeof(msg->content.__buffers[0]))) return kIOReturnOverrun;
    bcopy(buffers, &msg->content.__buffers[0], buffersCount * sizeof(msg->content.__buffers[0]));

    msg->content.buffersCount = buffersCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrays_InputBuffers_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrays_InputBuffers_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *output = OSDynamicCast(OSObject, (OSObject *) rpl->content.output);
        if (rpl->content.output && !*output) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrays::SerializableArray(
        const OSDictionary * dictionaries,
        uint32_t dictionariesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrays_SerializableArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrays_SerializableArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrays_SerializableArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrays_SerializableArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrays_SerializableArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrays_SerializableArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->dictionaries__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->dictionaries__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->dictionaries__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseObjectArrays_SerializableArray_Msg_Content, dictionaries);
    msg->content.dictionaries = dictionaries;

    if (dictionariesCount > (sizeof(msg->content.__dictionaries) / sizeof(msg->content.__dictionaries[0]))) return kIOReturnOverrun;
    bcopy(dictionaries, &msg->content.__dictionaries[0], dictionariesCount * sizeof(msg->content.__dictionaries[0]));

    msg->content.dictionariesCount = dictionariesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrays_SerializableArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrays_SerializableArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrays::InputObjects_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputObjects_Handler func)
{
    IIGVerifyCaseObjectArrays_InputObjects_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrays_InputObjects_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrays_InputObjects_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrays_InputObjects_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrays_InputObjects_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    OSObject * objects[4] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop

    if (5 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrays_InputObjects_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrays_InputObjects_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (OSObject *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (OSObject **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(OSObject, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        objects,
        objectsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrays_InputObjects_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrays_InputObjects_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrays::InputBuffers_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputBuffers_Handler func)
{
    IIGVerifyCaseObjectArrays_InputBuffers_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrays_InputBuffers_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrays_InputBuffers_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrays_InputBuffers_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrays_InputBuffers_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    IOBufferMemoryDescriptor * buffers[2] = {};
#else /* !__LP64__ */
    IOBufferMemoryDescriptor ** buffers;
#endif /* __LP64__ */
    uint32_t buffersCount = (sizeof(MESSAGE_CONTENT(__buffers)) / sizeof(MESSAGE_CONTENT(__buffers[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(buffersCount) >= 0 && buffersCount > MESSAGE_CONTENT(buffersCount)) buffersCount = MESSAGE_CONTENT(buffersCount);
#pragma clang diagnostic pop

    if (3 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrays_InputBuffers_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrays_InputBuffers_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < buffersCount; idx++)
    {
        buffers[idx] = (IOBufferMemoryDescriptor *)(uintptr_t)MESSAGE_CONTENT(__buffers[idx]);
    }
#else /* !__LP64__ */
    buffers = (IOBufferMemoryDescriptor **)(uintptr_t) &MESSAGE_CONTENT(__buffers[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < buffersCount; idx++)
    {
        if (buffers[idx] && !OSDynamicCast(IOBufferMemoryDescriptor, buffers[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        buffers,
        buffersCount,
        (OSObject **)&reply->content.output);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrays_InputBuffers_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrays_InputBuffers_Rpl_ObjRefs;
    reply->output__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrays::SerializableArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SerializableArray_Handler func)
{
    IIGVerifyCaseObjectArrays_SerializableArray_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrays_SerializableArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrays_SerializableArray_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrays_SerializableArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrays_SerializableArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t dictionariesCount = (sizeof(MESSAGE_CONTENT(__dictionaries)) / sizeof(MESSAGE_CONTENT(__dictionaries[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(dictionariesCount) >= 0 && dictionariesCount > MESSAGE_CONTENT(dictionariesCount)) dictionariesCount = MESSAGE_CONTENT(dictionariesCount);
#pragma clang diagnostic pop

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrays_SerializableArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrays_SerializableArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(dictionaries)) != NULL && OSDynamicCast(OSDictionary, (OSObject *) MESSAGE_CONTENT(dictionaries)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        MESSAGE_CONTENT(dictionaries),
        dictionariesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrays_SerializableArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrays_SerializableArray_Rpl_ObjRefs;

    return (ret);
}



