/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseIntegerExpressionsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseIntegerExpressionsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseIntegerExpressionsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[6];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Invocation;
struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[4];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Invocation;
struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[8];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerExpressionsMore_InlineParens_Invocation;
struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[6];
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Invocation;
struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[5];
};
#pragma pack(4)
struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseIntegerExpressionsMore_QueueNames  ""

#define IIGVerifyCaseIntegerExpressionsMore_MethodNames  ""

#define IIGVerifyCaseIntegerExpressionsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseIntegerExpressionsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseIntegerExpressionsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseIntegerExpressionsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t
OSClassDescription_IIGVerifyCaseIntegerExpressionsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t),
        .name                    = "IIGVerifyCaseIntegerExpressionsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseIntegerExpressionsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseIntegerExpressionsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseIntegerExpressionsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerExpressionsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseIntegerExpressionsMore_QueueNames,
    .methodNames     = IIGVerifyCaseIntegerExpressionsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseIntegerExpressionsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseIntegerExpressionsMoreMetaClass;

static kern_return_t
IIGVerifyCaseIntegerExpressionsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseIntegerExpressionsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseIntegerExpressionsMore.base,
    .metaPointer       = &gIIGVerifyCaseIntegerExpressionsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseIntegerExpressionsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseIntegerExpressionsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseIntegerExpressionsMore_Declaration;
const void * const
gIIGVerifyCaseIntegerExpressionsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseIntegerExpressionsMore_Class;

static kern_return_t
IIGVerifyCaseIntegerExpressionsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseIntegerExpressionsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseIntegerExpressionsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::_Dispatch(IIGVerifyCaseIntegerExpressionsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseIntegerExpressionsMore_InlineProduct_ID:
        {
            ret = IIGVerifyCaseIntegerExpressionsMore::InlineProduct_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerExpressionsMore::InlineProduct_Handler, *self, &IIGVerifyCaseIntegerExpressionsMore::InlineProduct_Impl));
            break;
        }
        case IIGVerifyCaseIntegerExpressionsMore_InlineDifference_ID:
        {
            ret = IIGVerifyCaseIntegerExpressionsMore::InlineDifference_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerExpressionsMore::InlineDifference_Handler, *self, &IIGVerifyCaseIntegerExpressionsMore::InlineDifference_Impl));
            break;
        }
        case IIGVerifyCaseIntegerExpressionsMore_InlineParens_ID:
        {
            ret = IIGVerifyCaseIntegerExpressionsMore::InlineParens_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerExpressionsMore::InlineParens_Handler, *self, &IIGVerifyCaseIntegerExpressionsMore::InlineParens_Impl));
            break;
        }
        case IIGVerifyCaseIntegerExpressionsMore_OutputProduct_ID:
        {
            ret = IIGVerifyCaseIntegerExpressionsMore::OutputProduct_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerExpressionsMore::OutputProduct_Handler, *self, &IIGVerifyCaseIntegerExpressionsMore::OutputProduct_Impl));
            break;
        }
        case IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_ID:
        {
            ret = IIGVerifyCaseIntegerExpressionsMore::OutputEnumMinus_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerExpressionsMore::OutputEnumMinus_Handler, *self, &IIGVerifyCaseIntegerExpressionsMore::OutputEnumMinus_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseIntegerExpressionsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseIntegerExpressionsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::InlineProduct(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_InlineProduct_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerExpressionsMore_InlineProduct_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::InlineDifference(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_InlineDifference_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerExpressionsMore_InlineDifference_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::InlineParens(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_InlineParens_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerExpressionsMore_InlineParens_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::OutputProduct(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_OutputProduct_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerExpressionsMore_OutputProduct_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::OutputEnumMinus(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::InlineProduct_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineProduct_Handler func)
{
    IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_InlineProduct_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_InlineProduct_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::InlineDifference_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineDifference_Handler func)
{
    IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_InlineDifference_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_InlineDifference_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::InlineParens_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineParens_Handler func)
{
    IIGVerifyCaseIntegerExpressionsMore_InlineParens_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerExpressionsMore_InlineParens_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_InlineParens_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_InlineParens_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::OutputProduct_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputProduct_Handler func)
{
    IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_OutputProduct_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_OutputProduct_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerExpressionsMore::OutputEnumMinus_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputEnumMinus_Handler func)
{
    IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerExpressionsMore_OutputEnumMinus_Rpl_ObjRefs;

    return (ret);
}



