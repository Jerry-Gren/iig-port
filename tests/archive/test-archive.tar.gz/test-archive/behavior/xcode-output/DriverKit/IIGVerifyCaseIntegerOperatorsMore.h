/* iig(DriverKit-440) generated from IIGVerifyCaseIntegerOperatorsMore.iig */

/* IIGVerifyCaseIntegerOperatorsMore.iig:1-19 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEINTEGEROPERATORSMORE_H
#define _DRIVERKIT_IIGVerifyCASEINTEGEROPERATORSMORE_H

#define IIGVerifyCaseIntegerOpsShift (1 << 3)
#define IIGVerifyCaseIntegerOpsDivide (0x18 / 3)
#define IIGVerifyCaseIntegerOpsRemainder (11 % 4)
#define IIGVerifyCaseIntegerOpsBitwise ((1 << 2) | 3)
#define IIGVerifyCaseIntegerOpsAndMask (15 & 6)

enum {
	kIIGVerifyCaseIntegerOpsEnumShift = 1 << 4,
	kIIGVerifyCaseIntegerOpsEnumMixed = (kIIGVerifyCaseIntegerOpsEnumShift >> 2) + 1,
};

typedef uint32_t IIGVerifyCaseIntegerOpsBitwiseWords[IIGVerifyCaseIntegerOpsBitwise];
typedef uint32_t IIGVerifyCaseIntegerOpsEnumWords[kIIGVerifyCaseIntegerOpsEnumMixed];

/* source class IIGVerifyCaseIntegerOperatorsMore IIGVerifyCaseIntegerOperatorsMore.iig:20-45 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseIntegerOperatorsMore : public OSObject
{
public:
	virtual kern_return_t
	InlineShift(const uint8_t bytes[IIGVerifyCaseIntegerOpsShift],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineDivide(const uint8_t bytes[IIGVerifyCaseIntegerOpsDivide],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineRemainder(const uint8_t bytes[IIGVerifyCaseIntegerOpsRemainder],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineAndMask(const uint8_t bytes[IIGVerifyCaseIntegerOpsAndMask],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	OutputBitwise(uint32_t wordsCount,
	    IIGVerifyCaseIntegerOpsBitwiseWords words) LOCAL;

	virtual kern_return_t
	OutputEnumMixed(uint32_t wordsCount,
	    IIGVerifyCaseIntegerOpsEnumWords words) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseIntegerOperatorsMore IIGVerifyCaseIntegerOperatorsMore.iig:20-45 */

#define IIGVerifyCaseIntegerOperatorsMore_InlineShift_ID            0xcd6832678b812b55ULL
#define IIGVerifyCaseIntegerOperatorsMore_InlineDivide_ID            0x8b9b9eb4bc3751d8ULL
#define IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_ID            0xfdd7645766e27754ULL
#define IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_ID            0xf6c1abe2b357bc88ULL
#define IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_ID            0x8804fdda5824a468ULL
#define IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_ID            0x8a9b891d7f4523edULL

#define IIGVerifyCaseIntegerOperatorsMore_InlineShift_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseIntegerOperatorsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseIntegerOperatorsMore * self, const IORPC rpc);\
\
    kern_return_t\
    InlineShift(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineDivide(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineRemainder(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineAndMask(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputBitwise(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputEnumMixed(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InlineShift_Impl(IIGVerifyCaseIntegerOperatorsMore_InlineShift_Args);\
\
    kern_return_t\
    InlineDivide_Impl(IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Args);\
\
    kern_return_t\
    InlineRemainder_Impl(IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Args);\
\
    kern_return_t\
    InlineAndMask_Impl(IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Args);\
\
    kern_return_t\
    OutputBitwise_Impl(IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Args);\
\
    kern_return_t\
    OutputEnumMixed_Impl(IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InlineShift_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerOperatorsMore_InlineShift_Args);\
    static kern_return_t\
    InlineShift_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineShift_Handler func);\
\
    typedef kern_return_t (*InlineDivide_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Args);\
    static kern_return_t\
    InlineDivide_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineDivide_Handler func);\
\
    typedef kern_return_t (*InlineRemainder_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Args);\
    static kern_return_t\
    InlineRemainder_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineRemainder_Handler func);\
\
    typedef kern_return_t (*InlineAndMask_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Args);\
    static kern_return_t\
    InlineAndMask_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineAndMask_Handler func);\
\
    typedef kern_return_t (*OutputBitwise_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Args);\
    static kern_return_t\
    OutputBitwise_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputBitwise_Handler func);\
\
    typedef kern_return_t (*OutputEnumMixed_Handler)(OSMetaClassBase * target, IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Args);\
    static kern_return_t\
    OutputEnumMixed_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputEnumMixed_Handler func);\
\


#define IIGVerifyCaseIntegerOperatorsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseIntegerOperatorsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseIntegerOperatorsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseIntegerOperatorsMore_Class;

class IIGVerifyCaseIntegerOperatorsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseIntegerOperatorsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseIntegerOperatorsMore_IVars;
struct IIGVerifyCaseIntegerOperatorsMore_LocalIVars;

class IIGVerifyCaseIntegerOperatorsMore : public OSObject, public IIGVerifyCaseIntegerOperatorsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseIntegerOperatorsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseIntegerOperatorsMore_DECLARE_IVARS
IIGVerifyCaseIntegerOperatorsMore_DECLARE_IVARS
#else /* IIGVerifyCaseIntegerOperatorsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_IVars * ivars;
        IIGVerifyCaseIntegerOperatorsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseIntegerOperatorsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseIntegerOperatorsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseIntegerOperatorsMore_Methods
    IIGVerifyCaseIntegerOperatorsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseIntegerOperatorsMore.iig:47- */

#endif /* _DRIVERKIT_IIGVerifyCASEINTEGEROPERATORSMORE_H */
