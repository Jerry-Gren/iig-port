/* iig(DriverKit-440) generated from IIGVerifyCaseStaticArrays.iig */

/* IIGVerifyCaseStaticArrays.iig:1-7 */
#include <DriverKit/OSObject.h>  /* .iig include */
#include <DriverKit/IOMemoryDescriptor.h>  /* .iig include */
#include <DriverKit/IOBufferMemoryDescriptor.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESTATICARRAYS_H
#define _DRIVERKIT_IIGVerifyCASESTATICARRAYS_H

/* source class IIGVerifyCaseStaticArrays IIGVerifyCaseStaticArrays.iig:8-22 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseStaticArrays : public OSObject
{
public:
	static kern_return_t
	StaticObjectCountBefore(uint32_t objectsCount,
	    OSObject * const objects[4]) LOCAL;

	static kern_return_t
	StaticDescriptorCountAfter(IOMemoryDescriptor * const descriptors[3],
	    uint32_t descriptorsCount,
	    IOMemoryDescriptor ** memory) LOCAL;

	virtual kern_return_t
	InstanceObjectCountBefore(uint32_t objectsCount,
	    IOBufferMemoryDescriptor * const objects[2]) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseStaticArrays IIGVerifyCaseStaticArrays.iig:8-22 */

#define IIGVerifyCaseStaticArrays_StaticObjectCountBefore_ID            0xea91bac0d8d7abe2ULL
#define IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_ID            0x9831fe55981890e6ULL
#define IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_ID            0xa70bea02c9fc67d9ULL

#define IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Args \
        uint32_t objectsCount, \
        OSObject ** const objects

#define IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Args \
        IOMemoryDescriptor ** const descriptors, \
        uint32_t descriptorsCount, \
        IOMemoryDescriptor ** memory

#define IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Args \
        uint32_t objectsCount, \
        IOBufferMemoryDescriptor ** const objects

#define IIGVerifyCaseStaticArrays_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseStaticArrays * self, const IORPC rpc);\
\
    static kern_return_t\
    StaticObjectCountBefore(\
        uint32_t objectsCount,\
        OSObject ** const objects);\
\
    static kern_return_t\
    StaticDescriptorCountAfter(\
        IOMemoryDescriptor ** const descriptors,\
        uint32_t descriptorsCount,\
        IOMemoryDescriptor ** memory);\
\
    kern_return_t\
    InstanceObjectCountBefore(\
        uint32_t objectsCount,\
        IOBufferMemoryDescriptor ** const objects,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    static kern_return_t\
    StaticObjectCountBefore_Call(IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Args);\
\
    static kern_return_t\
    StaticDescriptorCountAfter_Call(IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Args);\
\
    kern_return_t\
    InstanceObjectCountBefore_Impl(IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*StaticObjectCountBefore_Handler)(IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Args);\
    static kern_return_t\
    StaticObjectCountBefore_Invoke(const IORPC rpc,\
        StaticObjectCountBefore_Handler func);\
\
    typedef kern_return_t (*StaticDescriptorCountAfter_Handler)(IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Args);\
    static kern_return_t\
    StaticDescriptorCountAfter_Invoke(const IORPC rpc,\
        StaticDescriptorCountAfter_Handler func);\
\
    typedef kern_return_t (*InstanceObjectCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Args);\
    static kern_return_t\
    InstanceObjectCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceObjectCountBefore_Handler func);\
\


#define IIGVerifyCaseStaticArrays_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    static kern_return_t\
    StaticObjectCountBefore_Impl(IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Args);\
\
    static kern_return_t\
    StaticDescriptorCountAfter_Impl(IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Args);\
\


#define IIGVerifyCaseStaticArrays_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseStaticArraysMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseStaticArrays_Class;

class IIGVerifyCaseStaticArraysMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseStaticArraysInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseStaticArrays_IVars;
struct IIGVerifyCaseStaticArrays_LocalIVars;

class IIGVerifyCaseStaticArrays : public OSObject, public IIGVerifyCaseStaticArraysInterface
{
#if !KERNEL
    friend class IIGVerifyCaseStaticArraysMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseStaticArrays_DECLARE_IVARS
IIGVerifyCaseStaticArrays_DECLARE_IVARS
#else /* IIGVerifyCaseStaticArrays_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseStaticArrays_IVars * ivars;
        IIGVerifyCaseStaticArrays_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseStaticArrays_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseStaticArraysMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseStaticArrays_Methods
    IIGVerifyCaseStaticArrays_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseStaticArrays.iig:24- */

#endif /* _DRIVERKIT_IIGVerifyCASESTATICARRAYS_H */
