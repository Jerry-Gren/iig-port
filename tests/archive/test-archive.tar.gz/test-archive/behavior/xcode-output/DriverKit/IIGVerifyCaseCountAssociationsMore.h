/* iig(DriverKit-440) generated from IIGVerifyCaseCountAssociationsMore.iig */

/* IIGVerifyCaseCountAssociationsMore.iig:1-6 */
#include <DriverKit/OSObject.h>  /* .iig include */
#include <DriverKit/IOBufferMemoryDescriptor.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASECOUNTASSOCIATIONSMORE_H
#define _DRIVERKIT_IIGVerifyCASECOUNTASSOCIATIONSMORE_H

/* source class IIGVerifyCaseCountAssociationsMore IIGVerifyCaseCountAssociationsMore.iig:7-31 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseCountAssociationsMore : public OSObject
{
public:
	virtual kern_return_t
	InputBytesWithExtraCount(const uint8_t bytes[4],
	    uint32_t byteCount,
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	OutputWordsCountBefore(uint32_t wordsCount,
	    uint32_t words[5],
	    uint32_t otherCount) LOCAL;

	virtual kern_return_t
	InputObjectsCountAfter(OSObject * const objects[3],
	    uint32_t objectsCount,
	    uint32_t unrelatedCount) LOCAL;

	virtual kern_return_t
	OutputBuffersCountBefore(uint32_t buffersCount,
	    IOBufferMemoryDescriptor * buffers[2]) LOCAL;

	virtual kern_return_t
	SerializableCountBefore(uint32_t dictionariesCount,
	    OSDictionary * const dictionaries[2]) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseCountAssociationsMore IIGVerifyCaseCountAssociationsMore.iig:7-31 */

#define IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_ID            0xc7473ba26b238423ULL
#define IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_ID            0xcec3a5bbdc125a33ULL
#define IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_ID            0xfab8c9031cb6ada8ULL
#define IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_ID            0xfd7cf0c19ef0d83eULL
#define IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_ID            0xa2d4710d77173300ULL

#define IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Args \
        const unsigned char * bytes, \
        uint32_t byteCount, \
        uint32_t bytesCount

#define IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Args \
        uint32_t wordsCount, \
        unsigned int * words, \
        uint32_t otherCount

#define IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Args \
        OSObject ** const objects, \
        uint32_t objectsCount, \
        uint32_t unrelatedCount

#define IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Args \
        uint32_t buffersCount, \
        IOBufferMemoryDescriptor ** buffers

#define IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Args \
        uint32_t dictionariesCount, \
        const OSDictionary * dictionaries

#define IIGVerifyCaseCountAssociationsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseCountAssociationsMore * self, const IORPC rpc);\
\
    kern_return_t\
    InputBytesWithExtraCount(\
        const unsigned char * bytes,\
        uint32_t byteCount,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputWordsCountBefore(\
        uint32_t wordsCount,\
        unsigned int * words,\
        uint32_t otherCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputObjectsCountAfter(\
        OSObject ** const objects,\
        uint32_t objectsCount,\
        uint32_t unrelatedCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputBuffersCountBefore(\
        uint32_t buffersCount,\
        IOBufferMemoryDescriptor ** buffers,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SerializableCountBefore(\
        uint32_t dictionariesCount,\
        const OSDictionary * dictionaries,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InputBytesWithExtraCount_Impl(IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Args);\
\
    kern_return_t\
    OutputWordsCountBefore_Impl(IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Args);\
\
    kern_return_t\
    InputObjectsCountAfter_Impl(IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Args);\
\
    kern_return_t\
    OutputBuffersCountBefore_Impl(IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Args);\
\
    kern_return_t\
    SerializableCountBefore_Impl(IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InputBytesWithExtraCount_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Args);\
    static kern_return_t\
    InputBytesWithExtraCount_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputBytesWithExtraCount_Handler func);\
\
    typedef kern_return_t (*OutputWordsCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Args);\
    static kern_return_t\
    OutputWordsCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputWordsCountBefore_Handler func);\
\
    typedef kern_return_t (*InputObjectsCountAfter_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Args);\
    static kern_return_t\
    InputObjectsCountAfter_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputObjectsCountAfter_Handler func);\
\
    typedef kern_return_t (*OutputBuffersCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Args);\
    static kern_return_t\
    OutputBuffersCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputBuffersCountBefore_Handler func);\
\
    typedef kern_return_t (*SerializableCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Args);\
    static kern_return_t\
    SerializableCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SerializableCountBefore_Handler func);\
\


#define IIGVerifyCaseCountAssociationsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseCountAssociationsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseCountAssociationsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseCountAssociationsMore_Class;

class IIGVerifyCaseCountAssociationsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseCountAssociationsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseCountAssociationsMore_IVars;
struct IIGVerifyCaseCountAssociationsMore_LocalIVars;

class IIGVerifyCaseCountAssociationsMore : public OSObject, public IIGVerifyCaseCountAssociationsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseCountAssociationsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseCountAssociationsMore_DECLARE_IVARS
IIGVerifyCaseCountAssociationsMore_DECLARE_IVARS
#else /* IIGVerifyCaseCountAssociationsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseCountAssociationsMore_IVars * ivars;
        IIGVerifyCaseCountAssociationsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseCountAssociationsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseCountAssociationsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseCountAssociationsMore_Methods
    IIGVerifyCaseCountAssociationsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseCountAssociationsMore.iig:33- */

#endif /* _DRIVERKIT_IIGVerifyCASECOUNTASSOCIATIONSMORE_H */
