/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseSerializableArrayOrder.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseSerializableArrayOrder.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseSerializableArrayOrder.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSDictionary * dictionaries;
#if !defined(__LP64__)
    uint32_t __dictionariesPad;
#endif /* !defined(__LP64__) */
    uint32_t  dictionariesCount;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  dictionaries__descriptor;
};
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  dictionaries__descriptor;
    IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_ObjRefs (2)

struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Invocation;
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSString * strings;
#if !defined(__LP64__)
    uint32_t __stringsPad;
#endif /* !defined(__LP64__) */
    uint32_t  stringsCount;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  strings__descriptor;
};
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  strings__descriptor;
    IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_ObjRefs (2)

struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Invocation;
struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSArray * arrays;
#if !defined(__LP64__)
    uint32_t __arraysPad;
#endif /* !defined(__LP64__) */
    uint32_t  arraysCount;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  arrays__descriptor;
};
struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  arrays__descriptor;
    IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_ObjRefs (2)

struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Invocation;
struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSSet * sets;
#if !defined(__LP64__)
    uint32_t __setsPad;
#endif /* !defined(__LP64__) */
    uint32_t  setsCount;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  sets__descriptor;
};
struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  sets__descriptor;
    IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_ObjRefs (2)

struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseSerializableArrayOrder_QueueNames  ""

#define IIGVerifyCaseSerializableArrayOrder_MethodNames  ""

#define IIGVerifyCaseSerializableArrayOrderMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseSerializableArrayOrder_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseSerializableArrayOrder_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseSerializableArrayOrderMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t
OSClassDescription_IIGVerifyCaseSerializableArrayOrder =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t),
        .name                    = "IIGVerifyCaseSerializableArrayOrder",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseSerializableArrayOrder_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseSerializableArrayOrder_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseSerializableArrayOrderMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableArrayOrder_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseSerializableArrayOrder_QueueNames,
    .methodNames     = IIGVerifyCaseSerializableArrayOrder_MethodNames,
    .metaMethodNames = IIGVerifyCaseSerializableArrayOrderMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseSerializableArrayOrderMetaClass;

static kern_return_t
IIGVerifyCaseSerializableArrayOrder_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseSerializableArrayOrder_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseSerializableArrayOrder.base,
    .metaPointer       = &gIIGVerifyCaseSerializableArrayOrderMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseSerializableArrayOrder),

    .resv2             = {0},

    .New               = &IIGVerifyCaseSerializableArrayOrder_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseSerializableArrayOrder_Declaration;
const void * const
gIIGVerifyCaseSerializableArrayOrder_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseSerializableArrayOrder_Class;

static kern_return_t
IIGVerifyCaseSerializableArrayOrder_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseSerializableArrayOrderMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrderMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseSerializableArrayOrder) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseSerializableArrayOrder::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::_Dispatch(IIGVerifyCaseSerializableArrayOrder * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_ID:
        {
            ret = IIGVerifyCaseSerializableArrayOrder::InstanceCountAfter_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseSerializableArrayOrder::InstanceCountAfter_Handler, *self, &IIGVerifyCaseSerializableArrayOrder::InstanceCountAfter_Impl));
            break;
        }
        case IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_ID:
        {
            ret = IIGVerifyCaseSerializableArrayOrder::InstanceCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseSerializableArrayOrder::InstanceCountBefore_Handler, *self, &IIGVerifyCaseSerializableArrayOrder::InstanceCountBefore_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseSerializableArrayOrder::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseSerializableArrayOrderMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_ID:
            ret = IIGVerifyCaseSerializableArrayOrder::StaticCountAfter_Invoke(rpc, &IIGVerifyCaseSerializableArrayOrder::StaticCountAfter_Impl);
            break;
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_ID:
            ret = IIGVerifyCaseSerializableArrayOrder::StaticCountBefore_Invoke(rpc, &IIGVerifyCaseSerializableArrayOrder::StaticCountBefore_Impl);
            break;
#endif /* !KERNEL */

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::InstanceCountAfter(
        const OSDictionary * dictionaries,
        uint32_t dictionariesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->dictionaries__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->dictionaries__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->dictionaries__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_Content, dictionaries);
    msg->content.dictionaries = dictionaries;

    if (dictionariesCount > (sizeof(msg->content.__dictionaries) / sizeof(msg->content.__dictionaries[0]))) return kIOReturnOverrun;
    bcopy(dictionaries, &msg->content.__dictionaries[0], dictionariesCount * sizeof(msg->content.__dictionaries[0]));

    msg->content.dictionariesCount = dictionariesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::InstanceCountBefore(
        uint32_t stringsCount,
        const OSString * strings,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.stringsCount = stringsCount;

    msg->strings__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->strings__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->strings__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_Content, strings);
    msg->content.strings = strings;

    if (stringsCount > (sizeof(msg->content.__strings) / sizeof(msg->content.__strings[0]))) return kIOReturnOverrun;
    bcopy(strings, &msg->content.__strings[0], stringsCount * sizeof(msg->content.__strings[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::StaticCountAfter_Call(
        const OSArray * arrays,
        uint32_t arraysCount)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseSerializableArrayOrder);
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->arrays__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->arrays__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->arrays__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_Content, arrays);
    msg->content.arrays = arrays;

    if (arraysCount > (sizeof(msg->content.__arrays) / sizeof(msg->content.__arrays[0]))) return kIOReturnOverrun;
    bcopy(arrays, &msg->content.__arrays[0], arraysCount * sizeof(msg->content.__arrays[0]));

    msg->content.arraysCount = arraysCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseSerializableArrayOrder)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::StaticCountBefore_Call(
        uint32_t setsCount,
        const OSSet * sets)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseSerializableArrayOrder);
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.setsCount = setsCount;

    msg->sets__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->sets__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->sets__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_Content, sets);
    msg->content.sets = sets;

    if (setsCount > (sizeof(msg->content.__sets) / sizeof(msg->content.__sets[0]))) return kIOReturnOverrun;
    bcopy(sets, &msg->content.__sets[0], setsCount * sizeof(msg->content.__sets[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseSerializableArrayOrder)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::InstanceCountAfter_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceCountAfter_Handler func)
{
    IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t dictionariesCount = (sizeof(MESSAGE_CONTENT(__dictionaries)) / sizeof(MESSAGE_CONTENT(__dictionaries[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(dictionariesCount) >= 0 && dictionariesCount > MESSAGE_CONTENT(dictionariesCount)) dictionariesCount = MESSAGE_CONTENT(dictionariesCount);
#pragma clang diagnostic pop

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(dictionaries)) != NULL && OSDynamicCast(OSDictionary, (OSObject *) MESSAGE_CONTENT(dictionaries)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        MESSAGE_CONTENT(dictionaries),
        dictionariesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::InstanceCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceCountBefore_Handler func)
{
    IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t stringsCount = (sizeof(MESSAGE_CONTENT(__strings)) / sizeof(MESSAGE_CONTENT(__strings[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(stringsCount) >= 0 && stringsCount > MESSAGE_CONTENT(stringsCount)) stringsCount = MESSAGE_CONTENT(stringsCount);
#pragma clang diagnostic pop

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(strings)) != NULL && OSDynamicCast(OSString, (OSObject *) MESSAGE_CONTENT(strings)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        stringsCount,
        MESSAGE_CONTENT(strings));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::StaticCountAfter_Invoke(const IORPC _rpc,
        StaticCountAfter_Handler func)
{
    IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t arraysCount = (sizeof(MESSAGE_CONTENT(__arrays)) / sizeof(MESSAGE_CONTENT(__arrays[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(arraysCount) >= 0 && arraysCount > MESSAGE_CONTENT(arraysCount)) arraysCount = MESSAGE_CONTENT(arraysCount);
#pragma clang diagnostic pop

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(arrays)) != NULL && OSDynamicCast(OSArray, (OSObject *) MESSAGE_CONTENT(arrays)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(        MESSAGE_CONTENT(arrays),
        arraysCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableArrayOrder::StaticCountBefore_Invoke(const IORPC _rpc,
        StaticCountBefore_Handler func)
{
    IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t setsCount = (sizeof(MESSAGE_CONTENT(__sets)) / sizeof(MESSAGE_CONTENT(__sets[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(setsCount) >= 0 && setsCount > MESSAGE_CONTENT(setsCount)) setsCount = MESSAGE_CONTENT(setsCount);
#pragma clang diagnostic pop

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(sets)) != NULL && OSDynamicCast(OSSet, (OSObject *) MESSAGE_CONTENT(sets)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(        setsCount,
        MESSAGE_CONTENT(sets));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Rpl_ObjRefs;

    return (ret);
}



