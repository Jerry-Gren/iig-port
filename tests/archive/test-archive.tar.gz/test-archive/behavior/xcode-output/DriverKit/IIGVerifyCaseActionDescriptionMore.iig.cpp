/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseActionDescriptionMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseActionDescriptionMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseActionDescriptionMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_ObjRefs (2)

struct IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionDescriptionMore_CompletionA_Invocation;
struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_ObjRefs (2)

struct IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionDescriptionMore_CompletionB_Invocation;
struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
};
struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
    IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_ObjRefs (2)

struct IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionDescriptionMore_SubmitA_Invocation;
struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
};
struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
    IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_ObjRefs (2)

struct IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionDescriptionMore_SubmitB_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass;
extern OSMetaClass * gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseActionDescriptionMore_QueueNames  "" \
    "\042"IIGVerifyActionDescriptionQueueA"" \
    "\042"IIGVerifyActionDescriptionQueueB""

#define IIGVerifyCaseActionDescriptionMore_MethodNames  "" \
    "\013CompletionA" \
    "\007SubmitA"

#define IIGVerifyCaseActionDescriptionMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 2];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseActionDescriptionMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseActionDescriptionMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseActionDescriptionMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t
OSClassDescription_IIGVerifyCaseActionDescriptionMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseActionDescriptionMore_t),
        .name                    = "IIGVerifyCaseActionDescriptionMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 2,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseActionDescriptionMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseActionDescriptionMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseActionDescriptionMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionDescriptionMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseActionDescriptionMore_CompletionA_ID,
        IIGVerifyCaseActionDescriptionMore_SubmitA_ID,
        0x0000000000000000,
        0x0000000000000001,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseActionDescriptionMore_QueueNames,
    .methodNames     = IIGVerifyCaseActionDescriptionMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseActionDescriptionMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseActionDescriptionMoreMetaClass;

static kern_return_t
IIGVerifyCaseActionDescriptionMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseActionDescriptionMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseActionDescriptionMore.base,
    .metaPointer       = &gIIGVerifyCaseActionDescriptionMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseActionDescriptionMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseActionDescriptionMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseActionDescriptionMore_Declaration;
const void * const
gIIGVerifyCaseActionDescriptionMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseActionDescriptionMore_Class;

static kern_return_t
IIGVerifyCaseActionDescriptionMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseActionDescriptionMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionDescriptionMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseActionDescriptionMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseActionDescriptionMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::_Dispatch(IIGVerifyCaseActionDescriptionMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseActionDescriptionMore_CompletionA_ID:
        {
            ret = IIGVerifyCaseActionDescriptionMore::CompletionA_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionDescriptionMore::CompletionA_Handler, *self, &IIGVerifyCaseActionDescriptionMore::CompletionA_Impl));
            break;
        }
        case IIGVerifyCaseActionDescriptionMore_CompletionB_ID:
        {
            ret = IIGVerifyCaseActionDescriptionMore::CompletionB_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionDescriptionMore::CompletionB_Handler, *self, &IIGVerifyCaseActionDescriptionMore::CompletionB_Impl));
            break;
        }
        case IIGVerifyCaseActionDescriptionMore_SubmitA_ID:
        {
            ret = IIGVerifyCaseActionDescriptionMore::SubmitA_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionDescriptionMore::SubmitA_Handler, *self, &IIGVerifyCaseActionDescriptionMore::SubmitA_Impl));
            break;
        }
        case IIGVerifyCaseActionDescriptionMore_SubmitB_ID:
        {
            ret = IIGVerifyCaseActionDescriptionMore::SubmitB_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionDescriptionMore::SubmitB_Handler, *self, &IIGVerifyCaseActionDescriptionMore::SubmitB_Impl));
            break;
        }
#if KERNEL
        case IIGVerifyCaseActionDescriptionMore_KernelCompletionA_ID:
        {
            ret = IIGVerifyCaseActionDescriptionMore::CompletionA_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionDescriptionMore::CompletionA_Handler, *self, &IIGVerifyCaseActionDescriptionMore::KernelCompletionA_Impl), OSTypeID(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA));
            break;
        }
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseActionDescriptionMore_KernelCompletionB_ID:
        {
            ret = IIGVerifyCaseActionDescriptionMore::CompletionB_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionDescriptionMore::CompletionB_Handler, *self, &IIGVerifyCaseActionDescriptionMore::KernelCompletionB_Impl), OSTypeID(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB));
            break;
        }
#endif /* !KERNEL */

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseActionDescriptionMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseActionDescriptionMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CompletionA(
        IORPC rpc,
        OSAction * action,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionDescriptionMore_CompletionA_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.token = token;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CompletionB(
        IORPC rpc,
        OSAction * action,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionDescriptionMore_CompletionB_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.token = token;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::SubmitA(
        OSAction * completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionDescriptionMore_SubmitA_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->completion__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.completion = (OSObjectRef) completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseActionDescriptionMore_SubmitA_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::SubmitB(
        OSAction * completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionDescriptionMore_SubmitB_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->completion__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.completion = (OSObjectRef) completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseActionDescriptionMore_SubmitB_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CreateActionKernelCompletionA(size_t referenceSize, OSAction ** action)
{
    kern_return_t ret;

#if defined(IOKIT_ENABLE_SHARED_PTR)
    OSSharedPtr<OSString>
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
    OSString *
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    typeName = OSString::withCString("OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA");
    if (!typeName) {
        return kIOReturnNoMemory;
    }
    ret = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA::CreateWithTypeName(this,
                           IIGVerifyCaseActionDescriptionMore_KernelCompletionA_ID,
                           IIGVerifyCaseActionDescriptionMore_CompletionA_ID,
                           referenceSize,
#if defined(IOKIT_ENABLE_SHARED_PTR)
                           typeName.get(),
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
                           typeName,
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
                           action);

#if !defined(IOKIT_ENABLE_SHARED_PTR)
    typeName->release();
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CreateActionKernelCompletionB(size_t referenceSize, OSAction ** action)
{
    kern_return_t ret;

#if defined(IOKIT_ENABLE_SHARED_PTR)
    OSSharedPtr<OSString>
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
    OSString *
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    typeName = OSString::withCString("OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB");
    if (!typeName) {
        return kIOReturnNoMemory;
    }
    ret = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB::CreateWithTypeName(this,
                           IIGVerifyCaseActionDescriptionMore_KernelCompletionB_ID,
                           IIGVerifyCaseActionDescriptionMore_CompletionB_ID,
                           referenceSize,
#if defined(IOKIT_ENABLE_SHARED_PTR)
                           typeName.get(),
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
                           typeName,
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
                           action);

#if !defined(IOKIT_ENABLE_SHARED_PTR)
    typeName->release();
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CompletionA_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionA_Handler func)
{
    return IIGVerifyCaseActionDescriptionMore::CompletionA_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CompletionA_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionA_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseActionDescriptionMore_CompletionA_Invocation rpc = { _rpc };
    IIGVerifyCaseActionDescriptionMore_CompletionA_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionDescriptionMore_CompletionA_Msg *         message = rpc.message;
    const IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionDescriptionMore_CompletionA_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(token));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CompletionB_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionB_Handler func)
{
    return IIGVerifyCaseActionDescriptionMore::CompletionB_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::CompletionB_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionB_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseActionDescriptionMore_CompletionB_Invocation rpc = { _rpc };
    IIGVerifyCaseActionDescriptionMore_CompletionB_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionDescriptionMore_CompletionB_Msg *         message = rpc.message;
    const IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionDescriptionMore_CompletionB_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(token));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::SubmitA_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitA_Handler func)
{
    IIGVerifyCaseActionDescriptionMore_SubmitA_Invocation rpc = { _rpc };
    IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionDescriptionMore_SubmitA_Msg *         message = rpc.message;
    const IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSAction * completion;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionDescriptionMore_SubmitA_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    completion = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(completion));
    if (!completion && MESSAGE_CONTENT(completion)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        completion,
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseActionDescriptionMore_SubmitA_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseActionDescriptionMore_SubmitA_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseActionDescriptionMore::SubmitB_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitB_Handler func)
{
    IIGVerifyCaseActionDescriptionMore_SubmitB_Invocation rpc = { _rpc };
    IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionDescriptionMore_SubmitB_Msg *         message = rpc.message;
    const IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSAction * completion;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionDescriptionMore_SubmitB_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    completion = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(completion));
    if (!completion && MESSAGE_CONTENT(completion)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        completion,
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseActionDescriptionMore_SubmitB_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseActionDescriptionMore_SubmitB_Rpl_ObjRefs;

    return (ret);
}

#if KERNEL
OSDefineMetaClassAndStructors(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA, OSAction);
#endif /* KERNEL */

#if !KERNEL

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_QueueNames  ""

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_MethodNames  ""

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass_MethodNames  ""

struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_QueueNames)];
    char               methodNames[sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_MethodNames)];
    char               metaMethodNames[sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass_MethodNames)];
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t
OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t),
        .name                    = "OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA",
        .superName               = "OSAction",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t, metaMethodOptions),
        .queueNamesSize       = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t, queueNames),
        .methodNamesSize         = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t, methodNames),
        .metaMethodNamesSize     = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_QueueNames,
    .methodNames     = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_MethodNames,
    .metaMethodNames = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass_MethodNames,
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
OSMetaClass * gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_New(OSMetaClass * instance);

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const OSClassLoadInformation
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Class = 
{
    .description       = &OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA.base,
    .metaPointer       = &gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA),

    .resv2             = {0},

    .New               = &OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_New,
    .resv3             = {0},

};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
extern const void * const
gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Declaration;
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const void * const
gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Declaration
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Class;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_New(OSMetaClass * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass::New(OSObject * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA::_Dispatch(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSAction::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

#if KERNEL
OSDefineMetaClassAndStructors(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB, OSAction);
#endif /* KERNEL */

#if !KERNEL

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_QueueNames  ""

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_MethodNames  ""

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass_MethodNames  ""

struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_QueueNames)];
    char               methodNames[sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_MethodNames)];
    char               metaMethodNames[sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass_MethodNames)];
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t
OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t),
        .name                    = "OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB",
        .superName               = "OSAction",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t, metaMethodOptions),
        .queueNamesSize       = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t, queueNames),
        .methodNamesSize         = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t, methodNames),
        .metaMethodNamesSize     = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_QueueNames,
    .methodNames     = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_MethodNames,
    .metaMethodNames = OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass_MethodNames,
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
OSMetaClass * gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_New(OSMetaClass * instance);

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const OSClassLoadInformation
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Class = 
{
    .description       = &OSClassDescription_OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB.base,
    .metaPointer       = &gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB),

    .resv2             = {0},

    .New               = &OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_New,
    .resv3             = {0},

};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
extern const void * const
gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Declaration;
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const void * const
gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Declaration
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Class;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_New(OSMetaClass * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass::New(OSObject * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB::_Dispatch(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSAction::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



