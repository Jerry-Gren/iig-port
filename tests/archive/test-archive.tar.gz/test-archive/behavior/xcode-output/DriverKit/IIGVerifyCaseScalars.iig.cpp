/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseScalars.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseScalars.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseScalars.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseScalars_OutputScalars_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseScalars_OutputScalars_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseScalars_OutputScalars_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseScalars_OutputScalars_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalars_OutputScalars_Msg_ObjRefs (1)

struct IIGVerifyCaseScalars_OutputScalars_Rpl_Content
{
    IORPCMessage __hdr;
    unsigned char  small;
    unsigned short  medium;
    unsigned int  word;
    unsigned long long  wide;
    bool  flag;
};
#pragma pack(4)
struct IIGVerifyCaseScalars_OutputScalars_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseScalars_OutputScalars_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseScalars_OutputScalars_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalars_OutputScalars_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseScalars_OutputScalars_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseScalars_OutputScalars_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseScalars_OutputScalars_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseScalars_OutputScalars_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseScalars_OutputScalars_Invocation;
struct IIGVerifyCaseScalars_MixedScalars_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint8_t  small;
    uint16_t  medium;
    uint32_t  word;
    uint64_t  wide;
    bool  flag;
};
#pragma pack(4)
struct IIGVerifyCaseScalars_MixedScalars_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseScalars_MixedScalars_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseScalars_MixedScalars_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalars_MixedScalars_Msg_ObjRefs (1)

struct IIGVerifyCaseScalars_MixedScalars_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseScalars_MixedScalars_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseScalars_MixedScalars_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseScalars_MixedScalars_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalars_MixedScalars_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseScalars_MixedScalars_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseScalars_MixedScalars_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseScalars_MixedScalars_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseScalars_MixedScalars_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseScalars_MixedScalars_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseScalars_QueueNames  ""

#define IIGVerifyCaseScalars_MethodNames  ""

#define IIGVerifyCaseScalarsMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseScalars_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseScalars_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseScalars_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseScalarsMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseScalars_t
OSClassDescription_IIGVerifyCaseScalars =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseScalars_t),
        .name                    = "IIGVerifyCaseScalars",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalars_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalars_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseScalars_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalars_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseScalars_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalars_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseScalarsMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalars_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseScalars_QueueNames,
    .methodNames     = IIGVerifyCaseScalars_MethodNames,
    .metaMethodNames = IIGVerifyCaseScalarsMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseScalarsMetaClass;

static kern_return_t
IIGVerifyCaseScalars_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseScalars_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseScalars.base,
    .metaPointer       = &gIIGVerifyCaseScalarsMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseScalars),

    .resv2             = {0},

    .New               = &IIGVerifyCaseScalars_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseScalars_Declaration;
const void * const
gIIGVerifyCaseScalars_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseScalars_Class;

static kern_return_t
IIGVerifyCaseScalars_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseScalarsMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseScalarsMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseScalars) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseScalars::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseScalars::_Dispatch(IIGVerifyCaseScalars * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseScalars_OutputScalars_ID:
        {
            ret = IIGVerifyCaseScalars::OutputScalars_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseScalars::OutputScalars_Handler, *self, &IIGVerifyCaseScalars::OutputScalars_Impl));
            break;
        }
        case IIGVerifyCaseScalars_MixedScalars_ID:
        {
            ret = IIGVerifyCaseScalars::MixedScalars_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseScalars::MixedScalars_Handler, *self, &IIGVerifyCaseScalars::MixedScalars_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseScalars::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseScalarsMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseScalars::OutputScalars(
        uint8_t * small,
        uint16_t * medium,
        uint32_t * word,
        uint64_t * wide,
        bool * flag,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseScalars_OutputScalars_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseScalars_OutputScalars_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseScalars_OutputScalars_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseScalars_OutputScalars_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseScalars_OutputScalars_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseScalars_OutputScalars_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseScalars_OutputScalars_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseScalars_OutputScalars_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (small) *small = rpl->content.small;
        if (medium) *medium = rpl->content.medium;
        if (word) *word = rpl->content.word;
        if (wide) *wide = rpl->content.wide;
        if (flag) *flag = rpl->content.flag;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseScalars::MixedScalars(
        uint8_t small,
        uint16_t medium,
        uint32_t word,
        uint64_t wide,
        bool flag,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseScalars_MixedScalars_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseScalars_MixedScalars_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseScalars_MixedScalars_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseScalars_MixedScalars_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseScalars_MixedScalars_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseScalars_MixedScalars_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.small = small;

    msg->content.medium = medium;

    msg->content.word = word;

    msg->content.wide = wide;

    msg->content.flag = flag;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseScalars_MixedScalars_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseScalars_MixedScalars_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseScalars::OutputScalars_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputScalars_Handler func)
{
    IIGVerifyCaseScalars_OutputScalars_Invocation rpc = { _rpc };
    IIGVerifyCaseScalars_OutputScalars_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseScalars_OutputScalars_Msg *         message = rpc.message;
    const IIGVerifyCaseScalars_OutputScalars_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseScalars_OutputScalars_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseScalars_OutputScalars_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseScalars_OutputScalars_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.small,
        &reply->content.medium,
        &reply->content.word,
        &reply->content.wide,
        &reply->content.flag);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseScalars_OutputScalars_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseScalars_OutputScalars_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseScalars::MixedScalars_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        MixedScalars_Handler func)
{
    IIGVerifyCaseScalars_MixedScalars_Invocation rpc = { _rpc };
    IIGVerifyCaseScalars_MixedScalars_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseScalars_MixedScalars_Msg *         message = rpc.message;
    const IIGVerifyCaseScalars_MixedScalars_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseScalars_MixedScalars_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseScalars_MixedScalars_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseScalars_MixedScalars_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(small),
        MESSAGE_CONTENT(medium),
        MESSAGE_CONTENT(word),
        MESSAGE_CONTENT(wide),
        MESSAGE_CONTENT(flag));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseScalars_MixedScalars_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseScalars_MixedScalars_Rpl_ObjRefs;

    return (ret);
}



