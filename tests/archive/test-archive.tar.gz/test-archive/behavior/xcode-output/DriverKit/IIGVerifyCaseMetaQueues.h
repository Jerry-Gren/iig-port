/* iig(DriverKit-440) generated from IIGVerifyCaseMetaQueues.iig */

/* IIGVerifyCaseMetaQueues.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEMETAQUEUES_H
#define _DRIVERKIT_IIGVerifyCASEMETAQUEUES_H

#define kIIGVerifyMetaQueueA "IIGVerifyMetaQueueA"
#define kIIGVerifyMetaQueueB "IIGVerifyMetaQueueB"

/* source class IIGVerifyCaseMetaQueues IIGVerifyCaseMetaQueues.iig:9-22 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseMetaQueues : public OSObject
{
public:
	static kern_return_t
	StaticA(uint64_t value) LOCAL QUEUENAME(kIIGVerifyMetaQueueA);

	static kern_return_t
	StaticB(uint64_t value) LOCAL QUEUENAME(kIIGVerifyMetaQueueB);

	virtual kern_return_t
	InstanceB(uint64_t value) LOCAL QUEUENAME(kIIGVerifyMetaQueueB);

	virtual kern_return_t
	InstanceA(uint64_t value) LOCAL QUEUENAME(kIIGVerifyMetaQueueA);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseMetaQueues IIGVerifyCaseMetaQueues.iig:9-22 */

#define IIGVerifyCaseMetaQueues_StaticA_ID            0xbe0120fe943a3f06ULL
#define IIGVerifyCaseMetaQueues_StaticB_ID            0xbe3ed49a1f6c3687ULL
#define IIGVerifyCaseMetaQueues_InstanceB_ID            0xfcd6877379e55fd2ULL
#define IIGVerifyCaseMetaQueues_InstanceA_ID            0xe0515ddf49c48993ULL

#define IIGVerifyCaseMetaQueues_StaticA_Args \
        uint64_t value

#define IIGVerifyCaseMetaQueues_StaticB_Args \
        uint64_t value

#define IIGVerifyCaseMetaQueues_InstanceB_Args \
        uint64_t value

#define IIGVerifyCaseMetaQueues_InstanceA_Args \
        uint64_t value

#define IIGVerifyCaseMetaQueues_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseMetaQueues * self, const IORPC rpc);\
\
    static kern_return_t\
    StaticA(\
        uint64_t value);\
\
    static kern_return_t\
    StaticB(\
        uint64_t value);\
\
    kern_return_t\
    InstanceB(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InstanceA(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    static kern_return_t\
    StaticA_Call(IIGVerifyCaseMetaQueues_StaticA_Args);\
\
    static kern_return_t\
    StaticB_Call(IIGVerifyCaseMetaQueues_StaticB_Args);\
\
    kern_return_t\
    InstanceB_Impl(IIGVerifyCaseMetaQueues_InstanceB_Args);\
\
    kern_return_t\
    InstanceA_Impl(IIGVerifyCaseMetaQueues_InstanceA_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*StaticA_Handler)(IIGVerifyCaseMetaQueues_StaticA_Args);\
    static kern_return_t\
    StaticA_Invoke(const IORPC rpc,\
        StaticA_Handler func);\
\
    typedef kern_return_t (*StaticB_Handler)(IIGVerifyCaseMetaQueues_StaticB_Args);\
    static kern_return_t\
    StaticB_Invoke(const IORPC rpc,\
        StaticB_Handler func);\
\
    typedef kern_return_t (*InstanceB_Handler)(OSMetaClassBase * target, IIGVerifyCaseMetaQueues_InstanceB_Args);\
    static kern_return_t\
    InstanceB_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceB_Handler func);\
\
    typedef kern_return_t (*InstanceA_Handler)(OSMetaClassBase * target, IIGVerifyCaseMetaQueues_InstanceA_Args);\
    static kern_return_t\
    InstanceA_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceA_Handler func);\
\


#define IIGVerifyCaseMetaQueues_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    static kern_return_t\
    StaticA_Impl(IIGVerifyCaseMetaQueues_StaticA_Args);\
\
    static kern_return_t\
    StaticB_Impl(IIGVerifyCaseMetaQueues_StaticB_Args);\
\


#define IIGVerifyCaseMetaQueues_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseMetaQueuesMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseMetaQueues_Class;

class IIGVerifyCaseMetaQueuesMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseMetaQueuesInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseMetaQueues_IVars;
struct IIGVerifyCaseMetaQueues_LocalIVars;

class IIGVerifyCaseMetaQueues : public OSObject, public IIGVerifyCaseMetaQueuesInterface
{
#if !KERNEL
    friend class IIGVerifyCaseMetaQueuesMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseMetaQueues_DECLARE_IVARS
IIGVerifyCaseMetaQueues_DECLARE_IVARS
#else /* IIGVerifyCaseMetaQueues_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseMetaQueues_IVars * ivars;
        IIGVerifyCaseMetaQueues_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseMetaQueues_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseMetaQueuesMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseMetaQueues_Methods
    IIGVerifyCaseMetaQueues_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseMetaQueues.iig:24- */

#endif /* _DRIVERKIT_IIGVerifyCASEMETAQUEUES_H */
