/* iig(DriverKit-440) generated from IIGVerifyCaseObjectArrays.iig */

/* IIGVerifyCaseObjectArrays.iig:1-6 */
#include <DriverKit/OSObject.h>  /* .iig include */
#include <DriverKit/IOBufferMemoryDescriptor.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEOBJECTARRAYS_H
#define _DRIVERKIT_IIGVerifyCASEOBJECTARRAYS_H

/* source class IIGVerifyCaseObjectArrays IIGVerifyCaseObjectArrays.iig:7-21 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseObjectArrays : public OSObject
{
public:
	virtual kern_return_t
	InputObjects(OSObject * const objects[4],
	    uint32_t objectsCount) LOCAL;

	virtual kern_return_t
	InputBuffers(IOBufferMemoryDescriptor * const buffers[2],
	    uint32_t buffersCount,
	    OSObject ** output) LOCAL;

	virtual kern_return_t
	SerializableArray(OSDictionary * const dictionaries[3],
	    uint32_t dictionariesCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseObjectArrays IIGVerifyCaseObjectArrays.iig:7-21 */

#define IIGVerifyCaseObjectArrays_InputObjects_ID            0x9447b574719127e7ULL
#define IIGVerifyCaseObjectArrays_InputBuffers_ID            0x91bc2caa10317cfcULL
#define IIGVerifyCaseObjectArrays_SerializableArray_ID            0xe9bd3487a401e3ddULL

#define IIGVerifyCaseObjectArrays_InputObjects_Args \
        OSObject ** const objects, \
        uint32_t objectsCount

#define IIGVerifyCaseObjectArrays_InputBuffers_Args \
        IOBufferMemoryDescriptor ** const buffers, \
        uint32_t buffersCount, \
        OSObject ** output

#define IIGVerifyCaseObjectArrays_SerializableArray_Args \
        const OSDictionary * dictionaries, \
        uint32_t dictionariesCount

#define IIGVerifyCaseObjectArrays_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseObjectArrays * self, const IORPC rpc);\
\
    kern_return_t\
    InputObjects(\
        OSObject ** const objects,\
        uint32_t objectsCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputBuffers(\
        IOBufferMemoryDescriptor ** const buffers,\
        uint32_t buffersCount,\
        OSObject ** output,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SerializableArray(\
        const OSDictionary * dictionaries,\
        uint32_t dictionariesCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InputObjects_Impl(IIGVerifyCaseObjectArrays_InputObjects_Args);\
\
    kern_return_t\
    InputBuffers_Impl(IIGVerifyCaseObjectArrays_InputBuffers_Args);\
\
    kern_return_t\
    SerializableArray_Impl(IIGVerifyCaseObjectArrays_SerializableArray_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InputObjects_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrays_InputObjects_Args);\
    static kern_return_t\
    InputObjects_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputObjects_Handler func);\
\
    typedef kern_return_t (*InputBuffers_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrays_InputBuffers_Args);\
    static kern_return_t\
    InputBuffers_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputBuffers_Handler func);\
\
    typedef kern_return_t (*SerializableArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrays_SerializableArray_Args);\
    static kern_return_t\
    SerializableArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SerializableArray_Handler func);\
\


#define IIGVerifyCaseObjectArrays_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseObjectArrays_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseObjectArraysMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseObjectArrays_Class;

class IIGVerifyCaseObjectArraysMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseObjectArraysInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseObjectArrays_IVars;
struct IIGVerifyCaseObjectArrays_LocalIVars;

class IIGVerifyCaseObjectArrays : public OSObject, public IIGVerifyCaseObjectArraysInterface
{
#if !KERNEL
    friend class IIGVerifyCaseObjectArraysMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseObjectArrays_DECLARE_IVARS
IIGVerifyCaseObjectArrays_DECLARE_IVARS
#else /* IIGVerifyCaseObjectArrays_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseObjectArrays_IVars * ivars;
        IIGVerifyCaseObjectArrays_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseObjectArrays_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseObjectArraysMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseObjectArrays_Methods
    IIGVerifyCaseObjectArrays_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseObjectArrays.iig:23- */

#endif /* _DRIVERKIT_IIGVerifyCASEOBJECTARRAYS_H */
