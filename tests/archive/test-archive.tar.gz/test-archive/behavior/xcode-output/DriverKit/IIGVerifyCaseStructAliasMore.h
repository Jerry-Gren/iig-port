/* iig(DriverKit-440) generated from IIGVerifyCaseStructAliasMore.iig */

/* IIGVerifyCaseStructAliasMore.iig:1-12 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESTRUCTALIASMORE_H
#define _DRIVERKIT_IIGVerifyCASESTRUCTALIASMORE_H

struct IIGVerifyAliasStruct {
	uint64_t value;
};

typedef const IIGVerifyAliasStruct * IIGVerifyAliasStructIn;
typedef IIGVerifyAliasStruct * IIGVerifyAliasStructOut;

/* source class IIGVerifyCaseStructAliasMore IIGVerifyCaseStructAliasMore.iig:13-20 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseStructAliasMore : public OSObject
{
public:
	virtual kern_return_t
	InputAlias(IIGVerifyAliasStructIn value) LOCAL;

	virtual kern_return_t
	OutputAlias(IIGVerifyAliasStructOut value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseStructAliasMore IIGVerifyCaseStructAliasMore.iig:13-20 */

#define IIGVerifyCaseStructAliasMore_InputAlias_ID            0x81129ab7f21dc40bULL
#define IIGVerifyCaseStructAliasMore_OutputAlias_ID            0xfde7f84949253f79ULL

#define IIGVerifyCaseStructAliasMore_InputAlias_Args \
        IIGVerifyAliasStructIn value

#define IIGVerifyCaseStructAliasMore_OutputAlias_Args \
        IIGVerifyAliasStructOut value

#define IIGVerifyCaseStructAliasMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseStructAliasMore * self, const IORPC rpc);\
\
    kern_return_t\
    InputAlias(\
        IIGVerifyAliasStructIn value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputAlias(\
        IIGVerifyAliasStructOut value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InputAlias_Impl(IIGVerifyCaseStructAliasMore_InputAlias_Args);\
\
    kern_return_t\
    OutputAlias_Impl(IIGVerifyCaseStructAliasMore_OutputAlias_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InputAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructAliasMore_InputAlias_Args);\
    static kern_return_t\
    InputAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputAlias_Handler func);\
\
    typedef kern_return_t (*OutputAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructAliasMore_OutputAlias_Args);\
    static kern_return_t\
    OutputAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputAlias_Handler func);\
\


#define IIGVerifyCaseStructAliasMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseStructAliasMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseStructAliasMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseStructAliasMore_Class;

class IIGVerifyCaseStructAliasMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseStructAliasMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseStructAliasMore_IVars;
struct IIGVerifyCaseStructAliasMore_LocalIVars;

class IIGVerifyCaseStructAliasMore : public OSObject, public IIGVerifyCaseStructAliasMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseStructAliasMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseStructAliasMore_DECLARE_IVARS
IIGVerifyCaseStructAliasMore_DECLARE_IVARS
#else /* IIGVerifyCaseStructAliasMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseStructAliasMore_IVars * ivars;
        IIGVerifyCaseStructAliasMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseStructAliasMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseStructAliasMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseStructAliasMore_Methods
    IIGVerifyCaseStructAliasMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseStructAliasMore.iig:22- */

#endif /* _DRIVERKIT_IIGVerifyCASESTRUCTALIASMORE_H */
