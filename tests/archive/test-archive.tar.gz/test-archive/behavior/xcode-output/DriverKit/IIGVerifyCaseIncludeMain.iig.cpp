/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseIncludeMain.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseIncludeMain.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseIncludeMain.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseIncludeMain_NestedName_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[11];
};
#pragma pack(4)
struct IIGVerifyCaseIncludeMain_NestedName_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIncludeMain_NestedName_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIncludeMain_NestedName_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIncludeMain_NestedName_Msg_ObjRefs (1)

struct IIGVerifyCaseIncludeMain_NestedName_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIncludeMain_NestedName_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIncludeMain_NestedName_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIncludeMain_NestedName_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIncludeMain_NestedName_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIncludeMain_NestedName_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIncludeMain_NestedName_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIncludeMain_NestedName_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIncludeMain_NestedName_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIncludeMain_NestedName_Invocation;
struct IIGVerifyCaseIncludeMain_NestedInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[6];
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseIncludeMain_NestedInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIncludeMain_NestedInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIncludeMain_NestedInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIncludeMain_NestedInput_Msg_ObjRefs (1)

struct IIGVerifyCaseIncludeMain_NestedInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIncludeMain_NestedInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIncludeMain_NestedInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIncludeMain_NestedInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIncludeMain_NestedInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIncludeMain_NestedInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIncludeMain_NestedInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIncludeMain_NestedInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIncludeMain_NestedInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIncludeMain_NestedInput_Invocation;
struct IIGVerifyCaseIncludeMain_DirectInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned long long *  values;
#if !defined(__LP64__)
    uint32_t __valuesPad;
#endif /* !defined(__LP64__) */
    unsigned long long __values[3];
    uint32_t  valuesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIncludeMain_DirectInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIncludeMain_DirectInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIncludeMain_DirectInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIncludeMain_DirectInput_Msg_ObjRefs (1)

struct IIGVerifyCaseIncludeMain_DirectInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIncludeMain_DirectInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIncludeMain_DirectInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIncludeMain_DirectInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIncludeMain_DirectInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIncludeMain_DirectInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIncludeMain_DirectInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIncludeMain_DirectInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIncludeMain_DirectInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIncludeMain_DirectInput_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseIncludeMain_QueueNames  ""

#define IIGVerifyCaseIncludeMain_MethodNames  ""

#define IIGVerifyCaseIncludeMainMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseIncludeMain_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseIncludeMain_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseIncludeMain_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseIncludeMainMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseIncludeMain_t
OSClassDescription_IIGVerifyCaseIncludeMain =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseIncludeMain_t),
        .name                    = "IIGVerifyCaseIncludeMain",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIncludeMain_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIncludeMain_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseIncludeMain_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIncludeMain_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseIncludeMain_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIncludeMain_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseIncludeMainMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIncludeMain_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseIncludeMain_QueueNames,
    .methodNames     = IIGVerifyCaseIncludeMain_MethodNames,
    .metaMethodNames = IIGVerifyCaseIncludeMainMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseIncludeMainMetaClass;

static kern_return_t
IIGVerifyCaseIncludeMain_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseIncludeMain_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseIncludeMain.base,
    .metaPointer       = &gIIGVerifyCaseIncludeMainMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseIncludeMain),

    .resv2             = {0},

    .New               = &IIGVerifyCaseIncludeMain_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseIncludeMain_Declaration;
const void * const
gIIGVerifyCaseIncludeMain_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseIncludeMain_Class;

static kern_return_t
IIGVerifyCaseIncludeMain_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseIncludeMainMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseIncludeMainMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseIncludeMain) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseIncludeMain::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseIncludeMain::_Dispatch(IIGVerifyCaseIncludeMain * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseIncludeMain_NestedName_ID:
        {
            ret = IIGVerifyCaseIncludeMain::NestedName_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIncludeMain::NestedName_Handler, *self, &IIGVerifyCaseIncludeMain::NestedName_Impl));
            break;
        }
        case IIGVerifyCaseIncludeMain_NestedInput_ID:
        {
            ret = IIGVerifyCaseIncludeMain::NestedInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIncludeMain::NestedInput_Handler, *self, &IIGVerifyCaseIncludeMain::NestedInput_Impl));
            break;
        }
        case IIGVerifyCaseIncludeMain_DirectInput_ID:
        {
            ret = IIGVerifyCaseIncludeMain::DirectInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIncludeMain::DirectInput_Handler, *self, &IIGVerifyCaseIncludeMain::DirectInput_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseIncludeMain::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseIncludeMainMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseIncludeMain::NestedName(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIncludeMain_NestedName_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIncludeMain_NestedName_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIncludeMain_NestedName_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIncludeMain_NestedName_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIncludeMain_NestedName_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIncludeMain_NestedName_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIncludeMain_NestedName_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIncludeMain_NestedName_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIncludeMain::NestedInput(
        const unsigned int * words,
        uint32_t wordsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIncludeMain_NestedInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIncludeMain_NestedInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIncludeMain_NestedInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIncludeMain_NestedInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIncludeMain_NestedInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIncludeMain_NestedInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.words = NULL;

    if (wordsCount > (sizeof(msg->content.__words) / sizeof(msg->content.__words[0]))) return kIOReturnOverrun;
    bcopy(words, &msg->content.__words[0], wordsCount * sizeof(msg->content.__words[0]));

    msg->content.wordsCount = wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIncludeMain_NestedInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIncludeMain_NestedInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIncludeMain::DirectInput(
        const unsigned long long * values,
        uint32_t valuesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIncludeMain_DirectInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIncludeMain_DirectInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIncludeMain_DirectInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIncludeMain_DirectInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIncludeMain_DirectInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIncludeMain_DirectInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.values = NULL;

    if (valuesCount > (sizeof(msg->content.__values) / sizeof(msg->content.__values[0]))) return kIOReturnOverrun;
    bcopy(values, &msg->content.__values[0], valuesCount * sizeof(msg->content.__values[0]));

    msg->content.valuesCount = valuesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIncludeMain_DirectInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIncludeMain_DirectInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIncludeMain::NestedName_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        NestedName_Handler func)
{
    IIGVerifyCaseIncludeMain_NestedName_Invocation rpc = { _rpc };
    IIGVerifyCaseIncludeMain_NestedName_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIncludeMain_NestedName_Msg *         message = rpc.message;
    const IIGVerifyCaseIncludeMain_NestedName_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIncludeMain_NestedName_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIncludeMain_NestedName_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIncludeMain_NestedName_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIncludeMain_NestedName_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIncludeMain_NestedName_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIncludeMain::NestedInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        NestedInput_Handler func)
{
    IIGVerifyCaseIncludeMain_NestedInput_Invocation rpc = { _rpc };
    IIGVerifyCaseIncludeMain_NestedInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIncludeMain_NestedInput_Msg *         message = rpc.message;
    const IIGVerifyCaseIncludeMain_NestedInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIncludeMain_NestedInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIncludeMain_NestedInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIncludeMain_NestedInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__words[0]),
        wordsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIncludeMain_NestedInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIncludeMain_NestedInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIncludeMain::DirectInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        DirectInput_Handler func)
{
    IIGVerifyCaseIncludeMain_DirectInput_Invocation rpc = { _rpc };
    IIGVerifyCaseIncludeMain_DirectInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIncludeMain_DirectInput_Msg *         message = rpc.message;
    const IIGVerifyCaseIncludeMain_DirectInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIncludeMain_DirectInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t valuesCount = (sizeof(MESSAGE_CONTENT(__values)) / sizeof(MESSAGE_CONTENT(__values[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(valuesCount) >= 0 && valuesCount > MESSAGE_CONTENT(valuesCount)) valuesCount = MESSAGE_CONTENT(valuesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIncludeMain_DirectInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIncludeMain_DirectInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__values[0]),
        valuesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIncludeMain_DirectInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIncludeMain_DirectInput_Rpl_ObjRefs;

    return (ret);
}



