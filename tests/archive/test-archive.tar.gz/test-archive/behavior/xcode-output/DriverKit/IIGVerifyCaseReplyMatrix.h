/* iig(DriverKit-440) generated from IIGVerifyCaseReplyMatrix.iig */

/* IIGVerifyCaseReplyMatrix.iig:1-7 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEREPLYMATRIX_H
#define _DRIVERKIT_IIGVerifyCASEREPLYMATRIX_H

#define kIIGVerifyCaseReplyQueue "IIGVerifyCaseReplyQueue"

/* source class IIGVerifyCaseReplyMatrix IIGVerifyCaseReplyMatrix.iig:8-28 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseReplyMatrix : public OSObject
{
public:
	virtual kern_return_t
	NormalReply(uint64_t value) LOCAL;

	virtual kern_return_t
	HostReply(uint64_t value) LOCALHOST;

	virtual kern_return_t
	StatusReply(uint64_t value) REPLY LOCAL;

	virtual kern_return_t
	HostStatusReply(uint64_t value) REPLY LOCALHOST;

	virtual kern_return_t
	Queued(uint64_t value) LOCAL QUEUENAME(IIGVerifyCaseReplyQueue);

	virtual void
	TargetReply(OSAction * action TARGET,
	    uint64_t value) REPLY LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseReplyMatrix IIGVerifyCaseReplyMatrix.iig:8-28 */

#define IIGVerifyCaseReplyMatrix_NormalReply_ID            0xb71079e08a1bcee7ULL
#define IIGVerifyCaseReplyMatrix_HostReply_ID            0xcf4b18d69e2ce7b9ULL
#define IIGVerifyCaseReplyMatrix_StatusReply_ID            0xe623ff6bb35a35a4ULL
#define IIGVerifyCaseReplyMatrix_HostStatusReply_ID            0xe049ad6bf7077193ULL
#define IIGVerifyCaseReplyMatrix_Queued_ID            0xffbc3a41dba824e6ULL
#define IIGVerifyCaseReplyMatrix_TargetReply_ID            0x9d8ad5cf320a1603ULL

#define IIGVerifyCaseReplyMatrix_NormalReply_Args \
        uint64_t value

#define IIGVerifyCaseReplyMatrix_HostReply_Args \
        uint64_t value

#define IIGVerifyCaseReplyMatrix_StatusReply_Args \
        uint64_t value

#define IIGVerifyCaseReplyMatrix_HostStatusReply_Args \
        uint64_t value

#define IIGVerifyCaseReplyMatrix_Queued_Args \
        uint64_t value

#define IIGVerifyCaseReplyMatrix_TargetReply_Args \
        OSAction * action, \
        uint64_t value

#define IIGVerifyCaseReplyMatrix_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseReplyMatrix * self, const IORPC rpc);\
\
    kern_return_t\
    NormalReply(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    HostReply(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    StatusReply(\
        IORPC rpc,\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    HostStatusReply(\
        IORPC rpc,\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    Queued(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TargetReply(\
        IORPC rpc,\
        OSAction * action,\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    NormalReply_Impl(IIGVerifyCaseReplyMatrix_NormalReply_Args);\
\
    kern_return_t\
    HostReply_Impl(IIGVerifyCaseReplyMatrix_HostReply_Args);\
\
    kern_return_t\
    StatusReply_Impl(IIGVerifyCaseReplyMatrix_StatusReply_Args);\
\
    kern_return_t\
    HostStatusReply_Impl(IIGVerifyCaseReplyMatrix_HostStatusReply_Args);\
\
    kern_return_t\
    Queued_Impl(IIGVerifyCaseReplyMatrix_Queued_Args);\
\
    void\
    TargetReply_Impl(IIGVerifyCaseReplyMatrix_TargetReply_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*NormalReply_Handler)(OSMetaClassBase * target, IIGVerifyCaseReplyMatrix_NormalReply_Args);\
    static kern_return_t\
    NormalReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        NormalReply_Handler func);\
\
    typedef kern_return_t (*HostReply_Handler)(OSMetaClassBase * target, IIGVerifyCaseReplyMatrix_HostReply_Args);\
    static kern_return_t\
    HostReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        HostReply_Handler func);\
\
    typedef kern_return_t (*StatusReply_Handler)(OSMetaClassBase * target, IIGVerifyCaseReplyMatrix_StatusReply_Args);\
    static kern_return_t\
    StatusReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        StatusReply_Handler func);\
\
    typedef kern_return_t (*HostStatusReply_Handler)(OSMetaClassBase * target, IIGVerifyCaseReplyMatrix_HostStatusReply_Args);\
    static kern_return_t\
    HostStatusReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        HostStatusReply_Handler func);\
\
    typedef kern_return_t (*Queued_Handler)(OSMetaClassBase * target, IIGVerifyCaseReplyMatrix_Queued_Args);\
    static kern_return_t\
    Queued_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Queued_Handler func);\
\
    typedef void (*TargetReply_Handler)(OSMetaClassBase * target, IIGVerifyCaseReplyMatrix_TargetReply_Args);\
    static kern_return_t\
    TargetReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TargetReply_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    TargetReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TargetReply_Handler func);\
\


#define IIGVerifyCaseReplyMatrix_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseReplyMatrix_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseReplyMatrixMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseReplyMatrix_Class;

class IIGVerifyCaseReplyMatrixMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseReplyMatrixInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseReplyMatrix_IVars;
struct IIGVerifyCaseReplyMatrix_LocalIVars;

class IIGVerifyCaseReplyMatrix : public OSObject, public IIGVerifyCaseReplyMatrixInterface
{
#if !KERNEL
    friend class IIGVerifyCaseReplyMatrixMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseReplyMatrix_DECLARE_IVARS
IIGVerifyCaseReplyMatrix_DECLARE_IVARS
#else /* IIGVerifyCaseReplyMatrix_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseReplyMatrix_IVars * ivars;
        IIGVerifyCaseReplyMatrix_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseReplyMatrix_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseReplyMatrixMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseReplyMatrix_Methods
    IIGVerifyCaseReplyMatrix_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseReplyMatrix.iig:30- */

#endif /* _DRIVERKIT_IIGVerifyCASEREPLYMATRIX_H */
