/* iig(DriverKit-440) generated from IIGVerifyCaseTypedefDepth.iig */

/* IIGVerifyCaseTypedefDepth.iig:1-10 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASETYPEDEFDEPTH_H
#define _DRIVERKIT_IIGVerifyCASETYPEDEFDEPTH_H

#define IIGVerifyCaseTypedefDepthBytes 6

typedef uint8_t IIGVerifyCaseTypedefDepthLeaf[IIGVerifyCaseTypedefDepthBytes];
typedef IIGVerifyCaseTypedefDepthLeaf IIGVerifyCaseTypedefDepthAlias;

/* source class IIGVerifyCaseTypedefDepth IIGVerifyCaseTypedefDepth.iig:11-20 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseTypedefDepth : public OSObject
{
public:
	virtual kern_return_t
	AliasInput(const IIGVerifyCaseTypedefDepthAlias bytes,
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	AliasOutput(uint32_t wordsCount,
	    IIGVerifyCaseTypedefDepthAlias words) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseTypedefDepth IIGVerifyCaseTypedefDepth.iig:11-20 */

#define IIGVerifyCaseTypedefDepth_AliasInput_ID            0xa48e0748f5af4d4cULL
#define IIGVerifyCaseTypedefDepth_AliasOutput_ID            0xa02b86463718fb26ULL

#define IIGVerifyCaseTypedefDepth_AliasInput_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseTypedefDepth_AliasOutput_Args \
        uint32_t wordsCount, \
        unsigned char * words

#define IIGVerifyCaseTypedefDepth_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseTypedefDepth * self, const IORPC rpc);\
\
    kern_return_t\
    AliasInput(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasOutput(\
        uint32_t wordsCount,\
        unsigned char * words,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    AliasInput_Impl(IIGVerifyCaseTypedefDepth_AliasInput_Args);\
\
    kern_return_t\
    AliasOutput_Impl(IIGVerifyCaseTypedefDepth_AliasOutput_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*AliasInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefDepth_AliasInput_Args);\
    static kern_return_t\
    AliasInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasInput_Handler func);\
\
    typedef kern_return_t (*AliasOutput_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedefDepth_AliasOutput_Args);\
    static kern_return_t\
    AliasOutput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasOutput_Handler func);\
\


#define IIGVerifyCaseTypedefDepth_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseTypedefDepth_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseTypedefDepthMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseTypedefDepth_Class;

class IIGVerifyCaseTypedefDepthMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseTypedefDepthInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseTypedefDepth_IVars;
struct IIGVerifyCaseTypedefDepth_LocalIVars;

class IIGVerifyCaseTypedefDepth : public OSObject, public IIGVerifyCaseTypedefDepthInterface
{
#if !KERNEL
    friend class IIGVerifyCaseTypedefDepthMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseTypedefDepth_DECLARE_IVARS
IIGVerifyCaseTypedefDepth_DECLARE_IVARS
#else /* IIGVerifyCaseTypedefDepth_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseTypedefDepth_IVars * ivars;
        IIGVerifyCaseTypedefDepth_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseTypedefDepth_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseTypedefDepthMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseTypedefDepth_Methods
    IIGVerifyCaseTypedefDepth_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseTypedefDepth.iig:22- */

#endif /* _DRIVERKIT_IIGVerifyCASETYPEDEFDEPTH_H */
