/* iig(DriverKit-440) generated from IIGVerifyCasePointerQualifiers.iig */

/* IIGVerifyCasePointerQualifiers.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEPOINTERQUALIFIERS_H
#define _DRIVERKIT_IIGVerifyCASEPOINTERQUALIFIERS_H

/* source class IIGVerifyCasePointerQualifiers IIGVerifyCasePointerQualifiers.iig:6-16 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCasePointerQualifiers : public OSObject
{
public:
	virtual kern_return_t
	ConstObjectInput(const OSObject * object) LOCAL;

	virtual kern_return_t
	ObjectPointerConst(OSObject * const object) LOCAL;

	virtual kern_return_t
	ConstScalarInput(const uint64_t * value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCasePointerQualifiers IIGVerifyCasePointerQualifiers.iig:6-16 */

#define IIGVerifyCasePointerQualifiers_ConstObjectInput_ID            0xc048f3d4ca2d9632ULL
#define IIGVerifyCasePointerQualifiers_ObjectPointerConst_ID            0xd4fbf92f758844cfULL
#define IIGVerifyCasePointerQualifiers_ConstScalarInput_ID            0xa209729dd52be7d9ULL

#define IIGVerifyCasePointerQualifiers_ConstObjectInput_Args \
        const OSObject * object

#define IIGVerifyCasePointerQualifiers_ObjectPointerConst_Args \
        OSObject *const object

#define IIGVerifyCasePointerQualifiers_ConstScalarInput_Args \
        const uint64_t * value

#define IIGVerifyCasePointerQualifiers_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCasePointerQualifiers * self, const IORPC rpc);\
\
    kern_return_t\
    ConstObjectInput(\
        const OSObject * object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ObjectPointerConst(\
        OSObject *const object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ConstScalarInput(\
        const uint64_t * value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    ConstObjectInput_Impl(IIGVerifyCasePointerQualifiers_ConstObjectInput_Args);\
\
    kern_return_t\
    ObjectPointerConst_Impl(IIGVerifyCasePointerQualifiers_ObjectPointerConst_Args);\
\
    kern_return_t\
    ConstScalarInput_Impl(IIGVerifyCasePointerQualifiers_ConstScalarInput_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*ConstObjectInput_Handler)(OSMetaClassBase * target, IIGVerifyCasePointerQualifiers_ConstObjectInput_Args);\
    static kern_return_t\
    ConstObjectInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstObjectInput_Handler func);\
\
    typedef kern_return_t (*ObjectPointerConst_Handler)(OSMetaClassBase * target, IIGVerifyCasePointerQualifiers_ObjectPointerConst_Args);\
    static kern_return_t\
    ObjectPointerConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ObjectPointerConst_Handler func);\
\
    typedef kern_return_t (*ConstScalarInput_Handler)(OSMetaClassBase * target, IIGVerifyCasePointerQualifiers_ConstScalarInput_Args);\
    static kern_return_t\
    ConstScalarInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstScalarInput_Handler func);\
\


#define IIGVerifyCasePointerQualifiers_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCasePointerQualifiers_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCasePointerQualifiersMetaClass;
extern const OSClassLoadInformation IIGVerifyCasePointerQualifiers_Class;

class IIGVerifyCasePointerQualifiersMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCasePointerQualifiersInterface : public OSInterface
{
public:
};

struct IIGVerifyCasePointerQualifiers_IVars;
struct IIGVerifyCasePointerQualifiers_LocalIVars;

class IIGVerifyCasePointerQualifiers : public OSObject, public IIGVerifyCasePointerQualifiersInterface
{
#if !KERNEL
    friend class IIGVerifyCasePointerQualifiersMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCasePointerQualifiers_DECLARE_IVARS
IIGVerifyCasePointerQualifiers_DECLARE_IVARS
#else /* IIGVerifyCasePointerQualifiers_DECLARE_IVARS */
    union
    {
        IIGVerifyCasePointerQualifiers_IVars * ivars;
        IIGVerifyCasePointerQualifiers_LocalIVars * lvars;
    };
#endif /* IIGVerifyCasePointerQualifiers_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCasePointerQualifiersMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCasePointerQualifiers_Methods
    IIGVerifyCasePointerQualifiers_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCasePointerQualifiers.iig:18- */

#endif /* _DRIVERKIT_IIGVerifyCASEPOINTERQUALIFIERS_H */
