/* iig(DriverKit-440) generated from IIGVerifyCaseScalars.iig */

/* IIGVerifyCaseScalars.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESCALARS_H
#define _DRIVERKIT_IIGVerifyCASESCALARS_H

/* source class IIGVerifyCaseScalars IIGVerifyCaseScalars.iig:6-15 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseScalars : public OSObject
{
public:
	virtual kern_return_t
	OutputScalars(uint8_t * small, uint16_t * medium,
	    uint32_t * word, uint64_t * wide, bool * flag) LOCAL;

	virtual kern_return_t
	MixedScalars(uint8_t small, uint16_t medium,
	    uint32_t word, uint64_t wide, bool flag) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseScalars IIGVerifyCaseScalars.iig:6-15 */

#define IIGVerifyCaseScalars_OutputScalars_ID            0xb39b047db244a9dbULL
#define IIGVerifyCaseScalars_MixedScalars_ID            0xee83140c0d13e0b3ULL

#define IIGVerifyCaseScalars_OutputScalars_Args \
        uint8_t * small, \
        uint16_t * medium, \
        uint32_t * word, \
        uint64_t * wide, \
        bool * flag

#define IIGVerifyCaseScalars_MixedScalars_Args \
        uint8_t small, \
        uint16_t medium, \
        uint32_t word, \
        uint64_t wide, \
        bool flag

#define IIGVerifyCaseScalars_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseScalars * self, const IORPC rpc);\
\
    kern_return_t\
    OutputScalars(\
        uint8_t * small,\
        uint16_t * medium,\
        uint32_t * word,\
        uint64_t * wide,\
        bool * flag,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    MixedScalars(\
        uint8_t small,\
        uint16_t medium,\
        uint32_t word,\
        uint64_t wide,\
        bool flag,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    OutputScalars_Impl(IIGVerifyCaseScalars_OutputScalars_Args);\
\
    kern_return_t\
    MixedScalars_Impl(IIGVerifyCaseScalars_MixedScalars_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*OutputScalars_Handler)(OSMetaClassBase * target, IIGVerifyCaseScalars_OutputScalars_Args);\
    static kern_return_t\
    OutputScalars_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputScalars_Handler func);\
\
    typedef kern_return_t (*MixedScalars_Handler)(OSMetaClassBase * target, IIGVerifyCaseScalars_MixedScalars_Args);\
    static kern_return_t\
    MixedScalars_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        MixedScalars_Handler func);\
\


#define IIGVerifyCaseScalars_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseScalars_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseScalarsMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseScalars_Class;

class IIGVerifyCaseScalarsMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseScalarsInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseScalars_IVars;
struct IIGVerifyCaseScalars_LocalIVars;

class IIGVerifyCaseScalars : public OSObject, public IIGVerifyCaseScalarsInterface
{
#if !KERNEL
    friend class IIGVerifyCaseScalarsMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseScalars_DECLARE_IVARS
IIGVerifyCaseScalars_DECLARE_IVARS
#else /* IIGVerifyCaseScalars_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseScalars_IVars * ivars;
        IIGVerifyCaseScalars_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseScalars_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseScalarsMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseScalars_Methods
    IIGVerifyCaseScalars_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseScalars.iig:17- */

#endif /* _DRIVERKIT_IIGVerifyCASESCALARS_H */
