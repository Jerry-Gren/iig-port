/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseQualifiers.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseQualifiers.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseQualifiersBase.h>
#include <DriverKit/IIGVerifyCaseQualifiers.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQualifiersBase_OverrideMe_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQualifiersBase_OverrideMe_Msg_ObjRefs (1)

struct IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQualifiersBase_OverrideMe_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQualifiersBase_OverrideMe_Invocation;
struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQualifiersBase_ConstStatus_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQualifiersBase_ConstStatus_Msg_ObjRefs (1)

struct IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_Content
{
    IORPCMessage __hdr;
    unsigned long long  value;
};
#pragma pack(4)
struct IIGVerifyCaseQualifiersBase_ConstStatus_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQualifiersBase_ConstStatus_Invocation;
struct IIGVerifyCaseQualifiers_BoolStatus_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQualifiers_BoolStatus_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQualifiers_BoolStatus_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQualifiers_BoolStatus_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQualifiers_BoolStatus_Msg_ObjRefs (1)

struct IIGVerifyCaseQualifiers_BoolStatus_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQualifiers_BoolStatus_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQualifiers_BoolStatus_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQualifiers_BoolStatus_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQualifiers_BoolStatus_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQualifiers_BoolStatus_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQualifiers_BoolStatus_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQualifiers_BoolStatus_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQualifiers_BoolStatus_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQualifiers_BoolStatus_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseQualifiersBase_QueueNames  ""

#define IIGVerifyCaseQualifiersBase_MethodNames  ""

#define IIGVerifyCaseQualifiersBaseMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseQualifiersBase_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseQualifiersBase_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseQualifiersBase_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseQualifiersBaseMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseQualifiersBase_t
OSClassDescription_IIGVerifyCaseQualifiersBase =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseQualifiersBase_t),
        .name                    = "IIGVerifyCaseQualifiersBase",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiersBase_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiersBase_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseQualifiersBase_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiersBase_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseQualifiersBase_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiersBase_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseQualifiersBaseMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiersBase_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseQualifiersBase_QueueNames,
    .methodNames     = IIGVerifyCaseQualifiersBase_MethodNames,
    .metaMethodNames = IIGVerifyCaseQualifiersBaseMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseQualifiersBaseMetaClass;

static kern_return_t
IIGVerifyCaseQualifiersBase_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseQualifiersBase_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseQualifiersBase.base,
    .metaPointer       = &gIIGVerifyCaseQualifiersBaseMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseQualifiersBase),

    .resv2             = {0},

    .New               = &IIGVerifyCaseQualifiersBase_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseQualifiersBase_Declaration;
const void * const
gIIGVerifyCaseQualifiersBase_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseQualifiersBase_Class;

static kern_return_t
IIGVerifyCaseQualifiersBase_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseQualifiersBaseMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseQualifiersBaseMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseQualifiersBase) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseQualifiersBase::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseQualifiersBase::_Dispatch(IIGVerifyCaseQualifiersBase * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseQualifiersBase_ConstStatus_ID:
        {
            ret = IIGVerifyCaseQualifiersBase::ConstStatus_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQualifiersBase::ConstStatus_Handler, *self, &IIGVerifyCaseQualifiersBase::ConstStatus_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseQualifiersBase::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseQualifiersBaseMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseQualifiersBase::OverrideMe(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQualifiersBase_OverrideMe_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQualifiersBase_OverrideMe_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQualifiersBase_OverrideMe_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQualifiersBase_OverrideMe_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQualifiersBase_OverrideMe_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQualifiersBase::ConstStatus(
        uint64_t * value,
        OSDispatchMethod supermethod) const
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQualifiersBase_ConstStatus_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQualifiersBase_ConstStatus_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQualifiersBase_ConstStatus_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQualifiersBase_ConstStatus_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQualifiersBase_ConstStatus_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (value) *value = rpl->content.value;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQualifiersBase::OverrideMe_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OverrideMe_Handler func)
{
    IIGVerifyCaseQualifiersBase_OverrideMe_Invocation rpc = { _rpc };
    IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQualifiersBase_OverrideMe_Msg *         message = rpc.message;
    const IIGVerifyCaseQualifiersBase_OverrideMe_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQualifiersBase_OverrideMe_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQualifiersBase_OverrideMe_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQualifiersBase_OverrideMe_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQualifiersBase_OverrideMe_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQualifiersBase_OverrideMe_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseQualifiersBase::ConstStatus_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstStatus_Handler func)
{
    IIGVerifyCaseQualifiersBase_ConstStatus_Invocation rpc = { _rpc };
    IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQualifiersBase_ConstStatus_Msg *         message = rpc.message;
    const IIGVerifyCaseQualifiersBase_ConstStatus_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQualifiersBase_ConstStatus_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQualifiersBase_ConstStatus_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQualifiersBase_ConstStatus_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.value);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQualifiersBase_ConstStatus_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQualifiersBase_ConstStatus_Rpl_ObjRefs;

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseQualifiers_QueueNames  ""

#define IIGVerifyCaseQualifiers_MethodNames  ""

#define IIGVerifyCaseQualifiersMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseQualifiers_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseQualifiers_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseQualifiers_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseQualifiersMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseQualifiers_t
OSClassDescription_IIGVerifyCaseQualifiers =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseQualifiers_t),
        .name                    = "IIGVerifyCaseQualifiers",
        .superName               = "IIGVerifyCaseQualifiersBase",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiers_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiers_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseQualifiers_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiers_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseQualifiers_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiers_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseQualifiersMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQualifiers_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseQualifiers_QueueNames,
    .methodNames     = IIGVerifyCaseQualifiers_MethodNames,
    .metaMethodNames = IIGVerifyCaseQualifiersMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseQualifiersMetaClass;

static kern_return_t
IIGVerifyCaseQualifiers_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseQualifiers_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseQualifiers.base,
    .metaPointer       = &gIIGVerifyCaseQualifiersMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseQualifiers),

    .resv2             = {0},

    .New               = &IIGVerifyCaseQualifiers_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseQualifiers_Declaration;
const void * const
gIIGVerifyCaseQualifiers_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseQualifiers_Class;

static kern_return_t
IIGVerifyCaseQualifiers_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseQualifiersMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseQualifiersMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseQualifiers) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseQualifiers::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseQualifiers::_Dispatch(IIGVerifyCaseQualifiers * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseQualifiersBase_OverrideMe_ID:
        {
            ret = IIGVerifyCaseQualifiersBase::OverrideMe_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQualifiersBase::OverrideMe_Handler, *self, &IIGVerifyCaseQualifiers::OverrideMe_Impl));
            break;
        }
        case IIGVerifyCaseQualifiersBase_ConstStatus_ID:
        {
            ret = IIGVerifyCaseQualifiersBase::ConstStatus_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQualifiersBase::ConstStatus_Handler, *self, &IIGVerifyCaseQualifiers::ConstStatus_Impl));
            break;
        }
        case IIGVerifyCaseQualifiers_BoolStatus_ID:
        {
            ret = IIGVerifyCaseQualifiers::BoolStatus_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQualifiers::BoolStatus_Handler, *self, &IIGVerifyCaseQualifiers::BoolStatus_Impl));
            break;
        }

        default:
            ret = IIGVerifyCaseQualifiersBase::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseQualifiers::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseQualifiersMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

bool
IIGVerifyCaseQualifiers::BoolStatus(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQualifiers_BoolStatus_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQualifiers_BoolStatus_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQualifiers_BoolStatus_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQualifiers_BoolStatus_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQualifiers_BoolStatus_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQualifiers_BoolStatus_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQualifiers_BoolStatus_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQualifiers_BoolStatus_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQualifiers::BoolStatus_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        BoolStatus_Handler func)
{
    IIGVerifyCaseQualifiers_BoolStatus_Invocation rpc = { _rpc };
    IIGVerifyCaseQualifiers_BoolStatus_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQualifiers_BoolStatus_Msg *         message = rpc.message;
    const IIGVerifyCaseQualifiers_BoolStatus_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQualifiers_BoolStatus_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQualifiers_BoolStatus_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQualifiers_BoolStatus_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQualifiers_BoolStatus_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQualifiers_BoolStatus_Rpl_ObjRefs;

    return (ret);
}



