/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseActionQueuesMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseActionQueuesMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseActionQueuesMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_ObjRefs (2)

struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Invocation;
struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
};
struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
    IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_ObjRefs (2)

struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseActionQueuesMore_QueueNames  "" \
    "\033"IIGVerifyCaseActionQueueA"" \
    "\033"IIGVerifyCaseActionQueueB""

#define IIGVerifyCaseActionQueuesMore_MethodNames  "" \
    "\021CompletionOnQueue" \
    "\015SubmitOnQueue"

#define IIGVerifyCaseActionQueuesMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 2];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseActionQueuesMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseActionQueuesMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseActionQueuesMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t
OSClassDescription_IIGVerifyCaseActionQueuesMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseActionQueuesMore_t),
        .name                    = "IIGVerifyCaseActionQueuesMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 2,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseActionQueuesMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseActionQueuesMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseActionQueuesMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionQueuesMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseActionQueuesMore_CompletionOnQueue_ID,
        IIGVerifyCaseActionQueuesMore_SubmitOnQueue_ID,
        0x0000000000000000,
        0x0000000000000001,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseActionQueuesMore_QueueNames,
    .methodNames     = IIGVerifyCaseActionQueuesMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseActionQueuesMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseActionQueuesMoreMetaClass;

static kern_return_t
IIGVerifyCaseActionQueuesMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseActionQueuesMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseActionQueuesMore.base,
    .metaPointer       = &gIIGVerifyCaseActionQueuesMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseActionQueuesMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseActionQueuesMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseActionQueuesMore_Declaration;
const void * const
gIIGVerifyCaseActionQueuesMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseActionQueuesMore_Class;

static kern_return_t
IIGVerifyCaseActionQueuesMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseActionQueuesMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionQueuesMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseActionQueuesMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseActionQueuesMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::_Dispatch(IIGVerifyCaseActionQueuesMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseActionQueuesMore_CompletionOnQueue_ID:
        {
            ret = IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Handler, *self, &IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Impl));
            break;
        }
        case IIGVerifyCaseActionQueuesMore_SubmitOnQueue_ID:
        {
            ret = IIGVerifyCaseActionQueuesMore::SubmitOnQueue_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionQueuesMore::SubmitOnQueue_Handler, *self, &IIGVerifyCaseActionQueuesMore::SubmitOnQueue_Impl));
            break;
        }
#if KERNEL
        case IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_ID:
        {
            ret = IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Handler, *self, &IIGVerifyCaseActionQueuesMore::KernelCompletionOnQueue_Impl), OSTypeID(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue));
            break;
        }
#endif /* !KERNEL */

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseActionQueuesMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseActionQueuesMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::CompletionOnQueue(
        IORPC rpc,
        OSAction * action,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionQueuesMore_CompletionOnQueue_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.token = token;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::SubmitOnQueue(
        OSAction * completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionQueuesMore_SubmitOnQueue_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->completion__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.completion = (OSObjectRef) completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseActionQueuesMore_SubmitOnQueue_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::CreateActionKernelCompletionOnQueue(size_t referenceSize, OSAction ** action)
{
    kern_return_t ret;

#if defined(IOKIT_ENABLE_SHARED_PTR)
    OSSharedPtr<OSString>
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
    OSString *
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    typeName = OSString::withCString("OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue");
    if (!typeName) {
        return kIOReturnNoMemory;
    }
    ret = OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue::CreateWithTypeName(this,
                           IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_ID,
                           IIGVerifyCaseActionQueuesMore_CompletionOnQueue_ID,
                           referenceSize,
#if defined(IOKIT_ENABLE_SHARED_PTR)
                           typeName.get(),
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
                           typeName,
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
                           action);

#if !defined(IOKIT_ENABLE_SHARED_PTR)
    typeName->release();
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    return (ret);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionOnQueue_Handler func)
{
    return IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::CompletionOnQueue_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionOnQueue_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Invocation rpc = { _rpc };
    IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg *         message = rpc.message;
    const IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(token));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionQueuesMore::SubmitOnQueue_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitOnQueue_Handler func)
{
    IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Invocation rpc = { _rpc };
    IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg *         message = rpc.message;
    const IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSAction * completion;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    completion = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(completion));
    if (!completion && MESSAGE_CONTENT(completion)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        completion,
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseActionQueuesMore_SubmitOnQueue_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Rpl_ObjRefs;

    return (ret);
}

#if KERNEL
OSDefineMetaClassAndStructors(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue, OSAction);
#endif /* KERNEL */

#if !KERNEL

#define OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_QueueNames  ""

#define OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_MethodNames  ""

#define OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass_MethodNames  ""

struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_QueueNames)];
    char               methodNames[sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_MethodNames)];
    char               metaMethodNames[sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass_MethodNames)];
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t
OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t),
        .name                    = "OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue",
        .superName               = "OSAction",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t, metaMethodOptions),
        .queueNamesSize       = sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t, queueNames),
        .methodNamesSize         = sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t, methodNames),
        .metaMethodNamesSize     = sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_QueueNames,
    .methodNames     = OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_MethodNames,
    .metaMethodNames = OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass_MethodNames,
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
OSMetaClass * gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_New(OSMetaClass * instance);

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const OSClassLoadInformation
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Class = 
{
    .description       = &OSClassDescription_OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue.base,
    .metaPointer       = &gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue),

    .resv2             = {0},

    .New               = &OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_New,
    .resv3             = {0},

};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
extern const void * const
gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Declaration;
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const void * const
gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Declaration
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Class;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_New(OSMetaClass * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass::New(OSObject * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue::_Dispatch(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSAction::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



