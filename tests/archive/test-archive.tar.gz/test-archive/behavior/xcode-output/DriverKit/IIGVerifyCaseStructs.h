/* iig(DriverKit-440) generated from IIGVerifyCaseStructs.iig */

/* IIGVerifyCaseStructs.iig:1-11 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESTRUCTS_H
#define _DRIVERKIT_IIGVerifyCASESTRUCTS_H

struct IIGVerifyCaseSmallStruct
{
	uint64_t wide;
	uint32_t word;
};

/* source class IIGVerifyCaseStructs IIGVerifyCaseStructs.iig:12-23 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseStructs : public OSObject
{
public:
	virtual kern_return_t
	StructInput(const IIGVerifyCaseSmallStruct * input) LOCAL;

	virtual kern_return_t
	StructOutput(IIGVerifyCaseSmallStruct * output) LOCAL;

	virtual kern_return_t
	StructRoundTrip(const IIGVerifyCaseSmallStruct * input,
	    IIGVerifyCaseSmallStruct * output) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseStructs IIGVerifyCaseStructs.iig:12-23 */

#define IIGVerifyCaseStructs_StructInput_ID            0xea39732983c20d43ULL
#define IIGVerifyCaseStructs_StructOutput_ID            0xd0d4564a10f88278ULL
#define IIGVerifyCaseStructs_StructRoundTrip_ID            0xd1726d0b0b93cdf1ULL

#define IIGVerifyCaseStructs_StructInput_Args \
        const IIGVerifyCaseSmallStruct * input

#define IIGVerifyCaseStructs_StructOutput_Args \
        IIGVerifyCaseSmallStruct * output

#define IIGVerifyCaseStructs_StructRoundTrip_Args \
        const IIGVerifyCaseSmallStruct * input, \
        IIGVerifyCaseSmallStruct * output

#define IIGVerifyCaseStructs_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseStructs * self, const IORPC rpc);\
\
    kern_return_t\
    StructInput(\
        const IIGVerifyCaseSmallStruct * input,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    StructOutput(\
        IIGVerifyCaseSmallStruct * output,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    StructRoundTrip(\
        const IIGVerifyCaseSmallStruct * input,\
        IIGVerifyCaseSmallStruct * output,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    StructInput_Impl(IIGVerifyCaseStructs_StructInput_Args);\
\
    kern_return_t\
    StructOutput_Impl(IIGVerifyCaseStructs_StructOutput_Args);\
\
    kern_return_t\
    StructRoundTrip_Impl(IIGVerifyCaseStructs_StructRoundTrip_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*StructInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructs_StructInput_Args);\
    static kern_return_t\
    StructInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        StructInput_Handler func);\
\
    typedef kern_return_t (*StructOutput_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructs_StructOutput_Args);\
    static kern_return_t\
    StructOutput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        StructOutput_Handler func);\
\
    typedef kern_return_t (*StructRoundTrip_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructs_StructRoundTrip_Args);\
    static kern_return_t\
    StructRoundTrip_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        StructRoundTrip_Handler func);\
\


#define IIGVerifyCaseStructs_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseStructs_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseStructsMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseStructs_Class;

class IIGVerifyCaseStructsMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseStructsInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseStructs_IVars;
struct IIGVerifyCaseStructs_LocalIVars;

class IIGVerifyCaseStructs : public OSObject, public IIGVerifyCaseStructsInterface
{
#if !KERNEL
    friend class IIGVerifyCaseStructsMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseStructs_DECLARE_IVARS
IIGVerifyCaseStructs_DECLARE_IVARS
#else /* IIGVerifyCaseStructs_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseStructs_IVars * ivars;
        IIGVerifyCaseStructs_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseStructs_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseStructsMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseStructs_Methods
    IIGVerifyCaseStructs_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseStructs.iig:25- */

#endif /* _DRIVERKIT_IIGVerifyCASESTRUCTS_H */
