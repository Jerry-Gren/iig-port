/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseMethodAttributesMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseMethodAttributesMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseMethodAttributesBase.h>
#include <DriverKit/IIGVerifyCaseMethodAttributesMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_ObjRefs (1)

struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMethodAttributesBase_BaseAvailable_Invocation;
struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_ObjRefs (1)

struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMethodAttributesMore_FinalAvailable_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseMethodAttributesBase_QueueNames  ""

#define IIGVerifyCaseMethodAttributesBase_MethodNames  ""

#define IIGVerifyCaseMethodAttributesBaseMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseMethodAttributesBase_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseMethodAttributesBase_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseMethodAttributesBaseMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t
OSClassDescription_IIGVerifyCaseMethodAttributesBase =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseMethodAttributesBase_t),
        .name                    = "IIGVerifyCaseMethodAttributesBase",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseMethodAttributesBase_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseMethodAttributesBase_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseMethodAttributesBaseMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesBase_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseMethodAttributesBase_QueueNames,
    .methodNames     = IIGVerifyCaseMethodAttributesBase_MethodNames,
    .metaMethodNames = IIGVerifyCaseMethodAttributesBaseMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseMethodAttributesBaseMetaClass;

static kern_return_t
IIGVerifyCaseMethodAttributesBase_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseMethodAttributesBase_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseMethodAttributesBase.base,
    .metaPointer       = &gIIGVerifyCaseMethodAttributesBaseMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseMethodAttributesBase),

    .resv2             = {0},

    .New               = &IIGVerifyCaseMethodAttributesBase_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseMethodAttributesBase_Declaration;
const void * const
gIIGVerifyCaseMethodAttributesBase_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseMethodAttributesBase_Class;

static kern_return_t
IIGVerifyCaseMethodAttributesBase_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseMethodAttributesBaseMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseMethodAttributesBaseMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseMethodAttributesBase) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseMethodAttributesBase::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseMethodAttributesBase::_Dispatch(IIGVerifyCaseMethodAttributesBase * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseMethodAttributesBase::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseMethodAttributesBaseMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseMethodAttributesBase::BaseAvailable(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMethodAttributesBase_BaseAvailable_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMethodAttributesBase_BaseAvailable_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMethodAttributesBase::BaseAvailable_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        BaseAvailable_Handler func)
{
    IIGVerifyCaseMethodAttributesBase_BaseAvailable_Invocation rpc = { _rpc };
    IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg *         message = rpc.message;
    const IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMethodAttributesBase_BaseAvailable_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMethodAttributesBase_BaseAvailable_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMethodAttributesBase_BaseAvailable_Rpl_ObjRefs;

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseMethodAttributesMore_QueueNames  ""

#define IIGVerifyCaseMethodAttributesMore_MethodNames  ""

#define IIGVerifyCaseMethodAttributesMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseMethodAttributesMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseMethodAttributesMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseMethodAttributesMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t
OSClassDescription_IIGVerifyCaseMethodAttributesMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseMethodAttributesMore_t),
        .name                    = "IIGVerifyCaseMethodAttributesMore",
        .superName               = "IIGVerifyCaseMethodAttributesBase",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseMethodAttributesMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseMethodAttributesMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseMethodAttributesMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodAttributesMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseMethodAttributesMore_QueueNames,
    .methodNames     = IIGVerifyCaseMethodAttributesMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseMethodAttributesMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseMethodAttributesMoreMetaClass;

static kern_return_t
IIGVerifyCaseMethodAttributesMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseMethodAttributesMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseMethodAttributesMore.base,
    .metaPointer       = &gIIGVerifyCaseMethodAttributesMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseMethodAttributesMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseMethodAttributesMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseMethodAttributesMore_Declaration;
const void * const
gIIGVerifyCaseMethodAttributesMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseMethodAttributesMore_Class;

static kern_return_t
IIGVerifyCaseMethodAttributesMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseMethodAttributesMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseMethodAttributesMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseMethodAttributesMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseMethodAttributesMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseMethodAttributesMore::_Dispatch(IIGVerifyCaseMethodAttributesMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseMethodAttributesBase_BaseAvailable_ID:
        {
            ret = IIGVerifyCaseMethodAttributesBase::BaseAvailable_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseMethodAttributesBase::BaseAvailable_Handler, *self, &IIGVerifyCaseMethodAttributesMore::BaseAvailable_Impl));
            break;
        }
        case IIGVerifyCaseMethodAttributesMore_FinalAvailable_ID:
        {
            ret = IIGVerifyCaseMethodAttributesMore::FinalAvailable_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseMethodAttributesMore::FinalAvailable_Handler, *self, &IIGVerifyCaseMethodAttributesMore::FinalAvailable_Impl));
            break;
        }

        default:
            ret = IIGVerifyCaseMethodAttributesBase::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseMethodAttributesMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseMethodAttributesMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseMethodAttributesMore::FinalAvailable(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMethodAttributesMore_FinalAvailable_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMethodAttributesMore_FinalAvailable_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMethodAttributesMore::FinalAvailable_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        FinalAvailable_Handler func)
{
    IIGVerifyCaseMethodAttributesMore_FinalAvailable_Invocation rpc = { _rpc };
    IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg *         message = rpc.message;
    const IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMethodAttributesMore_FinalAvailable_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMethodAttributesMore_FinalAvailable_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMethodAttributesMore_FinalAvailable_Rpl_ObjRefs;

    return (ret);
}



