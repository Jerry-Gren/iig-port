/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseMethodSuffixOrderMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseMethodSuffixOrderMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseMethodSuffixOrderBase.h>
#include <DriverKit/IIGVerifyCaseMethodSuffixOrderMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_ObjRefs (1)

struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseMethodSuffixOrderBase_QueueNames  "" \
    "\040"IIGVerifyCaseMethodSuffixQueue""

#define IIGVerifyCaseMethodSuffixOrderBase_MethodNames  "" \
    "\017QueuedAvailable"

#define IIGVerifyCaseMethodSuffixOrderBaseMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 1];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseMethodSuffixOrderBase_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseMethodSuffixOrderBase_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseMethodSuffixOrderBaseMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t
OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t),
        .name                    = "IIGVerifyCaseMethodSuffixOrderBase",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 1,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseMethodSuffixOrderBase_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseMethodSuffixOrderBase_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseMethodSuffixOrderBaseMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID,
        0x0000000000000000,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseMethodSuffixOrderBase_QueueNames,
    .methodNames     = IIGVerifyCaseMethodSuffixOrderBase_MethodNames,
    .metaMethodNames = IIGVerifyCaseMethodSuffixOrderBaseMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseMethodSuffixOrderBaseMetaClass;

static kern_return_t
IIGVerifyCaseMethodSuffixOrderBase_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseMethodSuffixOrderBase_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseMethodSuffixOrderBase.base,
    .metaPointer       = &gIIGVerifyCaseMethodSuffixOrderBaseMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseMethodSuffixOrderBase),

    .resv2             = {0},

    .New               = &IIGVerifyCaseMethodSuffixOrderBase_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseMethodSuffixOrderBase_Declaration;
const void * const
gIIGVerifyCaseMethodSuffixOrderBase_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseMethodSuffixOrderBase_Class;

static kern_return_t
IIGVerifyCaseMethodSuffixOrderBase_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseMethodSuffixOrderBaseMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseMethodSuffixOrderBaseMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseMethodSuffixOrderBase) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseMethodSuffixOrderBase::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseMethodSuffixOrderBase::_Dispatch(IIGVerifyCaseMethodSuffixOrderBase * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseMethodSuffixOrderBase::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseMethodSuffixOrderBaseMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseMethodSuffixOrderBase::QueuedAvailable(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseMethodSuffixOrderBase::QueuedAvailable_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        QueuedAvailable_Handler func)
{
    IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Invocation rpc = { _rpc };
    IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg *         message = rpc.message;
    const IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Rpl_ObjRefs;

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseMethodSuffixOrderMore_QueueNames  "" \
    "\040"IIGVerifyCaseMethodSuffixQueue""

#define IIGVerifyCaseMethodSuffixOrderMore_MethodNames  "" \
    "\017QueuedAvailable"

#define IIGVerifyCaseMethodSuffixOrderMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 1];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseMethodSuffixOrderMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseMethodSuffixOrderMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseMethodSuffixOrderMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t
OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t),
        .name                    = "IIGVerifyCaseMethodSuffixOrderMore",
        .superName               = "IIGVerifyCaseMethodSuffixOrderBase",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 1,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseMethodSuffixOrderMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseMethodSuffixOrderMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseMethodSuffixOrderMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID,
        0x0000000000000000,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseMethodSuffixOrderMore_QueueNames,
    .methodNames     = IIGVerifyCaseMethodSuffixOrderMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseMethodSuffixOrderMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseMethodSuffixOrderMoreMetaClass;

static kern_return_t
IIGVerifyCaseMethodSuffixOrderMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseMethodSuffixOrderMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseMethodSuffixOrderMore.base,
    .metaPointer       = &gIIGVerifyCaseMethodSuffixOrderMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseMethodSuffixOrderMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseMethodSuffixOrderMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseMethodSuffixOrderMore_Declaration;
const void * const
gIIGVerifyCaseMethodSuffixOrderMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseMethodSuffixOrderMore_Class;

static kern_return_t
IIGVerifyCaseMethodSuffixOrderMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseMethodSuffixOrderMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseMethodSuffixOrderMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseMethodSuffixOrderMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseMethodSuffixOrderMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseMethodSuffixOrderMore::_Dispatch(IIGVerifyCaseMethodSuffixOrderMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID:
        {
            ret = IIGVerifyCaseMethodSuffixOrderBase::QueuedAvailable_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseMethodSuffixOrderBase::QueuedAvailable_Handler, *self, &IIGVerifyCaseMethodSuffixOrderMore::QueuedAvailable_Impl));
            break;
        }

        default:
            ret = IIGVerifyCaseMethodSuffixOrderBase::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseMethodSuffixOrderMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseMethodSuffixOrderMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



