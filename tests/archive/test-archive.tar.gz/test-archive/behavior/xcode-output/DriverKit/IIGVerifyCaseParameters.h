/* iig(DriverKit-440) generated from IIGVerifyCaseParameters.iig */

/* IIGVerifyCaseParameters.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */
#include <DriverKit/IOBufferMemoryDescriptor.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEPARAMETERS_H
#define _DRIVERKIT_IIGVerifyCASEPARAMETERS_H

typedef uint64_t IIGVerifyScalarArray4[4];

/* source class IIGVerifyCaseParameters IIGVerifyCaseParameters.iig:9-30 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseParameters : public OSObject
{
public:
	virtual kern_return_t
	InlineInput(const uint8_t bytes[16], uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	InlineOutput(uint32_t valuesCount, IIGVerifyScalarArray4 values) LOCAL;

	virtual kern_return_t
	ObjectRefs(OSObject * input, OSObject ** output) LOCAL;

	virtual kern_return_t
	BufferObjects(IOBufferMemoryDescriptor * input,
	    IOBufferMemoryDescriptor ** output) LOCAL;

	virtual kern_return_t
	SerializableObjects(OSDictionary * input, OSData ** output) LOCAL;

	virtual kern_return_t
	PortDispositions(mach_port_t made PORTMAKESEND,
	    mach_port_t copied PORTCOPYSEND) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseParameters IIGVerifyCaseParameters.iig:9-30 */

#define IIGVerifyCaseParameters_InlineInput_ID            0xefc74cfed9e0ac99ULL
#define IIGVerifyCaseParameters_InlineOutput_ID            0xbe943d6a4781af44ULL
#define IIGVerifyCaseParameters_ObjectRefs_ID            0xcba384f3cef1a41eULL
#define IIGVerifyCaseParameters_BufferObjects_ID            0xa74092d33777f668ULL
#define IIGVerifyCaseParameters_SerializableObjects_ID            0x8204ca7f6557d338ULL
#define IIGVerifyCaseParameters_PortDispositions_ID            0x9d10eb95d5426288ULL

#define IIGVerifyCaseParameters_InlineInput_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseParameters_InlineOutput_Args \
        uint32_t valuesCount, \
        unsigned long long * values

#define IIGVerifyCaseParameters_ObjectRefs_Args \
        OSObject * input, \
        OSObject ** output

#define IIGVerifyCaseParameters_BufferObjects_Args \
        IOBufferMemoryDescriptor * input, \
        IOBufferMemoryDescriptor ** output

#define IIGVerifyCaseParameters_SerializableObjects_Args \
        OSDictionary * input, \
        OSData ** output

#define IIGVerifyCaseParameters_PortDispositions_Args \
        mach_port_t made, \
        mach_port_t copied

#define IIGVerifyCaseParameters_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseParameters * self, const IORPC rpc);\
\
    kern_return_t\
    InlineInput(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InlineOutput(\
        uint32_t valuesCount,\
        unsigned long long * values,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ObjectRefs(\
        OSObject * input,\
        OSObject ** output,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    BufferObjects(\
        IOBufferMemoryDescriptor * input,\
        IOBufferMemoryDescriptor ** output,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SerializableObjects(\
        OSDictionary * input,\
        OSData ** output,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    PortDispositions(\
        mach_port_t made,\
        mach_port_t copied,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InlineInput_Impl(IIGVerifyCaseParameters_InlineInput_Args);\
\
    kern_return_t\
    InlineOutput_Impl(IIGVerifyCaseParameters_InlineOutput_Args);\
\
    kern_return_t\
    ObjectRefs_Impl(IIGVerifyCaseParameters_ObjectRefs_Args);\
\
    kern_return_t\
    BufferObjects_Impl(IIGVerifyCaseParameters_BufferObjects_Args);\
\
    kern_return_t\
    SerializableObjects_Impl(IIGVerifyCaseParameters_SerializableObjects_Args);\
\
    kern_return_t\
    PortDispositions_Impl(IIGVerifyCaseParameters_PortDispositions_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InlineInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseParameters_InlineInput_Args);\
    static kern_return_t\
    InlineInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineInput_Handler func);\
\
    typedef kern_return_t (*InlineOutput_Handler)(OSMetaClassBase * target, IIGVerifyCaseParameters_InlineOutput_Args);\
    static kern_return_t\
    InlineOutput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineOutput_Handler func);\
\
    typedef kern_return_t (*ObjectRefs_Handler)(OSMetaClassBase * target, IIGVerifyCaseParameters_ObjectRefs_Args);\
    static kern_return_t\
    ObjectRefs_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ObjectRefs_Handler func);\
\
    typedef kern_return_t (*BufferObjects_Handler)(OSMetaClassBase * target, IIGVerifyCaseParameters_BufferObjects_Args);\
    static kern_return_t\
    BufferObjects_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        BufferObjects_Handler func);\
\
    typedef kern_return_t (*SerializableObjects_Handler)(OSMetaClassBase * target, IIGVerifyCaseParameters_SerializableObjects_Args);\
    static kern_return_t\
    SerializableObjects_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SerializableObjects_Handler func);\
\
    typedef kern_return_t (*PortDispositions_Handler)(OSMetaClassBase * target, IIGVerifyCaseParameters_PortDispositions_Args);\
    static kern_return_t\
    PortDispositions_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        PortDispositions_Handler func);\
\


#define IIGVerifyCaseParameters_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseParameters_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseParametersMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseParameters_Class;

class IIGVerifyCaseParametersMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseParametersInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseParameters_IVars;
struct IIGVerifyCaseParameters_LocalIVars;

class IIGVerifyCaseParameters : public OSObject, public IIGVerifyCaseParametersInterface
{
#if !KERNEL
    friend class IIGVerifyCaseParametersMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseParameters_DECLARE_IVARS
IIGVerifyCaseParameters_DECLARE_IVARS
#else /* IIGVerifyCaseParameters_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseParameters_IVars * ivars;
        IIGVerifyCaseParameters_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseParameters_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseParametersMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseParameters_Methods
    IIGVerifyCaseParameters_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseParameters.iig:32- */

#endif /* _DRIVERKIT_IIGVerifyCASEPARAMETERS_H */
