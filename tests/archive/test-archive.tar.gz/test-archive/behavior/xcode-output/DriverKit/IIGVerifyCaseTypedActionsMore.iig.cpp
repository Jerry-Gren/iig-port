/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseTypedActionsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseTypedActionsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseTypedActionsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseTypedActionsMore_Completion_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    kern_return_t  status;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionsMore_Completion_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseTypedActionsMore_Completion_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseTypedActionsMore_Completion_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionsMore_Completion_Msg_ObjRefs (2)

struct IIGVerifyCaseTypedActionsMore_Completion_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionsMore_Completion_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedActionsMore_Completion_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedActionsMore_Completion_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionsMore_Completion_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionsMore_Completion_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedActionsMore_Completion_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedActionsMore_Completion_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionsMore_Completion_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedActionsMore_Completion_Invocation;
struct IIGVerifyCaseTypedActionsMore_Submit_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionsMore_Submit_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
};
struct IIGVerifyCaseTypedActionsMore_Submit_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
    IIGVerifyCaseTypedActionsMore_Submit_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionsMore_Submit_Msg_ObjRefs (2)

struct IIGVerifyCaseTypedActionsMore_Submit_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedActionsMore_Submit_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedActionsMore_Submit_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedActionsMore_Submit_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedActionsMore_Submit_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionsMore_Submit_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedActionsMore_Submit_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedActionsMore_Submit_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedActionsMore_Submit_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedActionsMore_Submit_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseTypedActionsMore_QueueNames  ""

#define IIGVerifyCaseTypedActionsMore_MethodNames  ""

#define IIGVerifyCaseTypedActionsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseTypedActionsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseTypedActionsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseTypedActionsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t
OSClassDescription_IIGVerifyCaseTypedActionsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseTypedActionsMore_t),
        .name                    = "IIGVerifyCaseTypedActionsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseTypedActionsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseTypedActionsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseTypedActionsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedActionsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseTypedActionsMore_QueueNames,
    .methodNames     = IIGVerifyCaseTypedActionsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseTypedActionsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseTypedActionsMoreMetaClass;

static kern_return_t
IIGVerifyCaseTypedActionsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseTypedActionsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseTypedActionsMore.base,
    .metaPointer       = &gIIGVerifyCaseTypedActionsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseTypedActionsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseTypedActionsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseTypedActionsMore_Declaration;
const void * const
gIIGVerifyCaseTypedActionsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseTypedActionsMore_Class;

static kern_return_t
IIGVerifyCaseTypedActionsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseTypedActionsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedActionsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseTypedActionsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseTypedActionsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::_Dispatch(IIGVerifyCaseTypedActionsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseTypedActionsMore_Completion_ID:
        {
            ret = IIGVerifyCaseTypedActionsMore::Completion_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionsMore::Completion_Handler, *self, &IIGVerifyCaseTypedActionsMore::Completion_Impl));
            break;
        }
        case IIGVerifyCaseTypedActionsMore_Submit_ID:
        {
            ret = IIGVerifyCaseTypedActionsMore::Submit_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionsMore::Submit_Handler, *self, &IIGVerifyCaseTypedActionsMore::Submit_Impl));
            break;
        }
#if KERNEL
        case IIGVerifyCaseTypedActionsMore_KernelCompletion_ID:
        {
            ret = IIGVerifyCaseTypedActionsMore::Completion_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedActionsMore::Completion_Handler, *self, &IIGVerifyCaseTypedActionsMore::KernelCompletion_Impl), OSTypeID(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion));
            break;
        }
#endif /* !KERNEL */

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseTypedActionsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseTypedActionsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::Completion(
        IORPC rpc,
        OSAction * action,
        kern_return_t status,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseTypedActionsMore_Completion_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedActionsMore_Completion_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedActionsMore_Completion_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.status = status;

    msg->content.token = token;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::Submit(
        OSAction * completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedActionsMore_Submit_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedActionsMore_Submit_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedActionsMore_Submit_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedActionsMore_Submit_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedActionsMore_Submit_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedActionsMore_Submit_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->completion__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.completion = (OSObjectRef) completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedActionsMore_Submit_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedActionsMore_Submit_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::CreateActionKernelCompletion(size_t referenceSize, OSAction ** action)
{
    kern_return_t ret;

#if defined(IOKIT_ENABLE_SHARED_PTR)
    OSSharedPtr<OSString>
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
    OSString *
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    typeName = OSString::withCString("OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion");
    if (!typeName) {
        return kIOReturnNoMemory;
    }
    ret = OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion::CreateWithTypeName(this,
                           IIGVerifyCaseTypedActionsMore_KernelCompletion_ID,
                           IIGVerifyCaseTypedActionsMore_Completion_ID,
                           referenceSize,
#if defined(IOKIT_ENABLE_SHARED_PTR)
                           typeName.get(),
#else /* defined(IOKIT_ENABLE_SHARED_PTR) */
                           typeName,
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
                           action);

#if !defined(IOKIT_ENABLE_SHARED_PTR)
    typeName->release();
#endif /* !defined(IOKIT_ENABLE_SHARED_PTR) */
    return (ret);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::Completion_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Completion_Handler func)
{
    return IIGVerifyCaseTypedActionsMore::Completion_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::Completion_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Completion_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseTypedActionsMore_Completion_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedActionsMore_Completion_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedActionsMore_Completion_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedActionsMore_Completion_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedActionsMore_Completion_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedActionsMore_Completion_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedActionsMore_Completion_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(status),
        MESSAGE_CONTENT(token));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedActionsMore::Submit_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Submit_Handler func)
{
    IIGVerifyCaseTypedActionsMore_Submit_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedActionsMore_Submit_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedActionsMore_Submit_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedActionsMore_Submit_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedActionsMore_Submit_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSAction * completion;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedActionsMore_Submit_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedActionsMore_Submit_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    completion = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(completion));
    if (!completion && MESSAGE_CONTENT(completion)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        completion,
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedActionsMore_Submit_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedActionsMore_Submit_Rpl_ObjRefs;

    return (ret);
}

#if KERNEL
OSDefineMetaClassAndStructors(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion, OSAction);
#endif /* KERNEL */

#if !KERNEL

#define OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_QueueNames  ""

#define OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_MethodNames  ""

#define OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass_MethodNames  ""

struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_QueueNames)];
    char               methodNames[sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_MethodNames)];
    char               metaMethodNames[sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass_MethodNames)];
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t
OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t),
        .name                    = "OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion",
        .superName               = "OSAction",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t, metaMethodOptions),
        .queueNamesSize       = sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t, queueNames),
        .methodNamesSize         = sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t, methodNames),
        .metaMethodNamesSize     = sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_QueueNames,
    .methodNames     = OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_MethodNames,
    .metaMethodNames = OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass_MethodNames,
};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
OSMetaClass * gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_New(OSMetaClass * instance);

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const OSClassLoadInformation
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Class = 
{
    .description       = &OSClassDescription_OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion.base,
    .metaPointer       = &gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion),

    .resv2             = {0},

    .New               = &OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_New,
    .resv3             = {0},

};

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
extern const void * const
gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Declaration;
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
const void * const
gOSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Declaration
 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_Class;

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
static kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion_New(OSMetaClass * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

 __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer")))
kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass::New(OSObject * instance)
{
    if (!new(instance) OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion::_Dispatch(OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSAction::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletion::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
OSAction_IIGVerifyCaseTypedActionsMore_KernelCompletionMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



