/* iig(DriverKit-440) generated from IIGVerifyCaseMethodSuffixOrderMore.iig */

/* IIGVerifyCaseMethodSuffixOrderMore.iig:1-7 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEMETHODSUFFIXORDERMORE_H
#define _DRIVERKIT_IIGVerifyCASEMETHODSUFFIXORDERMORE_H

#define kIIGVerifyCaseMethodSuffixQueue "IIGVerifyCaseMethodSuffixQueue"

/* source class IIGVerifyCaseMethodSuffixOrderBase IIGVerifyCaseMethodSuffixOrderMore.iig:8-15 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseMethodSuffixOrderBase : public OSObject
{
public:
	virtual kern_return_t
	QueuedAvailable(uint64_t value)
	    LOCAL
	    QUEUENAME(kIIGVerifyCaseMethodSuffixQueue)
	    __attribute__((availability(driverkit,introduced=20.0))) = 0;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseMethodSuffixOrderBase IIGVerifyCaseMethodSuffixOrderMore.iig:8-15 */

#define IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_ID            0xacf742086f148304ULL

#define IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Args \
        uint64_t value

#define IIGVerifyCaseMethodSuffixOrderBase_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseMethodSuffixOrderBase * self, const IORPC rpc);\
\
    kern_return_t\
    QueuedAvailable(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL) __attribute__((availability(driverkit,introduced=20.0)));\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*QueuedAvailable_Handler)(OSMetaClassBase * target, IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Args);\
    static kern_return_t\
    QueuedAvailable_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        QueuedAvailable_Handler func);\
\


#define IIGVerifyCaseMethodSuffixOrderBase_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseMethodSuffixOrderBase_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseMethodSuffixOrderBaseMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseMethodSuffixOrderBase_Class;

class IIGVerifyCaseMethodSuffixOrderBaseMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseMethodSuffixOrderBaseInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseMethodSuffixOrderBase_IVars;
struct IIGVerifyCaseMethodSuffixOrderBase_LocalIVars;

class IIGVerifyCaseMethodSuffixOrderBase : public OSObject, public IIGVerifyCaseMethodSuffixOrderBaseInterface
{
#if !KERNEL
    friend class IIGVerifyCaseMethodSuffixOrderBaseMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseMethodSuffixOrderBase_DECLARE_IVARS
IIGVerifyCaseMethodSuffixOrderBase_DECLARE_IVARS
#else /* IIGVerifyCaseMethodSuffixOrderBase_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseMethodSuffixOrderBase_IVars * ivars;
        IIGVerifyCaseMethodSuffixOrderBase_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseMethodSuffixOrderBase_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseMethodSuffixOrderBaseMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseMethodSuffixOrderBase_Methods
    IIGVerifyCaseMethodSuffixOrderBase_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */


/* source class IIGVerifyCaseMethodSuffixOrderMore IIGVerifyCaseMethodSuffixOrderMore.iig:18-27 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseMethodSuffixOrderMore : public IIGVerifyCaseMethodSuffixOrderBase
{
public:
	virtual kern_return_t
	QueuedAvailable(uint64_t value)
	    override
	    final
	    LOCAL
	    QUEUENAME(kIIGVerifyCaseMethodSuffixQueue)
	    __attribute__((availability(driverkit,introduced=20.0,message="same queue")));
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseMethodSuffixOrderMore IIGVerifyCaseMethodSuffixOrderMore.iig:18-27 */


#define IIGVerifyCaseMethodSuffixOrderMore_QueuedAvailable_Args \
        uint64_t value

#define IIGVerifyCaseMethodSuffixOrderMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseMethodSuffixOrderMore * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    QueuedAvailable_Impl(IIGVerifyCaseMethodSuffixOrderBase_QueuedAvailable_Args);\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyCaseMethodSuffixOrderMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseMethodSuffixOrderMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseMethodSuffixOrderMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseMethodSuffixOrderMore_Class;

class IIGVerifyCaseMethodSuffixOrderMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseMethodSuffixOrderMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseMethodSuffixOrderMore_IVars;
struct IIGVerifyCaseMethodSuffixOrderMore_LocalIVars;

class IIGVerifyCaseMethodSuffixOrderMore : public IIGVerifyCaseMethodSuffixOrderBase, public IIGVerifyCaseMethodSuffixOrderMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseMethodSuffixOrderMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseMethodSuffixOrderMore_DECLARE_IVARS
IIGVerifyCaseMethodSuffixOrderMore_DECLARE_IVARS
#else /* IIGVerifyCaseMethodSuffixOrderMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseMethodSuffixOrderMore_IVars * ivars;
        IIGVerifyCaseMethodSuffixOrderMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseMethodSuffixOrderMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseMethodSuffixOrderMoreMetaClass; };
#endif /* KERNEL */

    using super = IIGVerifyCaseMethodSuffixOrderBase;

#if !KERNEL
    IIGVerifyCaseMethodSuffixOrderMore_Methods
    IIGVerifyCaseMethodSuffixOrderMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseMethodSuffixOrderMore.iig:29- */

#endif /* _DRIVERKIT_IIGVerifyCASEMETHODSUFFIXORDERMORE_H */
