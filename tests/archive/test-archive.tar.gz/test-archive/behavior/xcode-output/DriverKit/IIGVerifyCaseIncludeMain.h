/* iig(DriverKit-440) generated from IIGVerifyCaseIncludeMain.iig */

/* IIGVerifyCaseIncludeMain.iig:1-5 */
#include <DriverKit/IIGVerifyCaseIncludeMiddle.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEINCLUDEMAIN_H
#define _DRIVERKIT_IIGVerifyCASEINCLUDEMAIN_H

/* source class IIGVerifyCaseIncludeMain IIGVerifyCaseIncludeMain.iig:6-18 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseIncludeMain : public OSObject
{
public:
	virtual kern_return_t
	NestedName(const IIGVerifyCaseLeafName name) LOCAL;

	virtual kern_return_t
	NestedInput(const IIGVerifyCaseLeafWords words,
	    uint32_t wordsCount) LOCAL;

	virtual kern_return_t
	DirectInput(const IIGVerifyCaseMiddleScalars values,
	    uint32_t valuesCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseIncludeMain IIGVerifyCaseIncludeMain.iig:6-18 */

#define IIGVerifyCaseIncludeMain_NestedName_ID            0xfbf45f04caf9ca28ULL
#define IIGVerifyCaseIncludeMain_NestedInput_ID            0xb2f1588a10943512ULL
#define IIGVerifyCaseIncludeMain_DirectInput_ID            0xac993ff350b50504ULL

#define IIGVerifyCaseIncludeMain_NestedName_Args \
        const char * name

#define IIGVerifyCaseIncludeMain_NestedInput_Args \
        const unsigned int * words, \
        uint32_t wordsCount

#define IIGVerifyCaseIncludeMain_DirectInput_Args \
        const unsigned long long * values, \
        uint32_t valuesCount

#define IIGVerifyCaseIncludeMain_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseIncludeMain * self, const IORPC rpc);\
\
    kern_return_t\
    NestedName(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    NestedInput(\
        const unsigned int * words,\
        uint32_t wordsCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    DirectInput(\
        const unsigned long long * values,\
        uint32_t valuesCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    NestedName_Impl(IIGVerifyCaseIncludeMain_NestedName_Args);\
\
    kern_return_t\
    NestedInput_Impl(IIGVerifyCaseIncludeMain_NestedInput_Args);\
\
    kern_return_t\
    DirectInput_Impl(IIGVerifyCaseIncludeMain_DirectInput_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*NestedName_Handler)(OSMetaClassBase * target, IIGVerifyCaseIncludeMain_NestedName_Args);\
    static kern_return_t\
    NestedName_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        NestedName_Handler func);\
\
    typedef kern_return_t (*NestedInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseIncludeMain_NestedInput_Args);\
    static kern_return_t\
    NestedInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        NestedInput_Handler func);\
\
    typedef kern_return_t (*DirectInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseIncludeMain_DirectInput_Args);\
    static kern_return_t\
    DirectInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        DirectInput_Handler func);\
\


#define IIGVerifyCaseIncludeMain_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseIncludeMain_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseIncludeMainMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseIncludeMain_Class;

class IIGVerifyCaseIncludeMainMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseIncludeMainInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseIncludeMain_IVars;
struct IIGVerifyCaseIncludeMain_LocalIVars;

class IIGVerifyCaseIncludeMain : public OSObject, public IIGVerifyCaseIncludeMainInterface
{
#if !KERNEL
    friend class IIGVerifyCaseIncludeMainMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseIncludeMain_DECLARE_IVARS
IIGVerifyCaseIncludeMain_DECLARE_IVARS
#else /* IIGVerifyCaseIncludeMain_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseIncludeMain_IVars * ivars;
        IIGVerifyCaseIncludeMain_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseIncludeMain_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseIncludeMainMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseIncludeMain_Methods
    IIGVerifyCaseIncludeMain_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseIncludeMain.iig:20- */

#endif /* _DRIVERKIT_IIGVerifyCASEINCLUDEMAIN_H */
