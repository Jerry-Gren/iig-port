/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseQueues.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseQueues.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCasePureBase.h>
#include <DriverKit/IIGVerifyCaseQueues.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCasePureBase_MustOverride_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCasePureBase_MustOverride_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCasePureBase_MustOverride_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCasePureBase_MustOverride_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePureBase_MustOverride_Msg_ObjRefs (1)

struct IIGVerifyCasePureBase_MustOverride_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePureBase_MustOverride_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePureBase_MustOverride_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePureBase_MustOverride_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePureBase_MustOverride_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePureBase_MustOverride_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePureBase_MustOverride_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePureBase_MustOverride_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePureBase_MustOverride_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePureBase_MustOverride_Invocation;
struct IIGVerifyCasePureBase_HostOnly_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCasePureBase_HostOnly_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCasePureBase_HostOnly_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCasePureBase_HostOnly_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePureBase_HostOnly_Msg_ObjRefs (1)

struct IIGVerifyCasePureBase_HostOnly_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePureBase_HostOnly_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePureBase_HostOnly_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePureBase_HostOnly_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePureBase_HostOnly_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePureBase_HostOnly_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePureBase_HostOnly_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePureBase_HostOnly_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePureBase_HostOnly_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePureBase_HostOnly_Invocation;
struct IIGVerifyCasePureBase_ReplyOnly_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCasePureBase_ReplyOnly_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCasePureBase_ReplyOnly_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCasePureBase_ReplyOnly_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePureBase_ReplyOnly_Msg_ObjRefs (1)

struct IIGVerifyCasePureBase_ReplyOnly_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePureBase_ReplyOnly_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePureBase_ReplyOnly_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePureBase_ReplyOnly_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePureBase_ReplyOnly_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePureBase_ReplyOnly_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePureBase_ReplyOnly_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePureBase_ReplyOnly_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePureBase_ReplyOnly_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePureBase_ReplyOnly_Invocation;
struct IIGVerifyCaseQueues_OnQueueA_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueues_OnQueueA_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueues_OnQueueA_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueues_OnQueueA_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueues_OnQueueA_Msg_ObjRefs (1)

struct IIGVerifyCaseQueues_OnQueueA_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueues_OnQueueA_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueues_OnQueueA_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueues_OnQueueA_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueues_OnQueueA_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueues_OnQueueA_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueues_OnQueueA_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueues_OnQueueA_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueues_OnQueueA_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueues_OnQueueA_Invocation;
struct IIGVerifyCaseQueues_OnQueueB_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueues_OnQueueB_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueues_OnQueueB_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueues_OnQueueB_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueues_OnQueueB_Msg_ObjRefs (1)

struct IIGVerifyCaseQueues_OnQueueB_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueues_OnQueueB_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueues_OnQueueB_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueues_OnQueueB_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueues_OnQueueB_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueues_OnQueueB_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueues_OnQueueB_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueues_OnQueueB_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueues_OnQueueB_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueues_OnQueueB_Invocation;
struct IIGVerifyCaseQueues_OnQueueAAgain_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueues_OnQueueAAgain_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueues_OnQueueAAgain_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueues_OnQueueAAgain_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueues_OnQueueAAgain_Msg_ObjRefs (1)

struct IIGVerifyCaseQueues_OnQueueAAgain_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueues_OnQueueAAgain_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueues_OnQueueAAgain_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueues_OnQueueAAgain_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueues_OnQueueAAgain_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueues_OnQueueAAgain_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueues_OnQueueAAgain_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueues_OnQueueAAgain_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueues_OnQueueAAgain_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueues_OnQueueAAgain_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCasePureBase_QueueNames  ""

#define IIGVerifyCasePureBase_MethodNames  ""

#define IIGVerifyCasePureBaseMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCasePureBase_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCasePureBase_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCasePureBase_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCasePureBaseMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCasePureBase_t
OSClassDescription_IIGVerifyCasePureBase =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCasePureBase_t),
        .name                    = "IIGVerifyCasePureBase",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePureBase_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePureBase_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCasePureBase_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePureBase_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCasePureBase_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePureBase_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCasePureBaseMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePureBase_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCasePureBase_QueueNames,
    .methodNames     = IIGVerifyCasePureBase_MethodNames,
    .metaMethodNames = IIGVerifyCasePureBaseMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCasePureBaseMetaClass;

static kern_return_t
IIGVerifyCasePureBase_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCasePureBase_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCasePureBase.base,
    .metaPointer       = &gIIGVerifyCasePureBaseMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCasePureBase),

    .resv2             = {0},

    .New               = &IIGVerifyCasePureBase_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCasePureBase_Declaration;
const void * const
gIIGVerifyCasePureBase_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCasePureBase_Class;

static kern_return_t
IIGVerifyCasePureBase_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCasePureBaseMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCasePureBaseMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCasePureBase) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCasePureBase::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCasePureBase::_Dispatch(IIGVerifyCasePureBase * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCasePureBase_HostOnly_ID:
        {
            ret = IIGVerifyCasePureBase::HostOnly_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePureBase::HostOnly_Handler, *self, &IIGVerifyCasePureBase::HostOnly_Impl));
            break;
        }
        case IIGVerifyCasePureBase_ReplyOnly_ID:
        {
            ret = IIGVerifyCasePureBase::ReplyOnly_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePureBase::ReplyOnly_Handler, *self, &IIGVerifyCasePureBase::ReplyOnly_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCasePureBase::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCasePureBaseMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCasePureBase::MustOverride(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePureBase_MustOverride_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePureBase_MustOverride_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePureBase_MustOverride_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePureBase_MustOverride_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePureBase_MustOverride_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePureBase_MustOverride_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePureBase_MustOverride_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePureBase_MustOverride_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePureBase::HostOnly(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePureBase_HostOnly_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePureBase_HostOnly_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePureBase_HostOnly_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePureBase_HostOnly_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 1*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePureBase_HostOnly_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePureBase_HostOnly_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePureBase_HostOnly_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePureBase_HostOnly_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePureBase::ReplyOnly(
        IORPC rpc,
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCasePureBase_ReplyOnly_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePureBase_ReplyOnly_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePureBase_ReplyOnly_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCasePureBase::MustOverride_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        MustOverride_Handler func)
{
    IIGVerifyCasePureBase_MustOverride_Invocation rpc = { _rpc };
    IIGVerifyCasePureBase_MustOverride_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePureBase_MustOverride_Msg *         message = rpc.message;
    const IIGVerifyCasePureBase_MustOverride_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePureBase_MustOverride_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePureBase_MustOverride_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePureBase_MustOverride_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePureBase_MustOverride_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePureBase_MustOverride_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCasePureBase::HostOnly_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        HostOnly_Handler func)
{
    IIGVerifyCasePureBase_HostOnly_Invocation rpc = { _rpc };
    IIGVerifyCasePureBase_HostOnly_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePureBase_HostOnly_Msg *         message = rpc.message;
    const IIGVerifyCasePureBase_HostOnly_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePureBase_HostOnly_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePureBase_HostOnly_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePureBase_HostOnly_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePureBase_HostOnly_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePureBase_HostOnly_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCasePureBase::ReplyOnly_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ReplyOnly_Handler func)
{
    IIGVerifyCasePureBase_ReplyOnly_Invocation rpc = { _rpc };
    IIGVerifyCasePureBase_ReplyOnly_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePureBase_ReplyOnly_Msg *         message = rpc.message;
    const IIGVerifyCasePureBase_ReplyOnly_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePureBase_ReplyOnly_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePureBase_ReplyOnly_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePureBase_ReplyOnly_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    (*func)(target,
        MESSAGE_CONTENT(value));


    return (kIOReturnSuccess);
}

#if !KERNEL

#define IIGVerifyCaseQueues_QueueNames  "" \
    "\023IIGVerifyCaseQueueA" \
    "\023IIGVerifyCaseQueueB"

#define IIGVerifyCaseQueues_MethodNames  "" \
    "\010OnQueueA" \
    "\015OnQueueAAgain" \
    "\010OnQueueB"

#define IIGVerifyCaseQueuesMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseQueues_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 3];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseQueues_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseQueues_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseQueuesMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseQueues_t
OSClassDescription_IIGVerifyCaseQueues =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseQueues_t),
        .name                    = "IIGVerifyCaseQueues",
        .superName               = "IIGVerifyCasePureBase",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 3,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueues_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueues_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseQueues_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueues_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseQueues_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueues_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseQueuesMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueues_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseQueues_OnQueueA_ID,
        IIGVerifyCaseQueues_OnQueueAAgain_ID,
        IIGVerifyCaseQueues_OnQueueB_ID,
        0x0000000000000000,
        0x0000000000000000,
        0x0000000000000001,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseQueues_QueueNames,
    .methodNames     = IIGVerifyCaseQueues_MethodNames,
    .metaMethodNames = IIGVerifyCaseQueuesMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseQueuesMetaClass;

static kern_return_t
IIGVerifyCaseQueues_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseQueues_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseQueues.base,
    .metaPointer       = &gIIGVerifyCaseQueuesMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseQueues),

    .resv2             = {0},

    .New               = &IIGVerifyCaseQueues_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseQueues_Declaration;
const void * const
gIIGVerifyCaseQueues_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseQueues_Class;

static kern_return_t
IIGVerifyCaseQueues_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseQueuesMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseQueuesMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseQueues) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseQueues::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseQueues::_Dispatch(IIGVerifyCaseQueues * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCasePureBase_MustOverride_ID:
        {
            ret = IIGVerifyCasePureBase::MustOverride_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePureBase::MustOverride_Handler, *self, &IIGVerifyCaseQueues::MustOverride_Impl));
            break;
        }
        case IIGVerifyCaseQueues_OnQueueA_ID:
        {
            ret = IIGVerifyCaseQueues::OnQueueA_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueues::OnQueueA_Handler, *self, &IIGVerifyCaseQueues::OnQueueA_Impl));
            break;
        }
        case IIGVerifyCaseQueues_OnQueueB_ID:
        {
            ret = IIGVerifyCaseQueues::OnQueueB_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueues::OnQueueB_Handler, *self, &IIGVerifyCaseQueues::OnQueueB_Impl));
            break;
        }
        case IIGVerifyCaseQueues_OnQueueAAgain_ID:
        {
            ret = IIGVerifyCaseQueues::OnQueueAAgain_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueues::OnQueueAAgain_Handler, *self, &IIGVerifyCaseQueues::OnQueueAAgain_Impl));
            break;
        }

        default:
            ret = IIGVerifyCasePureBase::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseQueues::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseQueuesMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseQueues::OnQueueA(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueues_OnQueueA_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueues_OnQueueA_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueues_OnQueueA_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueues_OnQueueA_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueues_OnQueueA_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueues_OnQueueA_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueues_OnQueueA_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueues_OnQueueA_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueues::OnQueueB(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueues_OnQueueB_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueues_OnQueueB_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueues_OnQueueB_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueues_OnQueueB_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueues_OnQueueB_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueues_OnQueueB_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueues_OnQueueB_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueues_OnQueueB_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueues::OnQueueAAgain(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueues_OnQueueAAgain_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueues_OnQueueAAgain_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueues_OnQueueAAgain_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueues_OnQueueAAgain_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueues_OnQueueAAgain_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueues_OnQueueAAgain_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueues_OnQueueAAgain_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueues_OnQueueAAgain_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueues::OnQueueA_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OnQueueA_Handler func)
{
    IIGVerifyCaseQueues_OnQueueA_Invocation rpc = { _rpc };
    IIGVerifyCaseQueues_OnQueueA_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueues_OnQueueA_Msg *         message = rpc.message;
    const IIGVerifyCaseQueues_OnQueueA_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueues_OnQueueA_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueues_OnQueueA_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueues_OnQueueA_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueues_OnQueueA_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueues_OnQueueA_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseQueues::OnQueueB_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OnQueueB_Handler func)
{
    IIGVerifyCaseQueues_OnQueueB_Invocation rpc = { _rpc };
    IIGVerifyCaseQueues_OnQueueB_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueues_OnQueueB_Msg *         message = rpc.message;
    const IIGVerifyCaseQueues_OnQueueB_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueues_OnQueueB_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueues_OnQueueB_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueues_OnQueueB_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueues_OnQueueB_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueues_OnQueueB_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseQueues::OnQueueAAgain_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OnQueueAAgain_Handler func)
{
    IIGVerifyCaseQueues_OnQueueAAgain_Invocation rpc = { _rpc };
    IIGVerifyCaseQueues_OnQueueAAgain_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueues_OnQueueAAgain_Msg *         message = rpc.message;
    const IIGVerifyCaseQueues_OnQueueAAgain_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueues_OnQueueAAgain_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueues_OnQueueAAgain_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueues_OnQueueAAgain_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueues_OnQueueAAgain_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueues_OnQueueAAgain_Rpl_ObjRefs;

    return (ret);
}



