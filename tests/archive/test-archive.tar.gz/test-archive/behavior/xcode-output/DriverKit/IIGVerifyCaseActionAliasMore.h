/* iig(DriverKit-440) generated from IIGVerifyCaseActionAliasMore.iig */

/* IIGVerifyCaseActionAliasMore.iig:1-8 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEACTIONALIASMORE_H
#define _DRIVERKIT_IIGVerifyCASEACTIONALIASMORE_H

typedef OSAction * IIGVerifyAliasAction;
typedef const OSAction * IIGVerifyAliasConstAction;

/* source class IIGVerifyCaseActionAliasMore IIGVerifyCaseActionAliasMore.iig:9-22 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseActionAliasMore : public OSObject
{
public:
	virtual void
	CompletionAlias(IIGVerifyAliasAction action TARGET,
	    uint64_t token) REPLY LOCAL;

	virtual kern_return_t
	SubmitAlias(IIGVerifyAliasAction completion TYPE(IIGVerifyCaseActionAliasMore::CompletionAlias),
	    uint64_t token) LOCAL;

	virtual kern_return_t
	SubmitConstAlias(IIGVerifyAliasConstAction completion TYPE(IIGVerifyCaseActionAliasMore::CompletionAlias),
	    uint64_t token) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseActionAliasMore IIGVerifyCaseActionAliasMore.iig:9-22 */

#define IIGVerifyCaseActionAliasMore_CompletionAlias_ID            0xd47816a314179fe2ULL
#define IIGVerifyCaseActionAliasMore_SubmitAlias_ID            0xfe8981b905672bfdULL
#define IIGVerifyCaseActionAliasMore_SubmitConstAlias_ID            0xd9d7f2ac21e23cceULL

#define IIGVerifyCaseActionAliasMore_CompletionAlias_Args \
        IIGVerifyAliasAction action, \
        uint64_t token

#define IIGVerifyCaseActionAliasMore_SubmitAlias_Args \
        IIGVerifyAliasAction completion, \
        uint64_t token

#define IIGVerifyCaseActionAliasMore_SubmitConstAlias_Args \
        IIGVerifyAliasConstAction completion, \
        uint64_t token

#define IIGVerifyCaseActionAliasMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseActionAliasMore * self, const IORPC rpc);\
\
    kern_return_t\
    CompletionAlias(\
        IORPC rpc,\
        IIGVerifyAliasAction action,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitAlias(\
        IIGVerifyAliasAction completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitConstAlias(\
        IIGVerifyAliasConstAction completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    void\
    CompletionAlias_Impl(IIGVerifyCaseActionAliasMore_CompletionAlias_Args);\
\
    kern_return_t\
    SubmitAlias_Impl(IIGVerifyCaseActionAliasMore_SubmitAlias_Args);\
\
    kern_return_t\
    SubmitConstAlias_Impl(IIGVerifyCaseActionAliasMore_SubmitConstAlias_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef void (*CompletionAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionAliasMore_CompletionAlias_Args);\
    static kern_return_t\
    CompletionAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionAlias_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    CompletionAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionAlias_Handler func);\
\
    typedef kern_return_t (*SubmitAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionAliasMore_SubmitAlias_Args);\
    static kern_return_t\
    SubmitAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitAlias_Handler func);\
\
    typedef kern_return_t (*SubmitConstAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionAliasMore_SubmitConstAlias_Args);\
    static kern_return_t\
    SubmitConstAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitConstAlias_Handler func);\
\


#define IIGVerifyCaseActionAliasMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseActionAliasMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseActionAliasMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseActionAliasMore_Class;

class IIGVerifyCaseActionAliasMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseActionAliasMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseActionAliasMore_IVars;
struct IIGVerifyCaseActionAliasMore_LocalIVars;

class IIGVerifyCaseActionAliasMore : public OSObject, public IIGVerifyCaseActionAliasMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseActionAliasMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseActionAliasMore_DECLARE_IVARS
IIGVerifyCaseActionAliasMore_DECLARE_IVARS
#else /* IIGVerifyCaseActionAliasMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseActionAliasMore_IVars * ivars;
        IIGVerifyCaseActionAliasMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseActionAliasMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseActionAliasMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseActionAliasMore_Methods
    IIGVerifyCaseActionAliasMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseActionAliasMore.iig:24- */

#endif /* _DRIVERKIT_IIGVerifyCASEACTIONALIASMORE_H */
