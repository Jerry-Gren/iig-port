/* iig(DriverKit-440) generated from IIGVerifyCaseBoundExpressions.iig */

/* IIGVerifyCaseBoundExpressions.iig:1-15 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEBOUNDEXPRESSIONS_H
#define _DRIVERKIT_IIGVerifyCASEBOUNDEXPRESSIONS_H

#define IIGVerifyCaseBoundExprBase 4
#define IIGVerifyCaseBoundExprAlias IIGVerifyCaseBoundExprBase

enum {
	kIIGVerifyCaseBoundExprBase = 3,
	kIIGVerifyCaseBoundExprAlias = kIIGVerifyCaseBoundExprBase,
};

typedef uint32_t IIGVerifyCaseBoundExprWords[IIGVerifyCaseBoundExprAlias];

/* source class IIGVerifyCaseBoundExpressions IIGVerifyCaseBoundExpressions.iig:16-29 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseBoundExpressions : public OSObject
{
public:
	virtual kern_return_t
	MacroAliasInput(const uint8_t bytes[IIGVerifyCaseBoundExprAlias],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	EnumAliasInput(const uint8_t bytes[kIIGVerifyCaseBoundExprAlias],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	TypedefMacroAliasOutput(uint32_t wordsCount,
	    IIGVerifyCaseBoundExprWords words) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseBoundExpressions IIGVerifyCaseBoundExpressions.iig:16-29 */

#define IIGVerifyCaseBoundExpressions_MacroAliasInput_ID            0x87c72226462006e3ULL
#define IIGVerifyCaseBoundExpressions_EnumAliasInput_ID            0x8052615f2d5519ccULL
#define IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_ID            0x8eb88ac86005d6c4ULL

#define IIGVerifyCaseBoundExpressions_MacroAliasInput_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseBoundExpressions_EnumAliasInput_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseBoundExpressions_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseBoundExpressions * self, const IORPC rpc);\
\
    kern_return_t\
    MacroAliasInput(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    EnumAliasInput(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TypedefMacroAliasOutput(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    MacroAliasInput_Impl(IIGVerifyCaseBoundExpressions_MacroAliasInput_Args);\
\
    kern_return_t\
    EnumAliasInput_Impl(IIGVerifyCaseBoundExpressions_EnumAliasInput_Args);\
\
    kern_return_t\
    TypedefMacroAliasOutput_Impl(IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*MacroAliasInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseBoundExpressions_MacroAliasInput_Args);\
    static kern_return_t\
    MacroAliasInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        MacroAliasInput_Handler func);\
\
    typedef kern_return_t (*EnumAliasInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseBoundExpressions_EnumAliasInput_Args);\
    static kern_return_t\
    EnumAliasInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        EnumAliasInput_Handler func);\
\
    typedef kern_return_t (*TypedefMacroAliasOutput_Handler)(OSMetaClassBase * target, IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Args);\
    static kern_return_t\
    TypedefMacroAliasOutput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TypedefMacroAliasOutput_Handler func);\
\


#define IIGVerifyCaseBoundExpressions_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseBoundExpressions_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseBoundExpressionsMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseBoundExpressions_Class;

class IIGVerifyCaseBoundExpressionsMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseBoundExpressionsInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseBoundExpressions_IVars;
struct IIGVerifyCaseBoundExpressions_LocalIVars;

class IIGVerifyCaseBoundExpressions : public OSObject, public IIGVerifyCaseBoundExpressionsInterface
{
#if !KERNEL
    friend class IIGVerifyCaseBoundExpressionsMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseBoundExpressions_DECLARE_IVARS
IIGVerifyCaseBoundExpressions_DECLARE_IVARS
#else /* IIGVerifyCaseBoundExpressions_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseBoundExpressions_IVars * ivars;
        IIGVerifyCaseBoundExpressions_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseBoundExpressions_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseBoundExpressionsMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseBoundExpressions_Methods
    IIGVerifyCaseBoundExpressions_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseBoundExpressions.iig:31- */

#endif /* _DRIVERKIT_IIGVerifyCASEBOUNDEXPRESSIONS_H */
