/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseQueueOrder.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseQueueOrder.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseQueueOrder.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_ObjRefs (1)

struct IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueueOrder_QueueOrderM0_Invocation;
struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_ObjRefs (1)

struct IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueueOrder_QueueOrderM1_Invocation;
struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_ObjRefs (1)

struct IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueueOrder_QueueOrderM2_Invocation;
struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_ObjRefs (1)

struct IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseQueueOrder_QueueOrderM3_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseQueueOrder_QueueNames  "" \
    "\024IIGVerifyQueueOrderA" \
    "\024IIGVerifyQueueOrderB" \
    "\024IIGVerifyQueueOrderC"

#define IIGVerifyCaseQueueOrder_MethodNames  "" \
    "\014QueueOrderM0" \
    "\014QueueOrderM3" \
    "\014QueueOrderM1" \
    "\014QueueOrderM2"

#define IIGVerifyCaseQueueOrderMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseQueueOrder_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 4];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseQueueOrder_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseQueueOrder_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseQueueOrderMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseQueueOrder_t
OSClassDescription_IIGVerifyCaseQueueOrder =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseQueueOrder_t),
        .name                    = "IIGVerifyCaseQueueOrder",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 4,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueueOrder_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueueOrder_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseQueueOrder_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueueOrder_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseQueueOrder_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueueOrder_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseQueueOrderMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseQueueOrder_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseQueueOrder_QueueOrderM0_ID,
        IIGVerifyCaseQueueOrder_QueueOrderM3_ID,
        IIGVerifyCaseQueueOrder_QueueOrderM1_ID,
        IIGVerifyCaseQueueOrder_QueueOrderM2_ID,
        0x0000000000000000,
        0x0000000000000000,
        0x0000000000000001,
        0x0000000000000002,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseQueueOrder_QueueNames,
    .methodNames     = IIGVerifyCaseQueueOrder_MethodNames,
    .metaMethodNames = IIGVerifyCaseQueueOrderMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseQueueOrderMetaClass;

static kern_return_t
IIGVerifyCaseQueueOrder_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseQueueOrder_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseQueueOrder.base,
    .metaPointer       = &gIIGVerifyCaseQueueOrderMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseQueueOrder),

    .resv2             = {0},

    .New               = &IIGVerifyCaseQueueOrder_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseQueueOrder_Declaration;
const void * const
gIIGVerifyCaseQueueOrder_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseQueueOrder_Class;

static kern_return_t
IIGVerifyCaseQueueOrder_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseQueueOrderMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseQueueOrderMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseQueueOrder) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseQueueOrder::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseQueueOrder::_Dispatch(IIGVerifyCaseQueueOrder * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseQueueOrder_QueueOrderM0_ID:
        {
            ret = IIGVerifyCaseQueueOrder::QueueOrderM0_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueueOrder::QueueOrderM0_Handler, *self, &IIGVerifyCaseQueueOrder::QueueOrderM0_Impl));
            break;
        }
        case IIGVerifyCaseQueueOrder_QueueOrderM1_ID:
        {
            ret = IIGVerifyCaseQueueOrder::QueueOrderM1_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueueOrder::QueueOrderM1_Handler, *self, &IIGVerifyCaseQueueOrder::QueueOrderM1_Impl));
            break;
        }
        case IIGVerifyCaseQueueOrder_QueueOrderM2_ID:
        {
            ret = IIGVerifyCaseQueueOrder::QueueOrderM2_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueueOrder::QueueOrderM2_Handler, *self, &IIGVerifyCaseQueueOrder::QueueOrderM2_Impl));
            break;
        }
        case IIGVerifyCaseQueueOrder_QueueOrderM3_ID:
        {
            ret = IIGVerifyCaseQueueOrder::QueueOrderM3_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseQueueOrder::QueueOrderM3_Handler, *self, &IIGVerifyCaseQueueOrder::QueueOrderM3_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseQueueOrder::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseQueueOrderMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM0(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM0_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueueOrder_QueueOrderM0_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM1(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM1_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueueOrder_QueueOrderM1_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM2(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM2_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueueOrder_QueueOrderM2_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM3(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM3_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseQueueOrder_QueueOrderM3_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM0_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        QueueOrderM0_Handler func)
{
    IIGVerifyCaseQueueOrder_QueueOrderM0_Invocation rpc = { _rpc };
    IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueueOrder_QueueOrderM0_Msg *         message = rpc.message;
    const IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueueOrder_QueueOrderM0_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM0_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM0_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM1_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        QueueOrderM1_Handler func)
{
    IIGVerifyCaseQueueOrder_QueueOrderM1_Invocation rpc = { _rpc };
    IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueueOrder_QueueOrderM1_Msg *         message = rpc.message;
    const IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueueOrder_QueueOrderM1_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM1_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM1_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM2_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        QueueOrderM2_Handler func)
{
    IIGVerifyCaseQueueOrder_QueueOrderM2_Invocation rpc = { _rpc };
    IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueueOrder_QueueOrderM2_Msg *         message = rpc.message;
    const IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueueOrder_QueueOrderM2_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM2_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM2_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseQueueOrder::QueueOrderM3_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        QueueOrderM3_Handler func)
{
    IIGVerifyCaseQueueOrder_QueueOrderM3_Invocation rpc = { _rpc };
    IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseQueueOrder_QueueOrderM3_Msg *         message = rpc.message;
    const IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseQueueOrder_QueueOrderM3_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseQueueOrder_QueueOrderM3_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseQueueOrder_QueueOrderM3_Rpl_ObjRefs;

    return (ret);
}



