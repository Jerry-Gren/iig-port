/* iig(DriverKit-440) generated from IIGVerifyCaseRemoteAndInvokeReply.iig */

/* IIGVerifyCaseRemoteAndInvokeReply.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEREMOTEANDINVOKEREPLY_H
#define _DRIVERKIT_IIGVerifyCASEREMOTEANDINVOKEREPLY_H

/* source class IIGVerifyCaseRemoteAndInvokeReply IIGVerifyCaseRemoteAndInvokeReply.iig:6-13 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseRemoteAndInvokeReply : public OSObject
{
public:
	virtual kern_return_t
	RemoteOnly(uint64_t value) REMOTE;

	virtual kern_return_t
	InvokeReply(uint64_t value) INVOKEREPLY;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseRemoteAndInvokeReply IIGVerifyCaseRemoteAndInvokeReply.iig:6-13 */

#define IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_ID            0xad2a99ed7e10eed9ULL
#define IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_ID            0x9237037dc4c82f35ULL

#define IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Args \
        uint64_t value

#define IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Args \
        const IORPC rpc, \
        uint64_t value

#define IIGVerifyCaseRemoteAndInvokeReply_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseRemoteAndInvokeReply * self, const IORPC rpc);\
\
    kern_return_t\
    RemoteOnly(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InvokeReply(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*RemoteOnly_Handler)(OSMetaClassBase * target, IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Args);\
    static kern_return_t\
    RemoteOnly_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        RemoteOnly_Handler func);\
\
    typedef kern_return_t (*InvokeReply_Handler)(OSMetaClassBase * target, IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Args);\
    static kern_return_t\
    InvokeReply_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InvokeReply_Handler func);\
\


#define IIGVerifyCaseRemoteAndInvokeReply_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    RemoteOnly_Impl(IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Args);\
\
    kern_return_t\
    InvokeReply_Impl(IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Args);\
\


#define IIGVerifyCaseRemoteAndInvokeReply_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseRemoteAndInvokeReplyMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseRemoteAndInvokeReply_Class;

class IIGVerifyCaseRemoteAndInvokeReplyMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseRemoteAndInvokeReplyInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseRemoteAndInvokeReply_IVars;
struct IIGVerifyCaseRemoteAndInvokeReply_LocalIVars;

class IIGVerifyCaseRemoteAndInvokeReply : public OSObject, public IIGVerifyCaseRemoteAndInvokeReplyInterface
{
#if !KERNEL
    friend class IIGVerifyCaseRemoteAndInvokeReplyMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseRemoteAndInvokeReply_DECLARE_IVARS
IIGVerifyCaseRemoteAndInvokeReply_DECLARE_IVARS
#else /* IIGVerifyCaseRemoteAndInvokeReply_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseRemoteAndInvokeReply_IVars * ivars;
        IIGVerifyCaseRemoteAndInvokeReply_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseRemoteAndInvokeReply_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseRemoteAndInvokeReplyMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseRemoteAndInvokeReply_Methods
    IIGVerifyCaseRemoteAndInvokeReply_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseRemoteAndInvokeReply.iig:15- */

#endif /* _DRIVERKIT_IIGVerifyCASEREMOTEANDINVOKEREPLY_H */
