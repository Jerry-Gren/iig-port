/* iig(DriverKit-440) generated from IIGVerifyCaseCountPairingMore.iig */

/* IIGVerifyCaseCountPairingMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASECOUNTPAIRINGMORE_H
#define _DRIVERKIT_IIGVerifyCASECOUNTPAIRINGMORE_H

/* source class IIGVerifyCaseCountPairingMore IIGVerifyCaseCountPairingMore.iig:6-24 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseCountPairingMore : public OSObject
{
public:
	virtual kern_return_t
	InputBytesCountAfter(const uint8_t bytes[16],
	    uint32_t bytesCount,
	    uint32_t otherCount) LOCAL;

	virtual kern_return_t
	InputBytesCountBefore(uint32_t bytesCount,
	    const uint8_t bytes[16]) LOCAL;

	virtual kern_return_t
	OutputWordsCountBefore(uint32_t wordsCount,
	    uint32_t words[8]) LOCAL;

	virtual kern_return_t
	OutputWordsCountAfter(uint32_t words[8],
	    uint32_t wordsCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseCountPairingMore IIGVerifyCaseCountPairingMore.iig:6-24 */

#define IIGVerifyCaseCountPairingMore_InputBytesCountAfter_ID            0x816f57ca9d7e4d47ULL
#define IIGVerifyCaseCountPairingMore_InputBytesCountBefore_ID            0xf7cb35d157bde940ULL
#define IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_ID            0xa242590fcc1ee4c1ULL
#define IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_ID            0x92a4ce2fb70016c4ULL

#define IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount, \
        uint32_t otherCount

#define IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Args \
        uint32_t bytesCount, \
        const unsigned char * bytes

#define IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Args \
        unsigned int * words, \
        uint32_t wordsCount

#define IIGVerifyCaseCountPairingMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseCountPairingMore * self, const IORPC rpc);\
\
    kern_return_t\
    InputBytesCountAfter(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        uint32_t otherCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputBytesCountBefore(\
        uint32_t bytesCount,\
        const unsigned char * bytes,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputWordsCountBefore(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputWordsCountAfter(\
        unsigned int * words,\
        uint32_t wordsCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InputBytesCountAfter_Impl(IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Args);\
\
    kern_return_t\
    InputBytesCountBefore_Impl(IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Args);\
\
    kern_return_t\
    OutputWordsCountBefore_Impl(IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Args);\
\
    kern_return_t\
    OutputWordsCountAfter_Impl(IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InputBytesCountAfter_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Args);\
    static kern_return_t\
    InputBytesCountAfter_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputBytesCountAfter_Handler func);\
\
    typedef kern_return_t (*InputBytesCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Args);\
    static kern_return_t\
    InputBytesCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputBytesCountBefore_Handler func);\
\
    typedef kern_return_t (*OutputWordsCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Args);\
    static kern_return_t\
    OutputWordsCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputWordsCountBefore_Handler func);\
\
    typedef kern_return_t (*OutputWordsCountAfter_Handler)(OSMetaClassBase * target, IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Args);\
    static kern_return_t\
    OutputWordsCountAfter_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputWordsCountAfter_Handler func);\
\


#define IIGVerifyCaseCountPairingMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseCountPairingMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseCountPairingMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseCountPairingMore_Class;

class IIGVerifyCaseCountPairingMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseCountPairingMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseCountPairingMore_IVars;
struct IIGVerifyCaseCountPairingMore_LocalIVars;

class IIGVerifyCaseCountPairingMore : public OSObject, public IIGVerifyCaseCountPairingMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseCountPairingMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseCountPairingMore_DECLARE_IVARS
IIGVerifyCaseCountPairingMore_DECLARE_IVARS
#else /* IIGVerifyCaseCountPairingMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseCountPairingMore_IVars * ivars;
        IIGVerifyCaseCountPairingMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseCountPairingMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseCountPairingMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseCountPairingMore_Methods
    IIGVerifyCaseCountPairingMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseCountPairingMore.iig:26- */

#endif /* _DRIVERKIT_IIGVerifyCASECOUNTPAIRINGMORE_H */
