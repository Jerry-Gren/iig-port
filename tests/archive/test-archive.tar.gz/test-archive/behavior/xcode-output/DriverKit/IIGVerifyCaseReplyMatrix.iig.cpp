/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseReplyMatrix.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseReplyMatrix.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseReplyMatrix.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseReplyMatrix_NormalReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_NormalReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseReplyMatrix_NormalReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseReplyMatrix_NormalReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_NormalReply_Msg_ObjRefs (1)

struct IIGVerifyCaseReplyMatrix_NormalReply_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_NormalReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseReplyMatrix_NormalReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseReplyMatrix_NormalReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_NormalReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_NormalReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseReplyMatrix_NormalReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseReplyMatrix_NormalReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_NormalReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseReplyMatrix_NormalReply_Invocation;
struct IIGVerifyCaseReplyMatrix_HostReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_HostReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseReplyMatrix_HostReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseReplyMatrix_HostReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_HostReply_Msg_ObjRefs (1)

struct IIGVerifyCaseReplyMatrix_HostReply_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_HostReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseReplyMatrix_HostReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseReplyMatrix_HostReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_HostReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_HostReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseReplyMatrix_HostReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseReplyMatrix_HostReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_HostReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseReplyMatrix_HostReply_Invocation;
struct IIGVerifyCaseReplyMatrix_StatusReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_StatusReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseReplyMatrix_StatusReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseReplyMatrix_StatusReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_StatusReply_Msg_ObjRefs (1)

struct IIGVerifyCaseReplyMatrix_StatusReply_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_StatusReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseReplyMatrix_StatusReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseReplyMatrix_StatusReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_StatusReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_StatusReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseReplyMatrix_StatusReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseReplyMatrix_StatusReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_StatusReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseReplyMatrix_StatusReply_Invocation;
struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_ObjRefs (1)

struct IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseReplyMatrix_HostStatusReply_Invocation;
struct IIGVerifyCaseReplyMatrix_Queued_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_Queued_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseReplyMatrix_Queued_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseReplyMatrix_Queued_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_Queued_Msg_ObjRefs (1)

struct IIGVerifyCaseReplyMatrix_Queued_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_Queued_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseReplyMatrix_Queued_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseReplyMatrix_Queued_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_Queued_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_Queued_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseReplyMatrix_Queued_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseReplyMatrix_Queued_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_Queued_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseReplyMatrix_Queued_Invocation;
struct IIGVerifyCaseReplyMatrix_TargetReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_TargetReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseReplyMatrix_TargetReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseReplyMatrix_TargetReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_TargetReply_Msg_ObjRefs (2)

struct IIGVerifyCaseReplyMatrix_TargetReply_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseReplyMatrix_TargetReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseReplyMatrix_TargetReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseReplyMatrix_TargetReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseReplyMatrix_TargetReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_TargetReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseReplyMatrix_TargetReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseReplyMatrix_TargetReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseReplyMatrix_TargetReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseReplyMatrix_TargetReply_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseReplyMatrix_QueueNames  "" \
    "\027IIGVerifyCaseReplyQueue"

#define IIGVerifyCaseReplyMatrix_MethodNames  "" \
    "\006Queued"

#define IIGVerifyCaseReplyMatrixMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseReplyMatrix_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 1];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseReplyMatrix_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseReplyMatrix_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseReplyMatrixMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseReplyMatrix_t
OSClassDescription_IIGVerifyCaseReplyMatrix =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseReplyMatrix_t),
        .name                    = "IIGVerifyCaseReplyMatrix",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 1,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseReplyMatrix_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseReplyMatrix_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseReplyMatrix_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseReplyMatrix_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseReplyMatrix_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseReplyMatrix_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseReplyMatrixMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseReplyMatrix_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
        IIGVerifyCaseReplyMatrix_Queued_ID,
        0x0000000000000000,
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseReplyMatrix_QueueNames,
    .methodNames     = IIGVerifyCaseReplyMatrix_MethodNames,
    .metaMethodNames = IIGVerifyCaseReplyMatrixMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseReplyMatrixMetaClass;

static kern_return_t
IIGVerifyCaseReplyMatrix_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseReplyMatrix_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseReplyMatrix.base,
    .metaPointer       = &gIIGVerifyCaseReplyMatrixMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseReplyMatrix),

    .resv2             = {0},

    .New               = &IIGVerifyCaseReplyMatrix_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseReplyMatrix_Declaration;
const void * const
gIIGVerifyCaseReplyMatrix_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseReplyMatrix_Class;

static kern_return_t
IIGVerifyCaseReplyMatrix_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseReplyMatrixMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseReplyMatrixMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseReplyMatrix) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseReplyMatrix::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseReplyMatrix::_Dispatch(IIGVerifyCaseReplyMatrix * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseReplyMatrix_NormalReply_ID:
        {
            ret = IIGVerifyCaseReplyMatrix::NormalReply_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseReplyMatrix::NormalReply_Handler, *self, &IIGVerifyCaseReplyMatrix::NormalReply_Impl));
            break;
        }
        case IIGVerifyCaseReplyMatrix_HostReply_ID:
        {
            ret = IIGVerifyCaseReplyMatrix::HostReply_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseReplyMatrix::HostReply_Handler, *self, &IIGVerifyCaseReplyMatrix::HostReply_Impl));
            break;
        }
        case IIGVerifyCaseReplyMatrix_StatusReply_ID:
        {
            ret = IIGVerifyCaseReplyMatrix::StatusReply_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseReplyMatrix::StatusReply_Handler, *self, &IIGVerifyCaseReplyMatrix::StatusReply_Impl));
            break;
        }
        case IIGVerifyCaseReplyMatrix_HostStatusReply_ID:
        {
            ret = IIGVerifyCaseReplyMatrix::HostStatusReply_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseReplyMatrix::HostStatusReply_Handler, *self, &IIGVerifyCaseReplyMatrix::HostStatusReply_Impl));
            break;
        }
        case IIGVerifyCaseReplyMatrix_Queued_ID:
        {
            ret = IIGVerifyCaseReplyMatrix::Queued_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseReplyMatrix::Queued_Handler, *self, &IIGVerifyCaseReplyMatrix::Queued_Impl));
            break;
        }
        case IIGVerifyCaseReplyMatrix_TargetReply_ID:
        {
            ret = IIGVerifyCaseReplyMatrix::TargetReply_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseReplyMatrix::TargetReply_Handler, *self, &IIGVerifyCaseReplyMatrix::TargetReply_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseReplyMatrix::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseReplyMatrixMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::NormalReply(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseReplyMatrix_NormalReply_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseReplyMatrix_NormalReply_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseReplyMatrix_NormalReply_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseReplyMatrix_NormalReply_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_NormalReply_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_NormalReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseReplyMatrix_NormalReply_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseReplyMatrix_NormalReply_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::HostReply(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseReplyMatrix_HostReply_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseReplyMatrix_HostReply_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseReplyMatrix_HostReply_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseReplyMatrix_HostReply_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 1*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_HostReply_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_HostReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseReplyMatrix_HostReply_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseReplyMatrix_HostReply_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::StatusReply(
        IORPC rpc,
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseReplyMatrix_StatusReply_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_StatusReply_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_StatusReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::HostStatusReply(
        IORPC rpc,
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 1*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_HostStatusReply_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::Queued(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseReplyMatrix_Queued_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseReplyMatrix_Queued_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseReplyMatrix_Queued_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseReplyMatrix_Queued_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_Queued_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_Queued_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseReplyMatrix_Queued_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseReplyMatrix_Queued_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::TargetReply(
        IORPC rpc,
        OSAction * action,
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseReplyMatrix_TargetReply_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_TargetReply_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_TargetReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.value = value;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::NormalReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        NormalReply_Handler func)
{
    IIGVerifyCaseReplyMatrix_NormalReply_Invocation rpc = { _rpc };
    IIGVerifyCaseReplyMatrix_NormalReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseReplyMatrix_NormalReply_Msg *         message = rpc.message;
    const IIGVerifyCaseReplyMatrix_NormalReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseReplyMatrix_NormalReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseReplyMatrix_NormalReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseReplyMatrix_NormalReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_NormalReply_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_NormalReply_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::HostReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        HostReply_Handler func)
{
    IIGVerifyCaseReplyMatrix_HostReply_Invocation rpc = { _rpc };
    IIGVerifyCaseReplyMatrix_HostReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseReplyMatrix_HostReply_Msg *         message = rpc.message;
    const IIGVerifyCaseReplyMatrix_HostReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseReplyMatrix_HostReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseReplyMatrix_HostReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseReplyMatrix_HostReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_HostReply_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_HostReply_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::StatusReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        StatusReply_Handler func)
{
    IIGVerifyCaseReplyMatrix_StatusReply_Invocation rpc = { _rpc };
    IIGVerifyCaseReplyMatrix_StatusReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseReplyMatrix_StatusReply_Msg *         message = rpc.message;
    const IIGVerifyCaseReplyMatrix_StatusReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseReplyMatrix_StatusReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseReplyMatrix_StatusReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseReplyMatrix_StatusReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    (*func)(target,
        MESSAGE_CONTENT(value));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseReplyMatrix::HostStatusReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        HostStatusReply_Handler func)
{
    IIGVerifyCaseReplyMatrix_HostStatusReply_Invocation rpc = { _rpc };
    IIGVerifyCaseReplyMatrix_HostStatusReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseReplyMatrix_HostStatusReply_Msg *         message = rpc.message;
    const IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseReplyMatrix_HostStatusReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    (*func)(target,
        MESSAGE_CONTENT(value));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseReplyMatrix::Queued_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Queued_Handler func)
{
    IIGVerifyCaseReplyMatrix_Queued_Invocation rpc = { _rpc };
    IIGVerifyCaseReplyMatrix_Queued_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseReplyMatrix_Queued_Msg *         message = rpc.message;
    const IIGVerifyCaseReplyMatrix_Queued_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseReplyMatrix_Queued_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseReplyMatrix_Queued_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseReplyMatrix_Queued_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseReplyMatrix_Queued_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseReplyMatrix_Queued_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseReplyMatrix::TargetReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TargetReply_Handler func)
{
    return IIGVerifyCaseReplyMatrix::TargetReply_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseReplyMatrix::TargetReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TargetReply_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseReplyMatrix_TargetReply_Invocation rpc = { _rpc };
    IIGVerifyCaseReplyMatrix_TargetReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseReplyMatrix_TargetReply_Msg *         message = rpc.message;
    const IIGVerifyCaseReplyMatrix_TargetReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseReplyMatrix_TargetReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseReplyMatrix_TargetReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseReplyMatrix_TargetReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(value));


    return (kIOReturnSuccess);
}



