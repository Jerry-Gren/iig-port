/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseStructConstSpellingsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseStructConstSpellingsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseStructConstSpellingsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Invocation;
struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Invocation;
struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Invocation;
struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Invocation;
struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Invocation;
struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Invocation;
struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyConstStructMore  value;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseStructConstSpellingsMore_QueueNames  ""

#define IIGVerifyCaseStructConstSpellingsMore_MethodNames  ""

#define IIGVerifyCaseStructConstSpellingsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseStructConstSpellingsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseStructConstSpellingsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseStructConstSpellingsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t
OSClassDescription_IIGVerifyCaseStructConstSpellingsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t),
        .name                    = "IIGVerifyCaseStructConstSpellingsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseStructConstSpellingsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseStructConstSpellingsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseStructConstSpellingsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructConstSpellingsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseStructConstSpellingsMore_QueueNames,
    .methodNames     = IIGVerifyCaseStructConstSpellingsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseStructConstSpellingsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseStructConstSpellingsMoreMetaClass;

static kern_return_t
IIGVerifyCaseStructConstSpellingsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseStructConstSpellingsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseStructConstSpellingsMore.base,
    .metaPointer       = &gIIGVerifyCaseStructConstSpellingsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseStructConstSpellingsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseStructConstSpellingsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseStructConstSpellingsMore_Declaration;
const void * const
gIIGVerifyCaseStructConstSpellingsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseStructConstSpellingsMore_Class;

static kern_return_t
IIGVerifyCaseStructConstSpellingsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseStructConstSpellingsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseStructConstSpellingsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::_Dispatch(IIGVerifyCaseStructConstSpellingsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseStructConstSpellingsMore_LeadingConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::LeadingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::LeadingConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::LeadingConst_Impl));
            break;
        }
        case IIGVerifyCaseStructConstSpellingsMore_TrailingConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::TrailingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::TrailingConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::TrailingConst_Impl));
            break;
        }
        case IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::AliasLeadingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::AliasLeadingConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::AliasLeadingConst_Impl));
            break;
        }
        case IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::AliasTrailingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::AliasTrailingConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::AliasTrailingConst_Impl));
            break;
        }
        case IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::TopLevelConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::TopLevelConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::TopLevelConst_Impl));
            break;
        }
        case IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::LeadingTopLevelConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::LeadingTopLevelConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::LeadingTopLevelConst_Impl));
            break;
        }
        case IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_ID:
        {
            ret = IIGVerifyCaseStructConstSpellingsMore::HiddenPointeeConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructConstSpellingsMore::HiddenPointeeConst_Handler, *self, &IIGVerifyCaseStructConstSpellingsMore::HiddenPointeeConst_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseStructConstSpellingsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseStructConstSpellingsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::LeadingConst(
        const IIGVerifyConstStructMore * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_LeadingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_LeadingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::TrailingConst(
        const IIGVerifyConstStructMore * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_TrailingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_TrailingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::AliasLeadingConst(
        const IIGVerifyAliasStructMore * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::AliasTrailingConst(
        const IIGVerifyAliasStructMore * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::TopLevelConst(
        const IIGVerifyAliasStructPointerMore value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (value) *value = rpl->content.value;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::LeadingTopLevelConst(
        const IIGVerifyAliasStructPointerMore value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (value) *value = rpl->content.value;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::HiddenPointeeConst(
        IIGVerifyAliasConstStructPointerMore value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::LeadingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        LeadingConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_LeadingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::TrailingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TrailingConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_TrailingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::AliasLeadingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasLeadingConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::AliasTrailingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasTrailingConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::TopLevelConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TopLevelConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.value);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::LeadingTopLevelConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        LeadingTopLevelConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.value);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructConstSpellingsMore::HiddenPointeeConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        HiddenPointeeConst_Handler func)
{
    IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Rpl_ObjRefs;

    return (ret);
}



