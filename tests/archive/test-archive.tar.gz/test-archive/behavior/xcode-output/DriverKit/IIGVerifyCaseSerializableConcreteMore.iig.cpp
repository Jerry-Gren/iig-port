/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseSerializableConcreteMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseSerializableConcreteMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseSerializablePayload.h>
#include <DriverKit/IIGVerifyCaseConcretePayload.h>
#include <DriverKit/IIGVerifyCaseSerializableConcreteMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyCaseSerializablePayload * payload;
#if !defined(__LP64__)
    uint32_t __payloadPad;
#endif /* !defined(__LP64__) */
};
#pragma pack(4)
struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  payload__descriptor;
};
struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  payload__descriptor;
    IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_ObjRefs (2)

struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableConcreteMore_SendPayload_Invocation;
struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_ObjRefs (1)

struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyCaseSerializablePayload * payload;
#if !defined(__LP64__)
    uint32_t __payloadPad;
#endif /* !defined(__LP64__) */
};
#pragma pack(4)
struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_ool_descriptor_t  payload__descriptor;
};
struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_ool_descriptor_t  payload__descriptor;
    IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableConcreteMore_CopyPayload_Invocation;
struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyCaseConcretePayload * payload;
#if !defined(__LP64__)
    uint32_t __payloadPad;
#endif /* !defined(__LP64__) */
};
#pragma pack(4)
struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  payload__descriptor;
};
struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  payload__descriptor;
    IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_ObjRefs (2)

struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseSerializableConcreteMore_SendConcrete_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseSerializablePayload_QueueNames  ""

#define IIGVerifyCaseSerializablePayload_MethodNames  ""

#define IIGVerifyCaseSerializablePayloadMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseSerializablePayload_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseSerializablePayload_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseSerializablePayload_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseSerializablePayloadMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseSerializablePayload_t
OSClassDescription_IIGVerifyCaseSerializablePayload =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseSerializablePayload_t),
        .name                    = "IIGVerifyCaseSerializablePayload",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializablePayload_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializablePayload_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseSerializablePayload_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializablePayload_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseSerializablePayload_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializablePayload_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseSerializablePayloadMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializablePayload_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseSerializablePayload_QueueNames,
    .methodNames     = IIGVerifyCaseSerializablePayload_MethodNames,
    .metaMethodNames = IIGVerifyCaseSerializablePayloadMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseSerializablePayloadMetaClass;

static kern_return_t
IIGVerifyCaseSerializablePayload_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseSerializablePayload_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseSerializablePayload.base,
    .metaPointer       = &gIIGVerifyCaseSerializablePayloadMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseSerializablePayload),

    .resv2             = {0},

    .New               = &IIGVerifyCaseSerializablePayload_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseSerializablePayload_Declaration;
const void * const
gIIGVerifyCaseSerializablePayload_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseSerializablePayload_Class;

static kern_return_t
IIGVerifyCaseSerializablePayload_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseSerializablePayloadMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseSerializablePayloadMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseSerializablePayload) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseSerializablePayload::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseSerializablePayload::_Dispatch(IIGVerifyCaseSerializablePayload * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseSerializablePayload::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseSerializablePayloadMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseConcretePayload_QueueNames  ""

#define IIGVerifyCaseConcretePayload_MethodNames  ""

#define IIGVerifyCaseConcretePayloadMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseConcretePayload_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseConcretePayload_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseConcretePayload_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseConcretePayloadMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseConcretePayload_t
OSClassDescription_IIGVerifyCaseConcretePayload =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseConcretePayload_t),
        .name                    = "IIGVerifyCaseConcretePayload",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConcretePayload_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConcretePayload_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseConcretePayload_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConcretePayload_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseConcretePayload_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConcretePayload_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseConcretePayloadMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConcretePayload_t, metaMethodNames),
        .flags                   = 0*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseConcretePayload_QueueNames,
    .methodNames     = IIGVerifyCaseConcretePayload_MethodNames,
    .metaMethodNames = IIGVerifyCaseConcretePayloadMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseConcretePayloadMetaClass;

static kern_return_t
IIGVerifyCaseConcretePayload_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseConcretePayload_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseConcretePayload.base,
    .metaPointer       = &gIIGVerifyCaseConcretePayloadMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseConcretePayload),

    .resv2             = {0},

    .New               = &IIGVerifyCaseConcretePayload_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseConcretePayload_Declaration;
const void * const
gIIGVerifyCaseConcretePayload_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseConcretePayload_Class;

static kern_return_t
IIGVerifyCaseConcretePayload_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseConcretePayloadMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseConcretePayloadMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseConcretePayload) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseConcretePayload::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseConcretePayload::_Dispatch(IIGVerifyCaseConcretePayload * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseConcretePayload::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseConcretePayloadMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseSerializableConcreteMore_QueueNames  ""

#define IIGVerifyCaseSerializableConcreteMore_MethodNames  ""

#define IIGVerifyCaseSerializableConcreteMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseSerializableConcreteMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseSerializableConcreteMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseSerializableConcreteMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t
OSClassDescription_IIGVerifyCaseSerializableConcreteMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t),
        .name                    = "IIGVerifyCaseSerializableConcreteMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseSerializableConcreteMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseSerializableConcreteMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseSerializableConcreteMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseSerializableConcreteMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseSerializableConcreteMore_QueueNames,
    .methodNames     = IIGVerifyCaseSerializableConcreteMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseSerializableConcreteMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseSerializableConcreteMoreMetaClass;

static kern_return_t
IIGVerifyCaseSerializableConcreteMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseSerializableConcreteMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseSerializableConcreteMore.base,
    .metaPointer       = &gIIGVerifyCaseSerializableConcreteMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseSerializableConcreteMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseSerializableConcreteMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseSerializableConcreteMore_Declaration;
const void * const
gIIGVerifyCaseSerializableConcreteMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseSerializableConcreteMore_Class;

static kern_return_t
IIGVerifyCaseSerializableConcreteMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseSerializableConcreteMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseSerializableConcreteMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseSerializableConcreteMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::_Dispatch(IIGVerifyCaseSerializableConcreteMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseSerializableConcreteMore_SendPayload_ID:
        {
            ret = IIGVerifyCaseSerializableConcreteMore::SendPayload_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseSerializableConcreteMore::SendPayload_Handler, *self, &IIGVerifyCaseSerializableConcreteMore::SendPayload_Impl));
            break;
        }
        case IIGVerifyCaseSerializableConcreteMore_CopyPayload_ID:
        {
            ret = IIGVerifyCaseSerializableConcreteMore::CopyPayload_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseSerializableConcreteMore::CopyPayload_Handler, *self, &IIGVerifyCaseSerializableConcreteMore::CopyPayload_Impl));
            break;
        }
        case IIGVerifyCaseSerializableConcreteMore_SendConcrete_ID:
        {
            ret = IIGVerifyCaseSerializableConcreteMore::SendConcrete_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseSerializableConcreteMore::SendConcrete_Handler, *self, &IIGVerifyCaseSerializableConcreteMore::SendConcrete_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseSerializableConcreteMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseSerializableConcreteMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::SendPayload(
        IIGVerifyCaseSerializablePayload * payload,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableConcreteMore_SendPayload_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->payload__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->payload__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->payload__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_Content, payload);
    msg->content.payload = payload;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableConcreteMore_SendPayload_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::CopyPayload(
        IIGVerifyCaseSerializablePayload ** payload,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableConcreteMore_CopyPayload_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableConcreteMore_CopyPayload_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *payload = OSDynamicCast(IIGVerifyCaseSerializablePayload, (OSObject *) rpl->content.payload);
        if (rpl->content.payload && !*payload) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::SendConcrete(
        IIGVerifyCaseConcretePayload * payload,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseSerializableConcreteMore_SendConcrete_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->payload__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->payload__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->payload__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_Content, payload);
    msg->content.payload = payload;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseSerializableConcreteMore_SendConcrete_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::SendPayload_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SendPayload_Handler func)
{
    IIGVerifyCaseSerializableConcreteMore_SendPayload_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableConcreteMore_SendPayload_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(payload)) != NULL && OSDynamicCast(IIGVerifyCaseSerializablePayload, (OSObject *) MESSAGE_CONTENT(payload)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        MESSAGE_CONTENT(payload));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableConcreteMore_SendPayload_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableConcreteMore_SendPayload_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::CopyPayload_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CopyPayload_Handler func)
{
    IIGVerifyCaseSerializableConcreteMore_CopyPayload_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableConcreteMore_CopyPayload_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.payload);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableConcreteMore_CopyPayload_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_ObjRefs;
    reply->payload__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    reply->payload__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    reply->payload__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseSerializableConcreteMore_CopyPayload_Rpl_Content, payload);
    reply->payload__descriptor.size = 0;

    return (ret);
}

kern_return_t
IIGVerifyCaseSerializableConcreteMore::SendConcrete_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SendConcrete_Handler func)
{
    IIGVerifyCaseSerializableConcreteMore_SendConcrete_Invocation rpc = { _rpc };
    IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg *         message = rpc.message;
    const IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseSerializableConcreteMore_SendConcrete_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(payload)) != NULL && OSDynamicCast(IIGVerifyCaseConcretePayload, (OSObject *) MESSAGE_CONTENT(payload)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        MESSAGE_CONTENT(payload));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseSerializableConcreteMore_SendConcrete_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseSerializableConcreteMore_SendConcrete_Rpl_ObjRefs;

    return (ret);
}



