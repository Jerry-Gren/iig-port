/* iig(DriverKit-440) generated from IIGVerifyCaseIncludeLeaf.iig */

/* IIGVerifyCaseIncludeLeaf.iig:1- */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEINCLUDELEAF_H
#define _DRIVERKIT_IIGVerifyCASEINCLUDELEAF_H

#define IIGVerifyCaseLeafBytes 11

enum {
	kIIGVerifyCaseLeafWords = 6,
};

typedef char IIGVerifyCaseLeafName[IIGVerifyCaseLeafBytes];
typedef uint32_t IIGVerifyCaseLeafWords[kIIGVerifyCaseLeafWords];

#endif /* _DRIVERKIT_IIGVerifyCASEINCLUDELEAF_H */
