/* iig(DriverKit-440) generated from IIGVerifyCaseObjectArrayQualifiersMore.iig */

/* IIGVerifyCaseObjectArrayQualifiersMore.iig:1-11 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEOBJECTARRAYQUALIFIERSMORE_H
#define _DRIVERKIT_IIGVerifyCASEOBJECTARRAYQUALIFIERSMORE_H

typedef OSObject * IIGVerifyObjectArrayMore[3];
typedef OSObject * const IIGVerifyConstObjectArrayMore[4];
typedef OSObject * IIGVerifyAliasObjectMore;
typedef IIGVerifyAliasObjectMore IIGVerifyAliasObjectArrayMore[5];
typedef IIGVerifyAliasObjectMore const IIGVerifyAliasConstObjectArrayMore[6];

/* source class IIGVerifyCaseObjectArrayQualifiersMore IIGVerifyCaseObjectArrayQualifiersMore.iig:12-29 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseObjectArrayQualifiersMore : public OSObject
{
public:
	virtual kern_return_t
	OutputTypedefArray(uint32_t objectsCount,
	    IIGVerifyObjectArrayMore objects) LOCAL;

	virtual kern_return_t
	InputConstTypedefArray(IIGVerifyConstObjectArrayMore objects,
	    uint32_t objectsCount) LOCAL;

	virtual kern_return_t
	OutputAliasArray(uint32_t objectsCount,
	    IIGVerifyAliasObjectArrayMore objects) LOCAL;

	virtual kern_return_t
	InputAliasConstArray(IIGVerifyAliasConstObjectArrayMore objects,
	    uint32_t objectsCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseObjectArrayQualifiersMore IIGVerifyCaseObjectArrayQualifiersMore.iig:12-29 */

#define IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_ID            0x95ab29f7c763ddaeULL
#define IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_ID            0xe2982ced17ef2c34ULL
#define IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_ID            0x97daee1e236fb2f6ULL
#define IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_ID            0xe850077449b9813cULL

#define IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Args \
        uint32_t objectsCount, \
        OSObject ** objects

#define IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Args \
        OSObject ** const objects, \
        uint32_t objectsCount

#define IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Args \
        uint32_t objectsCount, \
        OSObject ** objects

#define IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Args \
        OSObject ** const objects, \
        uint32_t objectsCount

#define IIGVerifyCaseObjectArrayQualifiersMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseObjectArrayQualifiersMore * self, const IORPC rpc);\
\
    kern_return_t\
    OutputTypedefArray(\
        uint32_t objectsCount,\
        OSObject ** objects,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputConstTypedefArray(\
        OSObject ** const objects,\
        uint32_t objectsCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputAliasArray(\
        uint32_t objectsCount,\
        OSObject ** objects,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InputAliasConstArray(\
        OSObject ** const objects,\
        uint32_t objectsCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    OutputTypedefArray_Impl(IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Args);\
\
    kern_return_t\
    InputConstTypedefArray_Impl(IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Args);\
\
    kern_return_t\
    OutputAliasArray_Impl(IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Args);\
\
    kern_return_t\
    InputAliasConstArray_Impl(IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*OutputTypedefArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Args);\
    static kern_return_t\
    OutputTypedefArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputTypedefArray_Handler func);\
\
    typedef kern_return_t (*InputConstTypedefArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Args);\
    static kern_return_t\
    InputConstTypedefArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputConstTypedefArray_Handler func);\
\
    typedef kern_return_t (*OutputAliasArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Args);\
    static kern_return_t\
    OutputAliasArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputAliasArray_Handler func);\
\
    typedef kern_return_t (*InputAliasConstArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Args);\
    static kern_return_t\
    InputAliasConstArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputAliasConstArray_Handler func);\
\


#define IIGVerifyCaseObjectArrayQualifiersMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseObjectArrayQualifiersMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseObjectArrayQualifiersMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseObjectArrayQualifiersMore_Class;

class IIGVerifyCaseObjectArrayQualifiersMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseObjectArrayQualifiersMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseObjectArrayQualifiersMore_IVars;
struct IIGVerifyCaseObjectArrayQualifiersMore_LocalIVars;

class IIGVerifyCaseObjectArrayQualifiersMore : public OSObject, public IIGVerifyCaseObjectArrayQualifiersMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseObjectArrayQualifiersMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseObjectArrayQualifiersMore_DECLARE_IVARS
IIGVerifyCaseObjectArrayQualifiersMore_DECLARE_IVARS
#else /* IIGVerifyCaseObjectArrayQualifiersMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseObjectArrayQualifiersMore_IVars * ivars;
        IIGVerifyCaseObjectArrayQualifiersMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseObjectArrayQualifiersMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseObjectArrayQualifiersMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseObjectArrayQualifiersMore_Methods
    IIGVerifyCaseObjectArrayQualifiersMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseObjectArrayQualifiersMore.iig:31- */

#endif /* _DRIVERKIT_IIGVerifyCASEOBJECTARRAYQUALIFIERSMORE_H */
