/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseExtensions.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseExtensions.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseExtensionBase.h>
#include <DriverKit/IIGVerifyCaseExtensionChild.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseExtensionBase_ExtraSecond_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionBase_ExtraSecond_Msg_ObjRefs (1)

struct IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionBase_ExtraSecond_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseExtensionBase_ExtraSecond_Invocation;
struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseExtensionBase_ExtraFirst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionBase_ExtraFirst_Msg_ObjRefs (1)

struct IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionBase_ExtraFirst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseExtensionBase_ExtraFirst_Invocation;
struct IIGVerifyCaseExtensionBase_BaseLocal_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionBase_BaseLocal_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseExtensionBase_BaseLocal_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseExtensionBase_BaseLocal_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionBase_BaseLocal_Msg_ObjRefs (1)

struct IIGVerifyCaseExtensionBase_BaseLocal_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionBase_BaseLocal_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseExtensionBase_BaseLocal_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseExtensionBase_BaseLocal_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionBase_BaseLocal_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionBase_BaseLocal_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseExtensionBase_BaseLocal_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseExtensionBase_BaseLocal_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionBase_BaseLocal_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseExtensionBase_BaseLocal_Invocation;
struct IIGVerifyCaseExtensionChild_ChildLocal_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionChild_ChildLocal_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseExtensionChild_ChildLocal_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseExtensionChild_ChildLocal_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionChild_ChildLocal_Msg_ObjRefs (1)

struct IIGVerifyCaseExtensionChild_ChildLocal_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseExtensionChild_ChildLocal_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseExtensionChild_ChildLocal_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseExtensionChild_ChildLocal_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseExtensionChild_ChildLocal_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionChild_ChildLocal_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseExtensionChild_ChildLocal_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseExtensionChild_ChildLocal_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseExtensionChild_ChildLocal_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseExtensionChild_ChildLocal_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseExtensionBase_QueueNames  ""

#define IIGVerifyCaseExtensionBase_MethodNames  ""

#define IIGVerifyCaseExtensionBaseMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseExtensionBase_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseExtensionBase_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseExtensionBase_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseExtensionBaseMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseExtensionBase_t
OSClassDescription_IIGVerifyCaseExtensionBase =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseExtensionBase_t),
        .name                    = "IIGVerifyCaseExtensionBase",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionBase_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionBase_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseExtensionBase_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionBase_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseExtensionBase_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionBase_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseExtensionBaseMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionBase_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseExtensionBase_QueueNames,
    .methodNames     = IIGVerifyCaseExtensionBase_MethodNames,
    .metaMethodNames = IIGVerifyCaseExtensionBaseMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseExtensionBaseMetaClass;

static kern_return_t
IIGVerifyCaseExtensionBase_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseExtensionBase_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseExtensionBase.base,
    .metaPointer       = &gIIGVerifyCaseExtensionBaseMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseExtensionBase),

    .resv2             = {0},

    .New               = &IIGVerifyCaseExtensionBase_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseExtensionBase_Declaration;
const void * const
gIIGVerifyCaseExtensionBase_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseExtensionBase_Class;

static kern_return_t
IIGVerifyCaseExtensionBase_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseExtensionBaseMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseExtensionBaseMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseExtensionBase) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseExtensionBase::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseExtensionBase::_Dispatch(IIGVerifyCaseExtensionBase * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseExtensionBase_ExtraSecond_ID:
        {
            ret = IIGVerifyCaseExtensionBase::ExtraSecond_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseExtensionBase::ExtraSecond_Handler, *self, &IIGVerifyCaseExtensionBase::ExtraSecond_Impl));
            break;
        }
        case IIGVerifyCaseExtensionBase_ExtraFirst_ID:
        {
            ret = IIGVerifyCaseExtensionBase::ExtraFirst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseExtensionBase::ExtraFirst_Handler, *self, &IIGVerifyCaseExtensionBase::ExtraFirst_Impl));
            break;
        }
        case IIGVerifyCaseExtensionBase_BaseLocal_ID:
        {
            ret = IIGVerifyCaseExtensionBase::BaseLocal_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseExtensionBase::BaseLocal_Handler, *self, &IIGVerifyCaseExtensionBase::BaseLocal_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseExtensionBase::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseExtensionBaseMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionBase::ExtraSecond(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseExtensionBase_ExtraSecond_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseExtensionBase_ExtraSecond_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseExtensionBase_ExtraSecond_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseExtensionBase_ExtraSecond_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseExtensionBase_ExtraSecond_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionBase::ExtraFirst(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseExtensionBase_ExtraFirst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseExtensionBase_ExtraFirst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseExtensionBase_ExtraFirst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseExtensionBase_ExtraFirst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseExtensionBase_ExtraFirst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionBase::BaseLocal(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseExtensionBase_BaseLocal_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseExtensionBase_BaseLocal_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseExtensionBase_BaseLocal_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseExtensionBase_BaseLocal_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseExtensionBase_BaseLocal_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseExtensionBase_BaseLocal_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseExtensionBase_BaseLocal_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseExtensionBase_BaseLocal_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionBase::ExtraSecond_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ExtraSecond_Handler func)
{
    IIGVerifyCaseExtensionBase_ExtraSecond_Invocation rpc = { _rpc };
    IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseExtensionBase_ExtraSecond_Msg *         message = rpc.message;
    const IIGVerifyCaseExtensionBase_ExtraSecond_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseExtensionBase_ExtraSecond_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseExtensionBase_ExtraSecond_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseExtensionBase_ExtraSecond_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseExtensionBase_ExtraSecond_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseExtensionBase_ExtraSecond_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionBase::ExtraFirst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ExtraFirst_Handler func)
{
    IIGVerifyCaseExtensionBase_ExtraFirst_Invocation rpc = { _rpc };
    IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseExtensionBase_ExtraFirst_Msg *         message = rpc.message;
    const IIGVerifyCaseExtensionBase_ExtraFirst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseExtensionBase_ExtraFirst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseExtensionBase_ExtraFirst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseExtensionBase_ExtraFirst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseExtensionBase_ExtraFirst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseExtensionBase_ExtraFirst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionBase::BaseLocal_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        BaseLocal_Handler func)
{
    IIGVerifyCaseExtensionBase_BaseLocal_Invocation rpc = { _rpc };
    IIGVerifyCaseExtensionBase_BaseLocal_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseExtensionBase_BaseLocal_Msg *         message = rpc.message;
    const IIGVerifyCaseExtensionBase_BaseLocal_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseExtensionBase_BaseLocal_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseExtensionBase_BaseLocal_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseExtensionBase_BaseLocal_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseExtensionBase_BaseLocal_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseExtensionBase_BaseLocal_Rpl_ObjRefs;

    return (ret);
}

#if !KERNEL

#define IIGVerifyCaseExtensionChild_QueueNames  ""

#define IIGVerifyCaseExtensionChild_MethodNames  ""

#define IIGVerifyCaseExtensionChildMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseExtensionChild_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseExtensionChild_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseExtensionChild_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseExtensionChildMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseExtensionChild_t
OSClassDescription_IIGVerifyCaseExtensionChild =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseExtensionChild_t),
        .name                    = "IIGVerifyCaseExtensionChild",
        .superName               = "IIGVerifyCaseExtensionBase",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionChild_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionChild_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseExtensionChild_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionChild_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseExtensionChild_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionChild_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseExtensionChildMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseExtensionChild_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseExtensionChild_QueueNames,
    .methodNames     = IIGVerifyCaseExtensionChild_MethodNames,
    .metaMethodNames = IIGVerifyCaseExtensionChildMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseExtensionChildMetaClass;

static kern_return_t
IIGVerifyCaseExtensionChild_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseExtensionChild_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseExtensionChild.base,
    .metaPointer       = &gIIGVerifyCaseExtensionChildMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseExtensionChild),

    .resv2             = {0},

    .New               = &IIGVerifyCaseExtensionChild_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseExtensionChild_Declaration;
const void * const
gIIGVerifyCaseExtensionChild_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseExtensionChild_Class;

static kern_return_t
IIGVerifyCaseExtensionChild_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseExtensionChildMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseExtensionChildMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseExtensionChild) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseExtensionChild::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseExtensionChild::_Dispatch(IIGVerifyCaseExtensionChild * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseExtensionChild_ChildLocal_ID:
        {
            ret = IIGVerifyCaseExtensionChild::ChildLocal_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseExtensionChild::ChildLocal_Handler, *self, &IIGVerifyCaseExtensionChild::ChildLocal_Impl));
            break;
        }

        default:
            ret = IIGVerifyCaseExtensionBase::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseExtensionChild::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseExtensionChildMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionChild::ChildLocal(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseExtensionChild_ChildLocal_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseExtensionChild_ChildLocal_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseExtensionChild_ChildLocal_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseExtensionChild_ChildLocal_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseExtensionChild_ChildLocal_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseExtensionChild_ChildLocal_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseExtensionChild_ChildLocal_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseExtensionChild_ChildLocal_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseExtensionChild::ChildLocal_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ChildLocal_Handler func)
{
    IIGVerifyCaseExtensionChild_ChildLocal_Invocation rpc = { _rpc };
    IIGVerifyCaseExtensionChild_ChildLocal_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseExtensionChild_ChildLocal_Msg *         message = rpc.message;
    const IIGVerifyCaseExtensionChild_ChildLocal_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseExtensionChild_ChildLocal_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseExtensionChild_ChildLocal_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseExtensionChild_ChildLocal_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseExtensionChild_ChildLocal_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseExtensionChild_ChildLocal_Rpl_ObjRefs;

    return (ret);
}



