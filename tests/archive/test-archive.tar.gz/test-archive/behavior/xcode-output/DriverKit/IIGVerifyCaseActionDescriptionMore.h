/* iig(DriverKit-440) generated from IIGVerifyCaseActionDescriptionMore.iig */

/* IIGVerifyCaseActionDescriptionMore.iig:1-8 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEACTIONDESCRIPTIONMORE_H
#define _DRIVERKIT_IIGVerifyCASEACTIONDESCRIPTIONMORE_H

#define kIIGVerifyActionDescriptionQueueA "IIGVerifyActionDescriptionQueueA"
#define kIIGVerifyActionDescriptionQueueB "IIGVerifyActionDescriptionQueueB"

/* source class IIGVerifyCaseActionDescriptionMore IIGVerifyCaseActionDescriptionMore.iig:9-38 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseActionDescriptionMore : public OSObject
{
public:
	virtual void
	CompletionA(OSAction * action TARGET,
	    uint64_t token) REPLY LOCAL QUEUENAME(kIIGVerifyActionDescriptionQueueA);

	virtual void
	CompletionB(OSAction * action TARGET,
	    uint64_t token) REPLY LOCAL;

	virtual kern_return_t
	SubmitA(OSAction * completion TYPE(IIGVerifyCaseActionDescriptionMore::CompletionA),
	    uint64_t token) LOCAL QUEUENAME(kIIGVerifyActionDescriptionQueueB);

	virtual kern_return_t
	SubmitB(OSAction * completion TYPE(IIGVerifyCaseActionDescriptionMore::CompletionB),
	    uint64_t token) LOCAL;

	virtual void
	KernelCompletionA(OSAction * action TARGET,
	    uint64_t token)
	    KERNEL
	    TYPE(IIGVerifyCaseActionDescriptionMore::CompletionA);

	virtual void
	KernelCompletionB(OSAction * action TARGET,
	    uint64_t token)
	    KERNEL
	    TYPE(IIGVerifyCaseActionDescriptionMore::CompletionB);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseActionDescriptionMore IIGVerifyCaseActionDescriptionMore.iig:9-38 */

#define IIGVerifyCaseActionDescriptionMore_CompletionA_ID            0x924bee1db819c22fULL
#define IIGVerifyCaseActionDescriptionMore_CompletionB_ID            0xd92452902bd64765ULL
#define IIGVerifyCaseActionDescriptionMore_SubmitA_ID            0xfb796deb32946e4bULL
#define IIGVerifyCaseActionDescriptionMore_SubmitB_ID            0xab85489ed8810a97ULL
#define IIGVerifyCaseActionDescriptionMore_KernelCompletionA_ID            0xd5688ce724a75c45ULL
#define IIGVerifyCaseActionDescriptionMore_KernelCompletionB_ID            0xf110ac0c8d8ab620ULL

#define IIGVerifyCaseActionDescriptionMore_CompletionA_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseActionDescriptionMore_CompletionB_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseActionDescriptionMore_SubmitA_Args \
        OSAction * completion, \
        uint64_t token

#define IIGVerifyCaseActionDescriptionMore_SubmitB_Args \
        OSAction * completion, \
        uint64_t token

#define IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseActionDescriptionMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseActionDescriptionMore * self, const IORPC rpc);\
\
    kern_return_t\
    CompletionA(\
        IORPC rpc,\
        OSAction * action,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CompletionB(\
        IORPC rpc,\
        OSAction * action,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitA(\
        OSAction * completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitB(\
        OSAction * completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CreateActionKernelCompletionA(size_t referenceSize, OSAction ** action);\
\
    kern_return_t\
    CreateActionKernelCompletionB(size_t referenceSize, OSAction ** action);\
\
\
protected:\
    /* _Impl methods */\
\
    void\
    CompletionA_Impl(IIGVerifyCaseActionDescriptionMore_CompletionA_Args);\
\
    void\
    CompletionB_Impl(IIGVerifyCaseActionDescriptionMore_CompletionB_Args);\
\
    kern_return_t\
    SubmitA_Impl(IIGVerifyCaseActionDescriptionMore_SubmitA_Args);\
\
    kern_return_t\
    SubmitB_Impl(IIGVerifyCaseActionDescriptionMore_SubmitB_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef void (*CompletionA_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionDescriptionMore_CompletionA_Args);\
    static kern_return_t\
    CompletionA_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionA_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    CompletionA_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionA_Handler func);\
\
    typedef void (*CompletionB_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionDescriptionMore_CompletionB_Args);\
    static kern_return_t\
    CompletionB_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionB_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    CompletionB_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionB_Handler func);\
\
    typedef kern_return_t (*SubmitA_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionDescriptionMore_SubmitA_Args);\
    static kern_return_t\
    SubmitA_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitA_Handler func);\
\
    typedef kern_return_t (*SubmitB_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionDescriptionMore_SubmitB_Args);\
    static kern_return_t\
    SubmitB_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitB_Handler func);\
\


#define IIGVerifyCaseActionDescriptionMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    void\
    KernelCompletionA_Impl(IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Args);\
\
    void\
    KernelCompletionB_Impl(IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Args);\
\


#define IIGVerifyCaseActionDescriptionMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseActionDescriptionMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseActionDescriptionMore_Class;

class IIGVerifyCaseActionDescriptionMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseActionDescriptionMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseActionDescriptionMore_IVars;
struct IIGVerifyCaseActionDescriptionMore_LocalIVars;

class IIGVerifyCaseActionDescriptionMore : public OSObject, public IIGVerifyCaseActionDescriptionMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseActionDescriptionMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseActionDescriptionMore_DECLARE_IVARS
IIGVerifyCaseActionDescriptionMore_DECLARE_IVARS
#else /* IIGVerifyCaseActionDescriptionMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseActionDescriptionMore_IVars * ivars;
        IIGVerifyCaseActionDescriptionMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseActionDescriptionMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseActionDescriptionMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseActionDescriptionMore_Methods
    IIGVerifyCaseActionDescriptionMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass;
extern const OSClassLoadInformation OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Class;

class OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

class  __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAInterface : public OSInterface
{
public:
};

struct OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_IVars;
struct OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_LocalIVars;

class __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA : public OSAction, public OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAInterface
{
#if KERNEL
    OSDeclareDefaultStructorsWithDispatch(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA);
#endif /* KERNEL */

#if !KERNEL
    friend class OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass;
#endif /* !KERNEL */

public:
#ifdef OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_DECLARE_IVARS
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_DECLARE_IVARS
#else /* OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_DECLARE_IVARS */
    union
    {
        OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_IVars * ivars;
        OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_LocalIVars * lvars;
    };
#endif /* OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_DECLARE_IVARS */
#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass; };
    virtual const OSMetaClass *
    getMetaClass() const APPLE_KEXT_OVERRIDE { return gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionAMetaClass; };
#endif /* KERNEL */

    using super = OSAction;

#if !KERNEL
    OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_Methods
#endif /* !KERNEL */

    OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionA_VirtualMethods
};

#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass;
extern const OSClassLoadInformation OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Class;

class OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

class  __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBInterface : public OSInterface
{
public:
};

struct OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_IVars;
struct OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_LocalIVars;

class __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB : public OSAction, public OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBInterface
{
#if KERNEL
    OSDeclareDefaultStructorsWithDispatch(OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB);
#endif /* KERNEL */

#if !KERNEL
    friend class OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass;
#endif /* !KERNEL */

public:
#ifdef OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_DECLARE_IVARS
OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_DECLARE_IVARS
#else /* OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_DECLARE_IVARS */
    union
    {
        OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_IVars * ivars;
        OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_LocalIVars * lvars;
    };
#endif /* OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_DECLARE_IVARS */
#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass; };
    virtual const OSMetaClass *
    getMetaClass() const APPLE_KEXT_OVERRIDE { return gOSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionBMetaClass; };
#endif /* KERNEL */

    using super = OSAction;

#if !KERNEL
    OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_Methods
#endif /* !KERNEL */

    OSAction_IIGVerifyCaseActionDescriptionMore_KernelCompletionB_VirtualMethods
};

#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseActionDescriptionMore.iig:40- */

#endif /* _DRIVERKIT_IIGVerifyCASEACTIONDESCRIPTIONMORE_H */
