/* iig(DriverKit-440) generated from IIGVerifyCaseArithmeticBoundExpressions.iig */

/* IIGVerifyCaseArithmeticBoundExpressions.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEARITHMETICBOUNDEXPRESSIONS_H
#define _DRIVERKIT_IIGVerifyCASEARITHMETICBOUNDEXPRESSIONS_H

#define IIGVerifyCaseArithmeticBoundBase 3
#define IIGVerifyCaseArithmeticBoundExtra 2

/* source class IIGVerifyCaseArithmeticBoundExpressions IIGVerifyCaseArithmeticBoundExpressions.iig:9-15 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseArithmeticBoundExpressions : public OSObject
{
public:
	virtual kern_return_t
	InlineAddExpression(
	    const uint8_t bytes[IIGVerifyCaseArithmeticBoundBase + IIGVerifyCaseArithmeticBoundExtra],
	    uint32_t bytesCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseArithmeticBoundExpressions IIGVerifyCaseArithmeticBoundExpressions.iig:9-15 */

#define IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_ID            0xb78a0ebe3b142c6dULL

#define IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseArithmeticBoundExpressions_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseArithmeticBoundExpressions * self, const IORPC rpc);\
\
    kern_return_t\
    InlineAddExpression(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InlineAddExpression_Impl(IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InlineAddExpression_Handler)(OSMetaClassBase * target, IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Args);\
    static kern_return_t\
    InlineAddExpression_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineAddExpression_Handler func);\
\


#define IIGVerifyCaseArithmeticBoundExpressions_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseArithmeticBoundExpressions_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseArithmeticBoundExpressionsMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseArithmeticBoundExpressions_Class;

class IIGVerifyCaseArithmeticBoundExpressionsMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseArithmeticBoundExpressionsInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseArithmeticBoundExpressions_IVars;
struct IIGVerifyCaseArithmeticBoundExpressions_LocalIVars;

class IIGVerifyCaseArithmeticBoundExpressions : public OSObject, public IIGVerifyCaseArithmeticBoundExpressionsInterface
{
#if !KERNEL
    friend class IIGVerifyCaseArithmeticBoundExpressionsMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseArithmeticBoundExpressions_DECLARE_IVARS
IIGVerifyCaseArithmeticBoundExpressions_DECLARE_IVARS
#else /* IIGVerifyCaseArithmeticBoundExpressions_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseArithmeticBoundExpressions_IVars * ivars;
        IIGVerifyCaseArithmeticBoundExpressions_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseArithmeticBoundExpressions_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseArithmeticBoundExpressionsMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseArithmeticBoundExpressions_Methods
    IIGVerifyCaseArithmeticBoundExpressions_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseArithmeticBoundExpressions.iig:17- */

#endif /* _DRIVERKIT_IIGVerifyCASEARITHMETICBOUNDEXPRESSIONS_H */
