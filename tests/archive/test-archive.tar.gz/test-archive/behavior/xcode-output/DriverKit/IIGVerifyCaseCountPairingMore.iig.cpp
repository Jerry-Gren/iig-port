/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseCountPairingMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseCountPairingMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseCountPairingMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[16];
    uint32_t  bytesCount;
    uint32_t  otherCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_ObjRefs (1)

struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Invocation;
struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  bytesCount;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[16];
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_ObjRefs (1)

struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Invocation;
struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_ObjRefs (1)

struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[8];
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Invocation;
struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_ObjRefs (1)

struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_Content
{
    IORPCMessage __hdr;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[8];
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseCountPairingMore_QueueNames  ""

#define IIGVerifyCaseCountPairingMore_MethodNames  ""

#define IIGVerifyCaseCountPairingMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseCountPairingMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseCountPairingMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseCountPairingMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseCountPairingMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseCountPairingMore_t
OSClassDescription_IIGVerifyCaseCountPairingMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseCountPairingMore_t),
        .name                    = "IIGVerifyCaseCountPairingMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountPairingMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountPairingMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseCountPairingMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountPairingMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseCountPairingMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountPairingMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseCountPairingMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountPairingMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseCountPairingMore_QueueNames,
    .methodNames     = IIGVerifyCaseCountPairingMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseCountPairingMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseCountPairingMoreMetaClass;

static kern_return_t
IIGVerifyCaseCountPairingMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseCountPairingMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseCountPairingMore.base,
    .metaPointer       = &gIIGVerifyCaseCountPairingMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseCountPairingMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseCountPairingMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseCountPairingMore_Declaration;
const void * const
gIIGVerifyCaseCountPairingMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseCountPairingMore_Class;

static kern_return_t
IIGVerifyCaseCountPairingMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseCountPairingMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseCountPairingMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseCountPairingMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseCountPairingMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseCountPairingMore::_Dispatch(IIGVerifyCaseCountPairingMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseCountPairingMore_InputBytesCountAfter_ID:
        {
            ret = IIGVerifyCaseCountPairingMore::InputBytesCountAfter_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountPairingMore::InputBytesCountAfter_Handler, *self, &IIGVerifyCaseCountPairingMore::InputBytesCountAfter_Impl));
            break;
        }
        case IIGVerifyCaseCountPairingMore_InputBytesCountBefore_ID:
        {
            ret = IIGVerifyCaseCountPairingMore::InputBytesCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountPairingMore::InputBytesCountBefore_Handler, *self, &IIGVerifyCaseCountPairingMore::InputBytesCountBefore_Impl));
            break;
        }
        case IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_ID:
        {
            ret = IIGVerifyCaseCountPairingMore::OutputWordsCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountPairingMore::OutputWordsCountBefore_Handler, *self, &IIGVerifyCaseCountPairingMore::OutputWordsCountBefore_Impl));
            break;
        }
        case IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_ID:
        {
            ret = IIGVerifyCaseCountPairingMore::OutputWordsCountAfter_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountPairingMore::OutputWordsCountAfter_Handler, *self, &IIGVerifyCaseCountPairingMore::OutputWordsCountAfter_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseCountPairingMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseCountPairingMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::InputBytesCountAfter(
        const unsigned char * bytes,
        uint32_t bytesCount,
        uint32_t otherCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_InputBytesCountAfter_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

    msg->content.otherCount = otherCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountPairingMore_InputBytesCountAfter_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::InputBytesCountBefore(
        uint32_t bytesCount,
        const unsigned char * bytes,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_InputBytesCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytesCount = bytesCount;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountPairingMore_InputBytesCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::OutputWordsCountBefore(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::OutputWordsCountAfter(
        unsigned int * words,
        uint32_t wordsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

    msg->content.wordsCount = wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::InputBytesCountAfter_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputBytesCountAfter_Handler func)
{
    IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Invocation rpc = { _rpc };
    IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg *         message = rpc.message;
    const IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount,
        MESSAGE_CONTENT(otherCount));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_InputBytesCountAfter_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_InputBytesCountAfter_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::InputBytesCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputBytesCountBefore_Handler func)
{
    IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        bytesCount,
        &MESSAGE_CONTENT(__bytes[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_InputBytesCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_InputBytesCountBefore_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::OutputWordsCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputWordsCountBefore_Handler func)
{
    IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_OutputWordsCountBefore_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCountPairingMore::OutputWordsCountAfter_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputWordsCountAfter_Handler func)
{
    IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Invocation rpc = { _rpc };
    IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg *         message = rpc.message;
    const IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.__words[0],
        wordsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountPairingMore_OutputWordsCountAfter_Rpl_ObjRefs;

    return (ret);
}



