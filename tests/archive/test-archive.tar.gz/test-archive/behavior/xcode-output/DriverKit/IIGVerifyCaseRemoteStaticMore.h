/* iig(DriverKit-440) generated from IIGVerifyCaseRemoteStaticMore.iig */

/* IIGVerifyCaseRemoteStaticMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEREMOTESTATICMORE_H
#define _DRIVERKIT_IIGVerifyCASEREMOTESTATICMORE_H

/* source class IIGVerifyCaseRemoteStaticMore IIGVerifyCaseRemoteStaticMore.iig:6-16 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseRemoteStaticMore : public OSObject
{
public:
	static kern_return_t
	StaticRemote(uint64_t value) REMOTE;

	static kern_return_t
	StaticInvokeReply(uint64_t value) INVOKEREPLY;

	virtual kern_return_t
	InstanceRemote(uint64_t value) REMOTE;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseRemoteStaticMore IIGVerifyCaseRemoteStaticMore.iig:6-16 */

#define IIGVerifyCaseRemoteStaticMore_StaticRemote_ID            0x99e7e3d4771be423ULL
#define IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_ID            0x87ace83ac8a1764eULL
#define IIGVerifyCaseRemoteStaticMore_InstanceRemote_ID            0xbfd6a45733eee890ULL

#define IIGVerifyCaseRemoteStaticMore_StaticRemote_Args \
        uint64_t value

#define IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Args \
        const IORPC rpc, \
        uint64_t value

#define IIGVerifyCaseRemoteStaticMore_InstanceRemote_Args \
        uint64_t value

#define IIGVerifyCaseRemoteStaticMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseRemoteStaticMore * self, const IORPC rpc);\
\
    static kern_return_t\
    StaticRemote(\
        uint64_t value);\
\
    static kern_return_t\
    StaticInvokeReply(\
        uint64_t value);\
\
    kern_return_t\
    InstanceRemote(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*StaticRemote_Handler)(IIGVerifyCaseRemoteStaticMore_StaticRemote_Args);\
    static kern_return_t\
    StaticRemote_Invoke(const IORPC rpc,\
        StaticRemote_Handler func);\
\
    typedef kern_return_t (*StaticInvokeReply_Handler)(IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Args);\
    static kern_return_t\
    StaticInvokeReply_Invoke(const IORPC rpc,\
        StaticInvokeReply_Handler func);\
\
    typedef kern_return_t (*InstanceRemote_Handler)(OSMetaClassBase * target, IIGVerifyCaseRemoteStaticMore_InstanceRemote_Args);\
    static kern_return_t\
    InstanceRemote_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceRemote_Handler func);\
\


#define IIGVerifyCaseRemoteStaticMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    static kern_return_t\
    StaticRemote_Impl(IIGVerifyCaseRemoteStaticMore_StaticRemote_Args);\
\
    static kern_return_t\
    StaticInvokeReply_Impl(IIGVerifyCaseRemoteStaticMore_StaticInvokeReply_Args);\
\
    kern_return_t\
    InstanceRemote_Impl(IIGVerifyCaseRemoteStaticMore_InstanceRemote_Args);\
\


#define IIGVerifyCaseRemoteStaticMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseRemoteStaticMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseRemoteStaticMore_Class;

class IIGVerifyCaseRemoteStaticMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseRemoteStaticMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseRemoteStaticMore_IVars;
struct IIGVerifyCaseRemoteStaticMore_LocalIVars;

class IIGVerifyCaseRemoteStaticMore : public OSObject, public IIGVerifyCaseRemoteStaticMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseRemoteStaticMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseRemoteStaticMore_DECLARE_IVARS
IIGVerifyCaseRemoteStaticMore_DECLARE_IVARS
#else /* IIGVerifyCaseRemoteStaticMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseRemoteStaticMore_IVars * ivars;
        IIGVerifyCaseRemoteStaticMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseRemoteStaticMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseRemoteStaticMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseRemoteStaticMore_Methods
    IIGVerifyCaseRemoteStaticMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseRemoteStaticMore.iig:18- */

#endif /* _DRIVERKIT_IIGVerifyCASEREMOTESTATICMORE_H */
