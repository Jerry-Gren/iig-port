/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseActionAliasMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseActionAliasMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseActionAliasMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  action;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
};
struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t action__descriptor;
    IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_ObjRefs (2)

struct IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionAliasMore_CompletionAlias_Invocation;
struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
};
struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t completion__descriptor;
    IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_ObjRefs (2)

struct IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionAliasMore_SubmitAlias_Invocation;
struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSAction  completion;
    uint64_t  token;
};
#pragma pack(4)
struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_ObjRefs (1)

struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseActionAliasMore_SubmitConstAlias_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gOSStringMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseActionAliasMore_QueueNames  ""

#define IIGVerifyCaseActionAliasMore_MethodNames  ""

#define IIGVerifyCaseActionAliasMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseActionAliasMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseActionAliasMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseActionAliasMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseActionAliasMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseActionAliasMore_t
OSClassDescription_IIGVerifyCaseActionAliasMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseActionAliasMore_t),
        .name                    = "IIGVerifyCaseActionAliasMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionAliasMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionAliasMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseActionAliasMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionAliasMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseActionAliasMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionAliasMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseActionAliasMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseActionAliasMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseActionAliasMore_QueueNames,
    .methodNames     = IIGVerifyCaseActionAliasMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseActionAliasMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseActionAliasMoreMetaClass;

static kern_return_t
IIGVerifyCaseActionAliasMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseActionAliasMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseActionAliasMore.base,
    .metaPointer       = &gIIGVerifyCaseActionAliasMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseActionAliasMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseActionAliasMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseActionAliasMore_Declaration;
const void * const
gIIGVerifyCaseActionAliasMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseActionAliasMore_Class;

static kern_return_t
IIGVerifyCaseActionAliasMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseActionAliasMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionAliasMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseActionAliasMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseActionAliasMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseActionAliasMore::_Dispatch(IIGVerifyCaseActionAliasMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseActionAliasMore_CompletionAlias_ID:
        {
            ret = IIGVerifyCaseActionAliasMore::CompletionAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionAliasMore::CompletionAlias_Handler, *self, &IIGVerifyCaseActionAliasMore::CompletionAlias_Impl));
            break;
        }
        case IIGVerifyCaseActionAliasMore_SubmitAlias_ID:
        {
            ret = IIGVerifyCaseActionAliasMore::SubmitAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionAliasMore::SubmitAlias_Handler, *self, &IIGVerifyCaseActionAliasMore::SubmitAlias_Impl));
            break;
        }
        case IIGVerifyCaseActionAliasMore_SubmitConstAlias_ID:
        {
            ret = IIGVerifyCaseActionAliasMore::SubmitConstAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseActionAliasMore::SubmitConstAlias_Handler, *self, &IIGVerifyCaseActionAliasMore::SubmitConstAlias_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseActionAliasMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseActionAliasMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseActionAliasMore::CompletionAlias(
        IORPC rpc,
        IIGVerifyAliasAction action,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    struct IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_With_Content * msg = (typeof(msg)) rpc.reply;
#ifdef KERNEL
    rpc.kernelContent = &msg->content.__hdr;
#endif /* KERNEL */

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 1*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 1*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionAliasMore_CompletionAlias_ID;
    msg->content.__object = (OSObjectRef) action;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->action__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.action = (OSObjectRef) action;

    msg->content.token = token;


    ret = kIOReturnSuccess;

    return (ret);
}

kern_return_t
IIGVerifyCaseActionAliasMore::SubmitAlias(
        IIGVerifyAliasAction completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionAliasMore_SubmitAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->completion__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.completion = (OSObjectRef) completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseActionAliasMore_SubmitAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseActionAliasMore::SubmitConstAlias(
        IIGVerifyAliasConstAction completion,
        uint64_t token,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseActionAliasMore_SubmitConstAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.completion = *completion;

    msg->content.token = token;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseActionAliasMore_SubmitConstAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseActionAliasMore::CompletionAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionAlias_Handler func)
{
    return IIGVerifyCaseActionAliasMore::CompletionAlias_Invoke(_rpc, target, func, NULL);
}

kern_return_t
IIGVerifyCaseActionAliasMore::CompletionAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CompletionAlias_Handler func,
        const OSMetaClass * targetActionClass)
{
    IIGVerifyCaseActionAliasMore_CompletionAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseActionAliasMore_CompletionAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionAliasMore_CompletionAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
    OSAction * action;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionAliasMore_CompletionAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (targetActionClass) {
        action = (OSAction *) OSMetaClassBase::safeMetaCast((OSObject *) MESSAGE_CONTENT(action), targetActionClass);
    } else {
        action = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(action));
    }
    if (!action && MESSAGE_CONTENT(action)) return (kIOReturnBadArgument);

    (*func)(target,
        action,
        MESSAGE_CONTENT(token));


    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseActionAliasMore::SubmitAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitAlias_Handler func)
{
    IIGVerifyCaseActionAliasMore_SubmitAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionAliasMore_SubmitAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSAction * completion;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionAliasMore_SubmitAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    completion = OSDynamicCast(OSAction, (OSObject *) MESSAGE_CONTENT(completion));
    if (!completion && MESSAGE_CONTENT(completion)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        completion,
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseActionAliasMore_SubmitAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseActionAliasMore_SubmitAlias_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseActionAliasMore::SubmitConstAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SubmitConstAlias_Handler func)
{
    IIGVerifyCaseActionAliasMore_SubmitConstAlias_Invocation rpc = { _rpc };
    IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg *         message = rpc.message;
    const IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseActionAliasMore_SubmitConstAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(completion),
        MESSAGE_CONTENT(token));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseActionAliasMore_SubmitConstAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseActionAliasMore_SubmitConstAlias_Rpl_ObjRefs;

    return (ret);
}



