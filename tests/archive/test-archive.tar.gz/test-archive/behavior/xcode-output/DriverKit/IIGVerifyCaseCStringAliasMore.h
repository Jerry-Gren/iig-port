/* iig(DriverKit-440) generated from IIGVerifyCaseCStringAliasMore.iig */

/* IIGVerifyCaseCStringAliasMore.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASECSTRINGALIASMORE_H
#define _DRIVERKIT_IIGVerifyCASECSTRINGALIASMORE_H

typedef const char * IIGVerifyAliasCString;
typedef const char IIGVerifyAliasConstChar;

/* source class IIGVerifyCaseCStringAliasMore IIGVerifyCaseCStringAliasMore.iig:9-16 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseCStringAliasMore : public OSObject
{
public:
	virtual kern_return_t
	CStringAlias(IIGVerifyAliasCString name) LOCAL;

	virtual kern_return_t
	CStringArrayAlias(IIGVerifyAliasConstChar name[32]) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseCStringAliasMore IIGVerifyCaseCStringAliasMore.iig:9-16 */

#define IIGVerifyCaseCStringAliasMore_CStringAlias_ID            0xea71af89d1ca5778ULL
#define IIGVerifyCaseCStringAliasMore_CStringArrayAlias_ID            0xeeb2845e32aac9f0ULL

#define IIGVerifyCaseCStringAliasMore_CStringAlias_Args \
        IIGVerifyAliasCString name

#define IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Args \
        const char * name

#define IIGVerifyCaseCStringAliasMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseCStringAliasMore * self, const IORPC rpc);\
\
    kern_return_t\
    CStringAlias(\
        IIGVerifyAliasCString name,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CStringArrayAlias(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    CStringAlias_Impl(IIGVerifyCaseCStringAliasMore_CStringAlias_Args);\
\
    kern_return_t\
    CStringArrayAlias_Impl(IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*CStringAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseCStringAliasMore_CStringAlias_Args);\
    static kern_return_t\
    CStringAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CStringAlias_Handler func);\
\
    typedef kern_return_t (*CStringArrayAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseCStringAliasMore_CStringArrayAlias_Args);\
    static kern_return_t\
    CStringArrayAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CStringArrayAlias_Handler func);\
\


#define IIGVerifyCaseCStringAliasMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseCStringAliasMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseCStringAliasMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseCStringAliasMore_Class;

class IIGVerifyCaseCStringAliasMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseCStringAliasMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseCStringAliasMore_IVars;
struct IIGVerifyCaseCStringAliasMore_LocalIVars;

class IIGVerifyCaseCStringAliasMore : public OSObject, public IIGVerifyCaseCStringAliasMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseCStringAliasMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseCStringAliasMore_DECLARE_IVARS
IIGVerifyCaseCStringAliasMore_DECLARE_IVARS
#else /* IIGVerifyCaseCStringAliasMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseCStringAliasMore_IVars * ivars;
        IIGVerifyCaseCStringAliasMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseCStringAliasMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseCStringAliasMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseCStringAliasMore_Methods
    IIGVerifyCaseCStringAliasMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseCStringAliasMore.iig:18- */

#endif /* _DRIVERKIT_IIGVerifyCASECSTRINGALIASMORE_H */
