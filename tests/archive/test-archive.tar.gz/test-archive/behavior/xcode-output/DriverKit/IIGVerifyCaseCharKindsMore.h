/* iig(DriverKit-440) generated from IIGVerifyCaseCharKindsMore.iig */

/* IIGVerifyCaseCharKindsMore.iig:1-9 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASECHARKINDSMORE_H
#define _DRIVERKIT_IIGVerifyCASECHARKINDSMORE_H

typedef char IIGVerifyPlainCharMore;
typedef signed char IIGVerifySignedCharMore;
typedef unsigned char IIGVerifyUnsignedCharMore;

/* source class IIGVerifyCaseCharKindsMore IIGVerifyCaseCharKindsMore.iig:10-22 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseCharKindsMore : public OSObject
{
public:
	virtual kern_return_t
	PlainCharArray(const IIGVerifyPlainCharMore text[7]) LOCAL;

	virtual kern_return_t
	SignedCharArray(const IIGVerifySignedCharMore bytes[8],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	UnsignedCharArray(const IIGVerifyUnsignedCharMore bytes[9],
	    uint32_t bytesCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseCharKindsMore IIGVerifyCaseCharKindsMore.iig:10-22 */

#define IIGVerifyCaseCharKindsMore_PlainCharArray_ID            0xdf47c6454b277600ULL
#define IIGVerifyCaseCharKindsMore_SignedCharArray_ID            0xbade752cf3bcf9e0ULL
#define IIGVerifyCaseCharKindsMore_UnsignedCharArray_ID            0xb277b16200c861c4ULL

#define IIGVerifyCaseCharKindsMore_PlainCharArray_Args \
        const char * text

#define IIGVerifyCaseCharKindsMore_SignedCharArray_Args \
        const signed char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseCharKindsMore_UnsignedCharArray_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseCharKindsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseCharKindsMore * self, const IORPC rpc);\
\
    kern_return_t\
    PlainCharArray(\
        const char * text,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SignedCharArray(\
        const signed char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    UnsignedCharArray(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    PlainCharArray_Impl(IIGVerifyCaseCharKindsMore_PlainCharArray_Args);\
\
    kern_return_t\
    SignedCharArray_Impl(IIGVerifyCaseCharKindsMore_SignedCharArray_Args);\
\
    kern_return_t\
    UnsignedCharArray_Impl(IIGVerifyCaseCharKindsMore_UnsignedCharArray_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*PlainCharArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseCharKindsMore_PlainCharArray_Args);\
    static kern_return_t\
    PlainCharArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        PlainCharArray_Handler func);\
\
    typedef kern_return_t (*SignedCharArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseCharKindsMore_SignedCharArray_Args);\
    static kern_return_t\
    SignedCharArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SignedCharArray_Handler func);\
\
    typedef kern_return_t (*UnsignedCharArray_Handler)(OSMetaClassBase * target, IIGVerifyCaseCharKindsMore_UnsignedCharArray_Args);\
    static kern_return_t\
    UnsignedCharArray_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        UnsignedCharArray_Handler func);\
\


#define IIGVerifyCaseCharKindsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseCharKindsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseCharKindsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseCharKindsMore_Class;

class IIGVerifyCaseCharKindsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseCharKindsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseCharKindsMore_IVars;
struct IIGVerifyCaseCharKindsMore_LocalIVars;

class IIGVerifyCaseCharKindsMore : public OSObject, public IIGVerifyCaseCharKindsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseCharKindsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseCharKindsMore_DECLARE_IVARS
IIGVerifyCaseCharKindsMore_DECLARE_IVARS
#else /* IIGVerifyCaseCharKindsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseCharKindsMore_IVars * ivars;
        IIGVerifyCaseCharKindsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseCharKindsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseCharKindsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseCharKindsMore_Methods
    IIGVerifyCaseCharKindsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseCharKindsMore.iig:24- */

#endif /* _DRIVERKIT_IIGVerifyCASECHARKINDSMORE_H */
