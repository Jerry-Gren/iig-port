/* iig(DriverKit-440) generated from IIGVerifyCaseBounds.iig */

/* IIGVerifyCaseBounds.iig:1-13 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEBOUNDS_H
#define _DRIVERKIT_IIGVerifyCASEBOUNDS_H

#define IIGVerifyCaseMacroBytes 7

enum {
	kIIGVerifyCaseEnumBytes = 5,
};

typedef uint32_t IIGVerifyCaseWords3[3];

/* source class IIGVerifyCaseBounds IIGVerifyCaseBounds.iig:14-29 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseBounds : public OSObject
{
public:
	virtual kern_return_t
	MacroInput(const uint8_t bytes[IIGVerifyCaseMacroBytes],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	EnumInput(const uint8_t bytes[kIIGVerifyCaseEnumBytes],
	    uint32_t bytesCount) LOCAL;

	virtual kern_return_t
	TypedefOutput(uint32_t wordsCount, IIGVerifyCaseWords3 words) LOCAL;

	virtual kern_return_t
	StringPointer(const char * name) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseBounds IIGVerifyCaseBounds.iig:14-29 */

#define IIGVerifyCaseBounds_MacroInput_ID            0xda9b0e2bd959a072ULL
#define IIGVerifyCaseBounds_EnumInput_ID            0xd384729168a1964aULL
#define IIGVerifyCaseBounds_TypedefOutput_ID            0xf8d06287acda0e17ULL
#define IIGVerifyCaseBounds_StringPointer_ID            0x982029d69e11641eULL

#define IIGVerifyCaseBounds_MacroInput_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseBounds_EnumInput_Args \
        const unsigned char * bytes, \
        uint32_t bytesCount

#define IIGVerifyCaseBounds_TypedefOutput_Args \
        uint32_t wordsCount, \
        unsigned int * words

#define IIGVerifyCaseBounds_StringPointer_Args \
        const char * name

#define IIGVerifyCaseBounds_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseBounds * self, const IORPC rpc);\
\
    kern_return_t\
    MacroInput(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    EnumInput(\
        const unsigned char * bytes,\
        uint32_t bytesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TypedefOutput(\
        uint32_t wordsCount,\
        unsigned int * words,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    StringPointer(\
        const char * name,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    MacroInput_Impl(IIGVerifyCaseBounds_MacroInput_Args);\
\
    kern_return_t\
    EnumInput_Impl(IIGVerifyCaseBounds_EnumInput_Args);\
\
    kern_return_t\
    TypedefOutput_Impl(IIGVerifyCaseBounds_TypedefOutput_Args);\
\
    kern_return_t\
    StringPointer_Impl(IIGVerifyCaseBounds_StringPointer_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*MacroInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseBounds_MacroInput_Args);\
    static kern_return_t\
    MacroInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        MacroInput_Handler func);\
\
    typedef kern_return_t (*EnumInput_Handler)(OSMetaClassBase * target, IIGVerifyCaseBounds_EnumInput_Args);\
    static kern_return_t\
    EnumInput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        EnumInput_Handler func);\
\
    typedef kern_return_t (*TypedefOutput_Handler)(OSMetaClassBase * target, IIGVerifyCaseBounds_TypedefOutput_Args);\
    static kern_return_t\
    TypedefOutput_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TypedefOutput_Handler func);\
\
    typedef kern_return_t (*StringPointer_Handler)(OSMetaClassBase * target, IIGVerifyCaseBounds_StringPointer_Args);\
    static kern_return_t\
    StringPointer_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        StringPointer_Handler func);\
\


#define IIGVerifyCaseBounds_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseBounds_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseBoundsMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseBounds_Class;

class IIGVerifyCaseBoundsMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseBoundsInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseBounds_IVars;
struct IIGVerifyCaseBounds_LocalIVars;

class IIGVerifyCaseBounds : public OSObject, public IIGVerifyCaseBoundsInterface
{
#if !KERNEL
    friend class IIGVerifyCaseBoundsMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseBounds_DECLARE_IVARS
IIGVerifyCaseBounds_DECLARE_IVARS
#else /* IIGVerifyCaseBounds_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseBounds_IVars * ivars;
        IIGVerifyCaseBounds_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseBounds_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseBoundsMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseBounds_Methods
    IIGVerifyCaseBounds_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseBounds.iig:31- */

#endif /* _DRIVERKIT_IIGVerifyCASEBOUNDS_H */
