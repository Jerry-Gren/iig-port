/* iig(DriverKit-440) generated from IIGVerifyCaseConstValuePointers.iig */

/* IIGVerifyCaseConstValuePointers.iig:1-11 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASECONSTVALUEPOINTERS_H
#define _DRIVERKIT_IIGVerifyCASECONSTVALUEPOINTERS_H

struct IIGVerifyCaseConstValueStruct
{
	uint32_t word;
	uint64_t wide;
};

/* source class IIGVerifyCaseConstValuePointers IIGVerifyCaseConstValuePointers.iig:12-28 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseConstValuePointers : public OSObject
{
public:
	virtual kern_return_t
	ConstByte(const uint8_t * value) LOCAL;

	virtual kern_return_t
	ConstBool(const bool * flag) LOCAL;

	virtual kern_return_t
	ConstStruct(const IIGVerifyCaseConstValueStruct * value) LOCAL;

	virtual kern_return_t
	ConstObject(const OSObject * object) LOCAL;

	virtual kern_return_t
	TopLevelConstObject(OSObject * const object) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseConstValuePointers IIGVerifyCaseConstValuePointers.iig:12-28 */

#define IIGVerifyCaseConstValuePointers_ConstByte_ID            0xefbe196c0048a6a4ULL
#define IIGVerifyCaseConstValuePointers_ConstBool_ID            0xa8347cc381a6dd24ULL
#define IIGVerifyCaseConstValuePointers_ConstStruct_ID            0xca7fde085d74e441ULL
#define IIGVerifyCaseConstValuePointers_ConstObject_ID            0x86d87652d03809ccULL
#define IIGVerifyCaseConstValuePointers_TopLevelConstObject_ID            0xa139b8de2cca9999ULL

#define IIGVerifyCaseConstValuePointers_ConstByte_Args \
        const uint8_t * value

#define IIGVerifyCaseConstValuePointers_ConstBool_Args \
        const bool * flag

#define IIGVerifyCaseConstValuePointers_ConstStruct_Args \
        const IIGVerifyCaseConstValueStruct * value

#define IIGVerifyCaseConstValuePointers_ConstObject_Args \
        const OSObject * object

#define IIGVerifyCaseConstValuePointers_TopLevelConstObject_Args \
        OSObject *const object

#define IIGVerifyCaseConstValuePointers_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseConstValuePointers * self, const IORPC rpc);\
\
    kern_return_t\
    ConstByte(\
        const uint8_t * value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ConstBool(\
        const bool * flag,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ConstStruct(\
        const IIGVerifyCaseConstValueStruct * value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ConstObject(\
        const OSObject * object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TopLevelConstObject(\
        OSObject *const object,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    ConstByte_Impl(IIGVerifyCaseConstValuePointers_ConstByte_Args);\
\
    kern_return_t\
    ConstBool_Impl(IIGVerifyCaseConstValuePointers_ConstBool_Args);\
\
    kern_return_t\
    ConstStruct_Impl(IIGVerifyCaseConstValuePointers_ConstStruct_Args);\
\
    kern_return_t\
    ConstObject_Impl(IIGVerifyCaseConstValuePointers_ConstObject_Args);\
\
    kern_return_t\
    TopLevelConstObject_Impl(IIGVerifyCaseConstValuePointers_TopLevelConstObject_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*ConstByte_Handler)(OSMetaClassBase * target, IIGVerifyCaseConstValuePointers_ConstByte_Args);\
    static kern_return_t\
    ConstByte_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstByte_Handler func);\
\
    typedef kern_return_t (*ConstBool_Handler)(OSMetaClassBase * target, IIGVerifyCaseConstValuePointers_ConstBool_Args);\
    static kern_return_t\
    ConstBool_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstBool_Handler func);\
\
    typedef kern_return_t (*ConstStruct_Handler)(OSMetaClassBase * target, IIGVerifyCaseConstValuePointers_ConstStruct_Args);\
    static kern_return_t\
    ConstStruct_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstStruct_Handler func);\
\
    typedef kern_return_t (*ConstObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseConstValuePointers_ConstObject_Args);\
    static kern_return_t\
    ConstObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ConstObject_Handler func);\
\
    typedef kern_return_t (*TopLevelConstObject_Handler)(OSMetaClassBase * target, IIGVerifyCaseConstValuePointers_TopLevelConstObject_Args);\
    static kern_return_t\
    TopLevelConstObject_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TopLevelConstObject_Handler func);\
\


#define IIGVerifyCaseConstValuePointers_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseConstValuePointers_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseConstValuePointersMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseConstValuePointers_Class;

class IIGVerifyCaseConstValuePointersMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseConstValuePointersInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseConstValuePointers_IVars;
struct IIGVerifyCaseConstValuePointers_LocalIVars;

class IIGVerifyCaseConstValuePointers : public OSObject, public IIGVerifyCaseConstValuePointersInterface
{
#if !KERNEL
    friend class IIGVerifyCaseConstValuePointersMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseConstValuePointers_DECLARE_IVARS
IIGVerifyCaseConstValuePointers_DECLARE_IVARS
#else /* IIGVerifyCaseConstValuePointers_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseConstValuePointers_IVars * ivars;
        IIGVerifyCaseConstValuePointers_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseConstValuePointers_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseConstValuePointersMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseConstValuePointers_Methods
    IIGVerifyCaseConstValuePointers_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseConstValuePointers.iig:30- */

#endif /* _DRIVERKIT_IIGVerifyCASECONSTVALUEPOINTERS_H */
