/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseKernelLocalOnlyMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseKernelLocalOnlyMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseKernelLocalOnlyMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseKernelLocalOnlyMore_QueueNames  ""

#define IIGVerifyCaseKernelLocalOnlyMore_MethodNames  ""

#define IIGVerifyCaseKernelLocalOnlyMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseKernelLocalOnlyMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseKernelLocalOnlyMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseKernelLocalOnlyMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t
OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t),
        .name                    = "IIGVerifyCaseKernelLocalOnlyMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseKernelLocalOnlyMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseKernelLocalOnlyMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseKernelLocalOnlyMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseKernelLocalOnlyMore_QueueNames,
    .methodNames     = IIGVerifyCaseKernelLocalOnlyMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseKernelLocalOnlyMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseKernelLocalOnlyMoreMetaClass;

static kern_return_t
IIGVerifyCaseKernelLocalOnlyMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseKernelLocalOnlyMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseKernelLocalOnlyMore.base,
    .metaPointer       = &gIIGVerifyCaseKernelLocalOnlyMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseKernelLocalOnlyMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseKernelLocalOnlyMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseKernelLocalOnlyMore_Declaration;
const void * const
gIIGVerifyCaseKernelLocalOnlyMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseKernelLocalOnlyMore_Class;

static kern_return_t
IIGVerifyCaseKernelLocalOnlyMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseKernelLocalOnlyMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseKernelLocalOnlyMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseKernelLocalOnlyMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseKernelLocalOnlyMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseKernelLocalOnlyMore::_Dispatch(IIGVerifyCaseKernelLocalOnlyMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseKernelLocalOnlyMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseKernelLocalOnlyMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



