/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseStructs.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseStructs.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseStructs.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseStructs_StructInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyCaseSmallStruct  input;
};
#pragma pack(4)
struct IIGVerifyCaseStructs_StructInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructs_StructInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructs_StructInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructs_StructInput_Msg_ObjRefs (1)

struct IIGVerifyCaseStructs_StructInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStructs_StructInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructs_StructInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructs_StructInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructs_StructInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructs_StructInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructs_StructInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructs_StructInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructs_StructInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructs_StructInput_Invocation;
struct IIGVerifyCaseStructs_StructOutput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseStructs_StructOutput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructs_StructOutput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructs_StructOutput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructs_StructOutput_Msg_ObjRefs (1)

struct IIGVerifyCaseStructs_StructOutput_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyCaseSmallStruct  output;
};
#pragma pack(4)
struct IIGVerifyCaseStructs_StructOutput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructs_StructOutput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructs_StructOutput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructs_StructOutput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructs_StructOutput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructs_StructOutput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructs_StructOutput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructs_StructOutput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructs_StructOutput_Invocation;
struct IIGVerifyCaseStructs_StructRoundTrip_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyCaseSmallStruct  input;
};
#pragma pack(4)
struct IIGVerifyCaseStructs_StructRoundTrip_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStructs_StructRoundTrip_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStructs_StructRoundTrip_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructs_StructRoundTrip_Msg_ObjRefs (1)

struct IIGVerifyCaseStructs_StructRoundTrip_Rpl_Content
{
    IORPCMessage __hdr;
    IIGVerifyCaseSmallStruct  output;
};
#pragma pack(4)
struct IIGVerifyCaseStructs_StructRoundTrip_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStructs_StructRoundTrip_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStructs_StructRoundTrip_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStructs_StructRoundTrip_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStructs_StructRoundTrip_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStructs_StructRoundTrip_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStructs_StructRoundTrip_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStructs_StructRoundTrip_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStructs_StructRoundTrip_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseStructs_QueueNames  ""

#define IIGVerifyCaseStructs_MethodNames  ""

#define IIGVerifyCaseStructsMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseStructs_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseStructs_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseStructs_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseStructsMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseStructs_t
OSClassDescription_IIGVerifyCaseStructs =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseStructs_t),
        .name                    = "IIGVerifyCaseStructs",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructs_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructs_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseStructs_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructs_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseStructs_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructs_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseStructsMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStructs_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseStructs_QueueNames,
    .methodNames     = IIGVerifyCaseStructs_MethodNames,
    .metaMethodNames = IIGVerifyCaseStructsMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseStructsMetaClass;

static kern_return_t
IIGVerifyCaseStructs_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseStructs_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseStructs.base,
    .metaPointer       = &gIIGVerifyCaseStructsMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseStructs),

    .resv2             = {0},

    .New               = &IIGVerifyCaseStructs_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseStructs_Declaration;
const void * const
gIIGVerifyCaseStructs_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseStructs_Class;

static kern_return_t
IIGVerifyCaseStructs_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseStructsMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStructsMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseStructs) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseStructs::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseStructs::_Dispatch(IIGVerifyCaseStructs * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseStructs_StructInput_ID:
        {
            ret = IIGVerifyCaseStructs::StructInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructs::StructInput_Handler, *self, &IIGVerifyCaseStructs::StructInput_Impl));
            break;
        }
        case IIGVerifyCaseStructs_StructOutput_ID:
        {
            ret = IIGVerifyCaseStructs::StructOutput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructs::StructOutput_Handler, *self, &IIGVerifyCaseStructs::StructOutput_Impl));
            break;
        }
        case IIGVerifyCaseStructs_StructRoundTrip_ID:
        {
            ret = IIGVerifyCaseStructs::StructRoundTrip_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStructs::StructRoundTrip_Handler, *self, &IIGVerifyCaseStructs::StructRoundTrip_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseStructs::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseStructsMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseStructs::StructInput(
        const IIGVerifyCaseSmallStruct * input,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructs_StructInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructs_StructInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructs_StructInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructs_StructInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructs_StructInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructs_StructInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.input = *input;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructs_StructInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructs_StructInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructs::StructOutput(
        IIGVerifyCaseSmallStruct * output,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructs_StructOutput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructs_StructOutput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructs_StructOutput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructs_StructOutput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructs_StructOutput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructs_StructOutput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructs_StructOutput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructs_StructOutput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (output) *output = rpl->content.output;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructs::StructRoundTrip(
        const IIGVerifyCaseSmallStruct * input,
        IIGVerifyCaseSmallStruct * output,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStructs_StructRoundTrip_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStructs_StructRoundTrip_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStructs_StructRoundTrip_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStructs_StructRoundTrip_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStructs_StructRoundTrip_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStructs_StructRoundTrip_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.input = *input;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStructs_StructRoundTrip_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStructs_StructRoundTrip_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (output) *output = rpl->content.output;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStructs::StructInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        StructInput_Handler func)
{
    IIGVerifyCaseStructs_StructInput_Invocation rpc = { _rpc };
    IIGVerifyCaseStructs_StructInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructs_StructInput_Msg *         message = rpc.message;
    const IIGVerifyCaseStructs_StructInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructs_StructInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructs_StructInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructs_StructInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(input));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructs_StructInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructs_StructInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructs::StructOutput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        StructOutput_Handler func)
{
    IIGVerifyCaseStructs_StructOutput_Invocation rpc = { _rpc };
    IIGVerifyCaseStructs_StructOutput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructs_StructOutput_Msg *         message = rpc.message;
    const IIGVerifyCaseStructs_StructOutput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructs_StructOutput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructs_StructOutput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructs_StructOutput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.output);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructs_StructOutput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructs_StructOutput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStructs::StructRoundTrip_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        StructRoundTrip_Handler func)
{
    IIGVerifyCaseStructs_StructRoundTrip_Invocation rpc = { _rpc };
    IIGVerifyCaseStructs_StructRoundTrip_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStructs_StructRoundTrip_Msg *         message = rpc.message;
    const IIGVerifyCaseStructs_StructRoundTrip_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStructs_StructRoundTrip_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStructs_StructRoundTrip_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStructs_StructRoundTrip_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(input),
        &reply->content.output);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStructs_StructRoundTrip_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStructs_StructRoundTrip_Rpl_ObjRefs;

    return (ret);
}



