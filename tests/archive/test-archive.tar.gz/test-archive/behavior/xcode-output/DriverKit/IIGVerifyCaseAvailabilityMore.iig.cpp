/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseAvailabilityMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseAvailabilityMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseAvailabilityMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_ObjRefs (1)

struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Invocation;
struct IIGVerifyCaseAvailabilityMore_Newer_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseAvailabilityMore_Newer_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseAvailabilityMore_Newer_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseAvailabilityMore_Newer_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseAvailabilityMore_Newer_Msg_ObjRefs (1)

struct IIGVerifyCaseAvailabilityMore_Newer_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseAvailabilityMore_Newer_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseAvailabilityMore_Newer_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseAvailabilityMore_Newer_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseAvailabilityMore_Newer_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseAvailabilityMore_Newer_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseAvailabilityMore_Newer_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseAvailabilityMore_Newer_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseAvailabilityMore_Newer_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseAvailabilityMore_Newer_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseAvailabilityMore_QueueNames  ""

#define IIGVerifyCaseAvailabilityMore_MethodNames  ""

#define IIGVerifyCaseAvailabilityMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseAvailabilityMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseAvailabilityMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseAvailabilityMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t
OSClassDescription_IIGVerifyCaseAvailabilityMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseAvailabilityMore_t),
        .name                    = "IIGVerifyCaseAvailabilityMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseAvailabilityMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseAvailabilityMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseAvailabilityMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseAvailabilityMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseAvailabilityMore_QueueNames,
    .methodNames     = IIGVerifyCaseAvailabilityMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseAvailabilityMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseAvailabilityMoreMetaClass;

static kern_return_t
IIGVerifyCaseAvailabilityMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseAvailabilityMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseAvailabilityMore.base,
    .metaPointer       = &gIIGVerifyCaseAvailabilityMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseAvailabilityMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseAvailabilityMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseAvailabilityMore_Declaration;
const void * const
gIIGVerifyCaseAvailabilityMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseAvailabilityMore_Class;

static kern_return_t
IIGVerifyCaseAvailabilityMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseAvailabilityMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseAvailabilityMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseAvailabilityMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseAvailabilityMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseAvailabilityMore::_Dispatch(IIGVerifyCaseAvailabilityMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_ID:
        {
            ret = IIGVerifyCaseAvailabilityMore::IntroducedDeprecated_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseAvailabilityMore::IntroducedDeprecated_Handler, *self, &IIGVerifyCaseAvailabilityMore::IntroducedDeprecated_Impl));
            break;
        }
        case IIGVerifyCaseAvailabilityMore_Newer_ID:
        {
            ret = IIGVerifyCaseAvailabilityMore::Newer_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseAvailabilityMore::Newer_Handler, *self, &IIGVerifyCaseAvailabilityMore::Newer_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseAvailabilityMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseAvailabilityMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseAvailabilityMore::IntroducedDeprecated(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseAvailabilityMore::Newer(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseAvailabilityMore_Newer_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseAvailabilityMore_Newer_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseAvailabilityMore_Newer_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseAvailabilityMore_Newer_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseAvailabilityMore_Newer_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseAvailabilityMore_Newer_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseAvailabilityMore_Newer_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseAvailabilityMore_Newer_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseAvailabilityMore::IntroducedDeprecated_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        IntroducedDeprecated_Handler func)
{
    IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Invocation rpc = { _rpc };
    IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg *         message = rpc.message;
    const IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseAvailabilityMore::Newer_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        Newer_Handler func)
{
    IIGVerifyCaseAvailabilityMore_Newer_Invocation rpc = { _rpc };
    IIGVerifyCaseAvailabilityMore_Newer_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseAvailabilityMore_Newer_Msg *         message = rpc.message;
    const IIGVerifyCaseAvailabilityMore_Newer_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseAvailabilityMore_Newer_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseAvailabilityMore_Newer_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseAvailabilityMore_Newer_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseAvailabilityMore_Newer_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseAvailabilityMore_Newer_Rpl_ObjRefs;

    return (ret);
}



