/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseTypedefScalarMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseTypedefScalarMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseTypedefScalarMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_Content
{
    IORPCMessage __hdr;
    unsigned int  word;
    long long  wide;
    unsigned long  size;
    unsigned long  pointer;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefScalarMore_OutputAliases_Invocation;
struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyAliasU32B  word;
    IIGVerifyAliasI64B  wide;
    IIGVerifyAliasSize  size;
    IIGVerifyAliasPointer  pointer;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefScalarMore_InputAliases_Invocation;
struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    unsigned int  word;
    long long  wide;
    unsigned long  size;
    unsigned long  pointer;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_ObjRefs (1)

struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseTypedefScalarMore_QueueNames  ""

#define IIGVerifyCaseTypedefScalarMore_MethodNames  ""

#define IIGVerifyCaseTypedefScalarMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseTypedefScalarMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseTypedefScalarMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseTypedefScalarMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t
OSClassDescription_IIGVerifyCaseTypedefScalarMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseTypedefScalarMore_t),
        .name                    = "IIGVerifyCaseTypedefScalarMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseTypedefScalarMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseTypedefScalarMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseTypedefScalarMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseTypedefScalarMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseTypedefScalarMore_QueueNames,
    .methodNames     = IIGVerifyCaseTypedefScalarMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseTypedefScalarMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseTypedefScalarMoreMetaClass;

static kern_return_t
IIGVerifyCaseTypedefScalarMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseTypedefScalarMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseTypedefScalarMore.base,
    .metaPointer       = &gIIGVerifyCaseTypedefScalarMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseTypedefScalarMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseTypedefScalarMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseTypedefScalarMore_Declaration;
const void * const
gIIGVerifyCaseTypedefScalarMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseTypedefScalarMore_Class;

static kern_return_t
IIGVerifyCaseTypedefScalarMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseTypedefScalarMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseTypedefScalarMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseTypedefScalarMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseTypedefScalarMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::_Dispatch(IIGVerifyCaseTypedefScalarMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseTypedefScalarMore_OutputAliases_ID:
        {
            ret = IIGVerifyCaseTypedefScalarMore::OutputAliases_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefScalarMore::OutputAliases_Handler, *self, &IIGVerifyCaseTypedefScalarMore::OutputAliases_Impl));
            break;
        }
        case IIGVerifyCaseTypedefScalarMore_InputAliases_ID:
        {
            ret = IIGVerifyCaseTypedefScalarMore::InputAliases_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefScalarMore::InputAliases_Handler, *self, &IIGVerifyCaseTypedefScalarMore::InputAliases_Impl));
            break;
        }
        case IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_ID:
        {
            ret = IIGVerifyCaseTypedefScalarMore::ConstPointerAliases_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseTypedefScalarMore::ConstPointerAliases_Handler, *self, &IIGVerifyCaseTypedefScalarMore::ConstPointerAliases_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseTypedefScalarMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseTypedefScalarMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::OutputAliases(
        IIGVerifyAliasU32B * word,
        IIGVerifyAliasI64B * wide,
        IIGVerifyAliasSize * size,
        IIGVerifyAliasPointer * pointer,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefScalarMore_OutputAliases_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefScalarMore_OutputAliases_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (word) *word = rpl->content.word;
        if (wide) *wide = rpl->content.wide;
        if (size) *size = rpl->content.size;
        if (pointer) *pointer = rpl->content.pointer;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::InputAliases(
        IIGVerifyAliasU32B word,
        IIGVerifyAliasI64B wide,
        IIGVerifyAliasSize size,
        IIGVerifyAliasPointer pointer,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefScalarMore_InputAliases_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.word = word;

    msg->content.wide = wide;

    msg->content.size = size;

    msg->content.pointer = pointer;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefScalarMore_InputAliases_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::ConstPointerAliases(
        const IIGVerifyAliasU32B * word,
        const IIGVerifyAliasI64B * wide,
        const IIGVerifyAliasSize * size,
        const IIGVerifyAliasPointer * pointer,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.word = *word;

    msg->content.wide = *wide;

    msg->content.size = *size;

    msg->content.pointer = *pointer;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::OutputAliases_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputAliases_Handler func)
{
    IIGVerifyCaseTypedefScalarMore_OutputAliases_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefScalarMore_OutputAliases_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.word,
        &reply->content.wide,
        &reply->content.size,
        &reply->content.pointer);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefScalarMore_OutputAliases_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefScalarMore_OutputAliases_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::InputAliases_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputAliases_Handler func)
{
    IIGVerifyCaseTypedefScalarMore_InputAliases_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefScalarMore_InputAliases_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefScalarMore_InputAliases_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(word),
        MESSAGE_CONTENT(wide),
        MESSAGE_CONTENT(size),
        MESSAGE_CONTENT(pointer));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefScalarMore_InputAliases_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefScalarMore_InputAliases_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseTypedefScalarMore::ConstPointerAliases_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstPointerAliases_Handler func)
{
    IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Invocation rpc = { _rpc };
    IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg *         message = rpc.message;
    const IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(word),
        &MESSAGE_CONTENT(wide),
        &MESSAGE_CONTENT(size),
        &MESSAGE_CONTENT(pointer));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseTypedefScalarMore_ConstPointerAliases_Rpl_ObjRefs;

    return (ret);
}



