/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseRemoteAndInvokeReply.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseRemoteAndInvokeReply.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseRemoteAndInvokeReply.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_ObjRefs (1)

struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Invocation;
struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint64_t  value;
};
#pragma pack(4)
struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_ObjRefs (1)

struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_Content
{
    IORPCMessage __hdr;
    uint64_t __replyBuffer[8];
};
#pragma pack(4)
struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseRemoteAndInvokeReply_QueueNames  ""

#define IIGVerifyCaseRemoteAndInvokeReply_MethodNames  ""

#define IIGVerifyCaseRemoteAndInvokeReplyMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseRemoteAndInvokeReply_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseRemoteAndInvokeReply_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseRemoteAndInvokeReplyMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t
OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t),
        .name                    = "IIGVerifyCaseRemoteAndInvokeReply",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseRemoteAndInvokeReply_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseRemoteAndInvokeReply_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseRemoteAndInvokeReplyMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseRemoteAndInvokeReply_QueueNames,
    .methodNames     = IIGVerifyCaseRemoteAndInvokeReply_MethodNames,
    .metaMethodNames = IIGVerifyCaseRemoteAndInvokeReplyMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseRemoteAndInvokeReplyMetaClass;

static kern_return_t
IIGVerifyCaseRemoteAndInvokeReply_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseRemoteAndInvokeReply_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseRemoteAndInvokeReply.base,
    .metaPointer       = &gIIGVerifyCaseRemoteAndInvokeReplyMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseRemoteAndInvokeReply),

    .resv2             = {0},

    .New               = &IIGVerifyCaseRemoteAndInvokeReply_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseRemoteAndInvokeReply_Declaration;
const void * const
gIIGVerifyCaseRemoteAndInvokeReply_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseRemoteAndInvokeReply_Class;

static kern_return_t
IIGVerifyCaseRemoteAndInvokeReply_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseRemoteAndInvokeReplyMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseRemoteAndInvokeReplyMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseRemoteAndInvokeReply) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::_Dispatch(IIGVerifyCaseRemoteAndInvokeReply * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_ID:
        {
            ret = IIGVerifyCaseRemoteAndInvokeReply::RemoteOnly_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRemoteAndInvokeReply::RemoteOnly_Handler, *self, &IIGVerifyCaseRemoteAndInvokeReply::RemoteOnly_Impl));
            break;
        }
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_ID:
        {
            ret = IIGVerifyCaseRemoteAndInvokeReply::InvokeReply_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRemoteAndInvokeReply::InvokeReply_Handler, *self, &IIGVerifyCaseRemoteAndInvokeReply::InvokeReply_Impl));
            break;
        }
#endif /* !KERNEL */

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseRemoteAndInvokeReplyMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::RemoteOnly(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::InvokeReply(
        uint64_t value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        if (rpl->mach.msgh.msgh_size < (sizeof(IORPCMessageMach) + sizeof(IORPCMessage))) { ret = kIOReturnIPCError; break; };
        if (rpl->mach.msgh_body.msgh_descriptor_count >= 1)
        {
            if (rpl->mach.msgh.msgh_size < (sizeof(IORPCMessageMach) + sizeof(mach_msg_port_descriptor_t) + sizeof(IORPCMessage))) { ret = kIOReturnIPCError; break; };
        }
        else
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (ret == kIOReturnSuccess) {
            IORPCMessage * message;
            OSObject     * object;

#ifdef KERNEL
            message = rpc.kernelContent;
#else /* KERNEL */
            message = IORPCMessageFromMach(rpc.reply, false);
#endif /* KERNEL */
            if ((rpc.reply->msgh_body.msgh_descriptor_count < 1) || !(kIORPCMessageOneway & message->flags)) {
               ret = kIOReturnIPCError;
            } else {
              object  = (typeof(object)) message->objects[0];
              if (!object) ret = kIOReturnIPCError;
              else
              {
                  rpc.sendSize  = rpc.replySize;
                  rpc.replySize = 0;
                  rpc.reply     = NULL;

                  ret = object->Invoke(rpc);
              }
          }
        }
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::RemoteOnly_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        RemoteOnly_Handler func)
{
    IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Invocation rpc = { _rpc };
    IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg *         message = rpc.message;
    const IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRemoteAndInvokeReply_RemoteOnly_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseRemoteAndInvokeReply::InvokeReply_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InvokeReply_Handler func)
{
    IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Invocation rpc = { _rpc };
    IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg *         message = rpc.message;
    const IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRemoteAndInvokeReply_InvokeReply_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        rpc.rpc,
        MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    IORPCMessage * replyMessage;

#ifdef KERNEL
    replyMessage = rpc.rpc.kernelContent;
#else /* KERNEL */
    replyMessage = IORPCMessageFromMach(rpc.rpc.reply, false);
#endif /* KERNEL */
    if ((rpc.rpc.reply->msgh_body.msgh_descriptor_count < 1)  || !(kIORPCMessageOneway & replyMessage->flags)) ret = kIOReturnIPCError;

    return (ret);
}



