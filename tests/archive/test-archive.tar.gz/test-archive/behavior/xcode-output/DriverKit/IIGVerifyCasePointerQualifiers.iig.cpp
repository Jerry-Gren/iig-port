/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCasePointerQualifiers.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCasePointerQualifiers.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCasePointerQualifiers.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObject  object;
};
#pragma pack(4)
struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_ObjRefs (1)

struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePointerQualifiers_ConstObjectInput_Invocation;
struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_ObjRefs (2)

struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePointerQualifiers_ObjectPointerConst_Invocation;
struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    unsigned long long  value;
};
#pragma pack(4)
struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_ObjRefs (1)

struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePointerQualifiers_ConstScalarInput_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCasePointerQualifiers_QueueNames  ""

#define IIGVerifyCasePointerQualifiers_MethodNames  ""

#define IIGVerifyCasePointerQualifiersMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCasePointerQualifiers_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCasePointerQualifiers_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCasePointerQualifiers_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCasePointerQualifiersMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCasePointerQualifiers_t
OSClassDescription_IIGVerifyCasePointerQualifiers =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCasePointerQualifiers_t),
        .name                    = "IIGVerifyCasePointerQualifiers",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePointerQualifiers_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePointerQualifiers_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCasePointerQualifiers_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePointerQualifiers_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCasePointerQualifiers_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePointerQualifiers_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCasePointerQualifiersMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePointerQualifiers_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCasePointerQualifiers_QueueNames,
    .methodNames     = IIGVerifyCasePointerQualifiers_MethodNames,
    .metaMethodNames = IIGVerifyCasePointerQualifiersMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCasePointerQualifiersMetaClass;

static kern_return_t
IIGVerifyCasePointerQualifiers_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCasePointerQualifiers_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCasePointerQualifiers.base,
    .metaPointer       = &gIIGVerifyCasePointerQualifiersMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCasePointerQualifiers),

    .resv2             = {0},

    .New               = &IIGVerifyCasePointerQualifiers_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCasePointerQualifiers_Declaration;
const void * const
gIIGVerifyCasePointerQualifiers_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCasePointerQualifiers_Class;

static kern_return_t
IIGVerifyCasePointerQualifiers_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCasePointerQualifiersMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCasePointerQualifiersMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCasePointerQualifiers) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCasePointerQualifiers::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCasePointerQualifiers::_Dispatch(IIGVerifyCasePointerQualifiers * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCasePointerQualifiers_ConstObjectInput_ID:
        {
            ret = IIGVerifyCasePointerQualifiers::ConstObjectInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePointerQualifiers::ConstObjectInput_Handler, *self, &IIGVerifyCasePointerQualifiers::ConstObjectInput_Impl));
            break;
        }
        case IIGVerifyCasePointerQualifiers_ObjectPointerConst_ID:
        {
            ret = IIGVerifyCasePointerQualifiers::ObjectPointerConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePointerQualifiers::ObjectPointerConst_Handler, *self, &IIGVerifyCasePointerQualifiers::ObjectPointerConst_Impl));
            break;
        }
        case IIGVerifyCasePointerQualifiers_ConstScalarInput_ID:
        {
            ret = IIGVerifyCasePointerQualifiers::ConstScalarInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePointerQualifiers::ConstScalarInput_Handler, *self, &IIGVerifyCasePointerQualifiers::ConstScalarInput_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCasePointerQualifiers::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCasePointerQualifiersMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCasePointerQualifiers::ConstObjectInput(
        const OSObject * object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePointerQualifiers_ConstObjectInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.object = *object;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePointerQualifiers_ConstObjectInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePointerQualifiers::ObjectPointerConst(
        OSObject *const object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePointerQualifiers_ObjectPointerConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.object = (OSObjectRef) object;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePointerQualifiers_ObjectPointerConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePointerQualifiers::ConstScalarInput(
        const uint64_t * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePointerQualifiers_ConstScalarInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePointerQualifiers_ConstScalarInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePointerQualifiers::ConstObjectInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstObjectInput_Handler func)
{
    IIGVerifyCasePointerQualifiers_ConstObjectInput_Invocation rpc = { _rpc };
    IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg *         message = rpc.message;
    const IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePointerQualifiers_ConstObjectInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(object));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePointerQualifiers_ConstObjectInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePointerQualifiers_ConstObjectInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCasePointerQualifiers::ObjectPointerConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ObjectPointerConst_Handler func)
{
    IIGVerifyCasePointerQualifiers_ObjectPointerConst_Invocation rpc = { _rpc };
    IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg *         message = rpc.message;
    const IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSObject * object;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePointerQualifiers_ObjectPointerConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    object = OSDynamicCast(OSObject, (OSObject *) MESSAGE_CONTENT(object));
    if (!object && MESSAGE_CONTENT(object)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePointerQualifiers_ObjectPointerConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePointerQualifiers_ObjectPointerConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCasePointerQualifiers::ConstScalarInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstScalarInput_Handler func)
{
    IIGVerifyCasePointerQualifiers_ConstScalarInput_Invocation rpc = { _rpc };
    IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg *         message = rpc.message;
    const IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePointerQualifiers_ConstScalarInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePointerQualifiers_ConstScalarInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePointerQualifiers_ConstScalarInput_Rpl_ObjRefs;

    return (ret);
}



