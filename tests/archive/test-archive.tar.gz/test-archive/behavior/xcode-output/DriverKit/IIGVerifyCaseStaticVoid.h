/* iig(DriverKit-440) generated from IIGVerifyCaseStaticVoid.iig */

/* IIGVerifyCaseStaticVoid.iig:1-7 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESTATICVOID_H
#define _DRIVERKIT_IIGVerifyCASESTATICVOID_H

#define kIIGVerifyCaseStaticQueue "IIGVerifyCaseStaticQueue"

/* source class IIGVerifyCaseStaticVoid IIGVerifyCaseStaticVoid.iig:8-21 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseStaticVoid : public OSObject
{
public:
	static void
	StaticVoid(uint64_t value) LOCAL;

	static kern_return_t
	StaticHost(uint64_t value) LOCALHOST;

	static kern_return_t
	StaticQueued(uint64_t value) LOCAL QUEUENAME(kIIGVerifyCaseStaticQueue);

	virtual void
	InstanceVoid(uint64_t value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseStaticVoid IIGVerifyCaseStaticVoid.iig:8-21 */

#define IIGVerifyCaseStaticVoid_StaticVoid_ID            0xde8f9b5de5bc3f43ULL
#define IIGVerifyCaseStaticVoid_StaticHost_ID            0x971ccc84b0ba5de9ULL
#define IIGVerifyCaseStaticVoid_StaticQueued_ID            0xbba76516c7c047ccULL
#define IIGVerifyCaseStaticVoid_InstanceVoid_ID            0xcfcb109f404b220fULL

#define IIGVerifyCaseStaticVoid_StaticVoid_Args \
        uint64_t value

#define IIGVerifyCaseStaticVoid_StaticHost_Args \
        uint64_t value

#define IIGVerifyCaseStaticVoid_StaticQueued_Args \
        uint64_t value

#define IIGVerifyCaseStaticVoid_InstanceVoid_Args \
        uint64_t value

#define IIGVerifyCaseStaticVoid_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseStaticVoid * self, const IORPC rpc);\
\
    static void\
    StaticVoid(\
        uint64_t value);\
\
    static kern_return_t\
    StaticHost(\
        uint64_t value);\
\
    static kern_return_t\
    StaticQueued(\
        uint64_t value);\
\
    void\
    InstanceVoid(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    static void\
    StaticVoid_Call(IIGVerifyCaseStaticVoid_StaticVoid_Args);\
\
    static kern_return_t\
    StaticHost_Call(IIGVerifyCaseStaticVoid_StaticHost_Args);\
\
    static kern_return_t\
    StaticQueued_Call(IIGVerifyCaseStaticVoid_StaticQueued_Args);\
\
    void\
    InstanceVoid_Impl(IIGVerifyCaseStaticVoid_InstanceVoid_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef void (*StaticVoid_Handler)(IIGVerifyCaseStaticVoid_StaticVoid_Args);\
    static kern_return_t\
    StaticVoid_Invoke(const IORPC rpc,\
        StaticVoid_Handler func);\
\
    typedef kern_return_t (*StaticHost_Handler)(IIGVerifyCaseStaticVoid_StaticHost_Args);\
    static kern_return_t\
    StaticHost_Invoke(const IORPC rpc,\
        StaticHost_Handler func);\
\
    typedef kern_return_t (*StaticQueued_Handler)(IIGVerifyCaseStaticVoid_StaticQueued_Args);\
    static kern_return_t\
    StaticQueued_Invoke(const IORPC rpc,\
        StaticQueued_Handler func);\
\
    typedef void (*InstanceVoid_Handler)(OSMetaClassBase * target, IIGVerifyCaseStaticVoid_InstanceVoid_Args);\
    static kern_return_t\
    InstanceVoid_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceVoid_Handler func);\
\


#define IIGVerifyCaseStaticVoid_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    static void\
    StaticVoid_Impl(IIGVerifyCaseStaticVoid_StaticVoid_Args);\
\
    static kern_return_t\
    StaticHost_Impl(IIGVerifyCaseStaticVoid_StaticHost_Args);\
\
    static kern_return_t\
    StaticQueued_Impl(IIGVerifyCaseStaticVoid_StaticQueued_Args);\
\


#define IIGVerifyCaseStaticVoid_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseStaticVoidMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseStaticVoid_Class;

class IIGVerifyCaseStaticVoidMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseStaticVoidInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseStaticVoid_IVars;
struct IIGVerifyCaseStaticVoid_LocalIVars;

class IIGVerifyCaseStaticVoid : public OSObject, public IIGVerifyCaseStaticVoidInterface
{
#if !KERNEL
    friend class IIGVerifyCaseStaticVoidMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseStaticVoid_DECLARE_IVARS
IIGVerifyCaseStaticVoid_DECLARE_IVARS
#else /* IIGVerifyCaseStaticVoid_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseStaticVoid_IVars * ivars;
        IIGVerifyCaseStaticVoid_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseStaticVoid_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseStaticVoidMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseStaticVoid_Methods
    IIGVerifyCaseStaticVoid_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseStaticVoid.iig:23- */

#endif /* _DRIVERKIT_IIGVerifyCASESTATICVOID_H */
