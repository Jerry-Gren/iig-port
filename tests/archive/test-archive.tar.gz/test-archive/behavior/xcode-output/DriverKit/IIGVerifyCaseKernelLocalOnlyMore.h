/* iig(DriverKit-440) generated from IIGVerifyCaseKernelLocalOnlyMore.iig */

/* IIGVerifyCaseKernelLocalOnlyMore.iig:1-7 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEKERNELLOCALONLYMORE_H
#define _DRIVERKIT_IIGVerifyCASEKERNELLOCALONLYMORE_H

typedef void (*IIGVerifyCaseKernelLocalOnlyCallback)(void * context);

/* source class IIGVerifyCaseKernelLocalOnlyMore IIGVerifyCaseKernelLocalOnlyMore.iig:8-19 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseKernelLocalOnlyMore : public OSObject
{
public:
	virtual bool
	IsReady(void) const LOCALONLY;

	virtual kern_return_t
	RunCallback(void * context,
	    IIGVerifyCaseKernelLocalOnlyCallback callback) LOCALONLY;

	static uint64_t
	GetStaticValue(void) LOCALONLY;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseKernelLocalOnlyMore IIGVerifyCaseKernelLocalOnlyMore.iig:8-19 */


#define IIGVerifyCaseKernelLocalOnlyMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseKernelLocalOnlyMore * self, const IORPC rpc);\
\
    static uint64_t\
    GetStaticValue(\
);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyCaseKernelLocalOnlyMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseKernelLocalOnlyMore_VirtualMethods \
\
public:\
\
    virtual bool\
    IsReady(\
) const APPLE_KEXT_OVERRIDE;\
\
    virtual kern_return_t\
    RunCallback(\
        void * context,\
        IIGVerifyCaseKernelLocalOnlyCallback callback) APPLE_KEXT_OVERRIDE;\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseKernelLocalOnlyMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseKernelLocalOnlyMore_Class;

class IIGVerifyCaseKernelLocalOnlyMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseKernelLocalOnlyMoreInterface : public OSInterface
{
public:
    virtual bool
    IsReady() const = 0;

    virtual kern_return_t
    RunCallback(void * context,
        IIGVerifyCaseKernelLocalOnlyCallback callback) = 0;

    bool
    IsReady_Call() const  { return IsReady(); };\

    kern_return_t
    RunCallback_Call(void * context,
        IIGVerifyCaseKernelLocalOnlyCallback callback)  { return RunCallback(context, callback); };\

};

struct IIGVerifyCaseKernelLocalOnlyMore_IVars;
struct IIGVerifyCaseKernelLocalOnlyMore_LocalIVars;

class IIGVerifyCaseKernelLocalOnlyMore : public OSObject, public IIGVerifyCaseKernelLocalOnlyMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseKernelLocalOnlyMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseKernelLocalOnlyMore_DECLARE_IVARS
IIGVerifyCaseKernelLocalOnlyMore_DECLARE_IVARS
#else /* IIGVerifyCaseKernelLocalOnlyMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseKernelLocalOnlyMore_IVars * ivars;
        IIGVerifyCaseKernelLocalOnlyMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseKernelLocalOnlyMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseKernelLocalOnlyMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseKernelLocalOnlyMore_Methods
    IIGVerifyCaseKernelLocalOnlyMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseKernelLocalOnlyMore.iig:21- */

#endif /* _DRIVERKIT_IIGVerifyCASEKERNELLOCALONLYMORE_H */
