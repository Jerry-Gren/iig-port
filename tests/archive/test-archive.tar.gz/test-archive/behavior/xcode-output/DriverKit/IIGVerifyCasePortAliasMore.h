/* iig(DriverKit-440) generated from IIGVerifyCasePortAliasMore.iig */

/* IIGVerifyCasePortAliasMore.iig:1-7 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEPORTALIASMORE_H
#define _DRIVERKIT_IIGVerifyCASEPORTALIASMORE_H

typedef mach_port_t IIGVerifyAliasPort;

/* source class IIGVerifyCasePortAliasMore IIGVerifyCasePortAliasMore.iig:8-15 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCasePortAliasMore : public OSObject
{
public:
	virtual kern_return_t
	SendPlain(mach_port_t port IIG_PORTCOPYSEND) LOCAL;

	virtual kern_return_t
	SendAlias(IIGVerifyAliasPort port IIG_PORTCOPYSEND) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCasePortAliasMore IIGVerifyCasePortAliasMore.iig:8-15 */

#define IIGVerifyCasePortAliasMore_SendPlain_ID            0xd0683e1465467b78ULL
#define IIGVerifyCasePortAliasMore_SendAlias_ID            0x980d1b91d440b59eULL

#define IIGVerifyCasePortAliasMore_SendPlain_Args \
        mach_port_t port

#define IIGVerifyCasePortAliasMore_SendAlias_Args \
        IIGVerifyAliasPort port

#define IIGVerifyCasePortAliasMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCasePortAliasMore * self, const IORPC rpc);\
\
    kern_return_t\
    SendPlain(\
        mach_port_t port,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SendAlias(\
        IIGVerifyAliasPort port,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    SendPlain_Impl(IIGVerifyCasePortAliasMore_SendPlain_Args);\
\
    kern_return_t\
    SendAlias_Impl(IIGVerifyCasePortAliasMore_SendAlias_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*SendPlain_Handler)(OSMetaClassBase * target, IIGVerifyCasePortAliasMore_SendPlain_Args);\
    static kern_return_t\
    SendPlain_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SendPlain_Handler func);\
\
    typedef kern_return_t (*SendAlias_Handler)(OSMetaClassBase * target, IIGVerifyCasePortAliasMore_SendAlias_Args);\
    static kern_return_t\
    SendAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SendAlias_Handler func);\
\


#define IIGVerifyCasePortAliasMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCasePortAliasMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCasePortAliasMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCasePortAliasMore_Class;

class IIGVerifyCasePortAliasMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCasePortAliasMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCasePortAliasMore_IVars;
struct IIGVerifyCasePortAliasMore_LocalIVars;

class IIGVerifyCasePortAliasMore : public OSObject, public IIGVerifyCasePortAliasMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCasePortAliasMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCasePortAliasMore_DECLARE_IVARS
IIGVerifyCasePortAliasMore_DECLARE_IVARS
#else /* IIGVerifyCasePortAliasMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCasePortAliasMore_IVars * ivars;
        IIGVerifyCasePortAliasMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCasePortAliasMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCasePortAliasMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCasePortAliasMore_Methods
    IIGVerifyCasePortAliasMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCasePortAliasMore.iig:17- */

#endif /* _DRIVERKIT_IIGVerifyCASEPORTALIASMORE_H */
