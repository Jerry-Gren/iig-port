/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseParameters.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseParameters.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseParameters.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseParameters_InlineInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[16];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_InlineInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseParameters_InlineInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseParameters_InlineInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_InlineInput_Msg_ObjRefs (1)

struct IIGVerifyCaseParameters_InlineInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_InlineInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseParameters_InlineInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseParameters_InlineInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_InlineInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_InlineInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseParameters_InlineInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseParameters_InlineInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_InlineInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseParameters_InlineInput_Invocation;
struct IIGVerifyCaseParameters_InlineOutput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  valuesCount;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_InlineOutput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseParameters_InlineOutput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseParameters_InlineOutput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_InlineOutput_Msg_ObjRefs (1)

struct IIGVerifyCaseParameters_InlineOutput_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  valuesCount;
    unsigned long long *  values;
#if !defined(__LP64__)
    uint32_t __valuesPad;
#endif /* !defined(__LP64__) */
    unsigned long long __values[4];
};
#pragma pack(4)
struct IIGVerifyCaseParameters_InlineOutput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseParameters_InlineOutput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseParameters_InlineOutput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_InlineOutput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_InlineOutput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseParameters_InlineOutput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseParameters_InlineOutput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_InlineOutput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseParameters_InlineOutput_Invocation;
struct IIGVerifyCaseParameters_ObjectRefs_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  input;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_ObjectRefs_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t input__descriptor;
};
struct IIGVerifyCaseParameters_ObjectRefs_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t input__descriptor;
    IIGVerifyCaseParameters_ObjectRefs_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_ObjectRefs_Msg_ObjRefs (2)

struct IIGVerifyCaseParameters_ObjectRefs_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  output;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_ObjectRefs_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t output__descriptor;
};
struct IIGVerifyCaseParameters_ObjectRefs_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t output__descriptor;
    IIGVerifyCaseParameters_ObjectRefs_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_ObjectRefs_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_ObjectRefs_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseParameters_ObjectRefs_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseParameters_ObjectRefs_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_ObjectRefs_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseParameters_ObjectRefs_Invocation;
struct IIGVerifyCaseParameters_BufferObjects_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  input;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_BufferObjects_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t input__descriptor;
};
struct IIGVerifyCaseParameters_BufferObjects_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t input__descriptor;
    IIGVerifyCaseParameters_BufferObjects_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_BufferObjects_Msg_ObjRefs (2)

struct IIGVerifyCaseParameters_BufferObjects_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  output;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_BufferObjects_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t output__descriptor;
};
struct IIGVerifyCaseParameters_BufferObjects_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t output__descriptor;
    IIGVerifyCaseParameters_BufferObjects_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_BufferObjects_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_BufferObjects_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseParameters_BufferObjects_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseParameters_BufferObjects_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_BufferObjects_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseParameters_BufferObjects_Invocation;
struct IIGVerifyCaseParameters_SerializableObjects_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSDictionary * input;
#if !defined(__LP64__)
    uint32_t __inputPad;
#endif /* !defined(__LP64__) */
};
#pragma pack(4)
struct IIGVerifyCaseParameters_SerializableObjects_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  input__descriptor;
};
struct IIGVerifyCaseParameters_SerializableObjects_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  input__descriptor;
    IIGVerifyCaseParameters_SerializableObjects_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_SerializableObjects_Msg_ObjRefs (2)

struct IIGVerifyCaseParameters_SerializableObjects_Rpl_Content
{
    IORPCMessage __hdr;
    OSData * output;
#if !defined(__LP64__)
    uint32_t __outputPad;
#endif /* !defined(__LP64__) */
};
#pragma pack(4)
struct IIGVerifyCaseParameters_SerializableObjects_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_ool_descriptor_t  output__descriptor;
};
struct IIGVerifyCaseParameters_SerializableObjects_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_ool_descriptor_t  output__descriptor;
    IIGVerifyCaseParameters_SerializableObjects_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_SerializableObjects_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_SerializableObjects_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseParameters_SerializableObjects_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseParameters_SerializableObjects_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_SerializableObjects_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseParameters_SerializableObjects_Invocation;
struct IIGVerifyCaseParameters_PortDispositions_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_PortDispositions_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t made__descriptor;
    mach_msg_port_descriptor_t copied__descriptor;
};
struct IIGVerifyCaseParameters_PortDispositions_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t made__descriptor;
    mach_msg_port_descriptor_t copied__descriptor;
    IIGVerifyCaseParameters_PortDispositions_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_PortDispositions_Msg_ObjRefs (1)

struct IIGVerifyCaseParameters_PortDispositions_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseParameters_PortDispositions_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseParameters_PortDispositions_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseParameters_PortDispositions_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseParameters_PortDispositions_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_PortDispositions_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseParameters_PortDispositions_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseParameters_PortDispositions_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseParameters_PortDispositions_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseParameters_PortDispositions_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gIOServiceMetaClass;
extern OSMetaClass * gIOMemoryMapMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseParameters_QueueNames  ""

#define IIGVerifyCaseParameters_MethodNames  ""

#define IIGVerifyCaseParametersMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseParameters_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseParameters_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseParameters_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseParametersMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseParameters_t
OSClassDescription_IIGVerifyCaseParameters =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseParameters_t),
        .name                    = "IIGVerifyCaseParameters",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseParameters_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseParameters_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseParameters_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseParameters_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseParameters_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseParameters_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseParametersMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseParameters_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseParameters_QueueNames,
    .methodNames     = IIGVerifyCaseParameters_MethodNames,
    .metaMethodNames = IIGVerifyCaseParametersMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseParametersMetaClass;

static kern_return_t
IIGVerifyCaseParameters_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseParameters_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseParameters.base,
    .metaPointer       = &gIIGVerifyCaseParametersMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseParameters),

    .resv2             = {0},

    .New               = &IIGVerifyCaseParameters_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseParameters_Declaration;
const void * const
gIIGVerifyCaseParameters_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseParameters_Class;

static kern_return_t
IIGVerifyCaseParameters_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseParametersMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseParametersMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseParameters) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseParameters::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseParameters::_Dispatch(IIGVerifyCaseParameters * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseParameters_InlineInput_ID:
        {
            ret = IIGVerifyCaseParameters::InlineInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseParameters::InlineInput_Handler, *self, &IIGVerifyCaseParameters::InlineInput_Impl));
            break;
        }
        case IIGVerifyCaseParameters_InlineOutput_ID:
        {
            ret = IIGVerifyCaseParameters::InlineOutput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseParameters::InlineOutput_Handler, *self, &IIGVerifyCaseParameters::InlineOutput_Impl));
            break;
        }
        case IIGVerifyCaseParameters_ObjectRefs_ID:
        {
            ret = IIGVerifyCaseParameters::ObjectRefs_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseParameters::ObjectRefs_Handler, *self, &IIGVerifyCaseParameters::ObjectRefs_Impl));
            break;
        }
        case IIGVerifyCaseParameters_BufferObjects_ID:
        {
            ret = IIGVerifyCaseParameters::BufferObjects_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseParameters::BufferObjects_Handler, *self, &IIGVerifyCaseParameters::BufferObjects_Impl));
            break;
        }
        case IIGVerifyCaseParameters_SerializableObjects_ID:
        {
            ret = IIGVerifyCaseParameters::SerializableObjects_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseParameters::SerializableObjects_Handler, *self, &IIGVerifyCaseParameters::SerializableObjects_Impl));
            break;
        }
        case IIGVerifyCaseParameters_PortDispositions_ID:
        {
            ret = IIGVerifyCaseParameters::PortDispositions_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseParameters::PortDispositions_Handler, *self, &IIGVerifyCaseParameters::PortDispositions_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseParameters::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseParametersMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::InlineInput(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseParameters_InlineInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseParameters_InlineInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseParameters_InlineInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseParameters_InlineInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseParameters_InlineInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseParameters_InlineInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseParameters_InlineInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseParameters_InlineInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::InlineOutput(
        uint32_t valuesCount,
        unsigned long long * values,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseParameters_InlineOutput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseParameters_InlineOutput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseParameters_InlineOutput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseParameters_InlineOutput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseParameters_InlineOutput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseParameters_InlineOutput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.valuesCount = valuesCount;

    if (*valuesCount > (sizeof(rpl->content.__values) / sizeof(rpl->content.__values[0]))) return kIOReturnOverrun;
    msg->content.valuesCount = *valuesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseParameters_InlineOutput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseParameters_InlineOutput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.valuesCount < *valuesCount) *valuesCount = rpl->content.valuesCount;
        bcopy(&rpl->content.__values[0], values, *valuesCount * sizeof(rpl->content.__values[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::ObjectRefs(
        OSObject * input,
        OSObject ** output,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseParameters_ObjectRefs_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseParameters_ObjectRefs_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseParameters_ObjectRefs_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseParameters_ObjectRefs_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseParameters_ObjectRefs_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseParameters_ObjectRefs_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->input__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.input = (OSObjectRef) input;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseParameters_ObjectRefs_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseParameters_ObjectRefs_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *output = OSDynamicCast(OSObject, (OSObject *) rpl->content.output);
        if (rpl->content.output && !*output) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::BufferObjects(
        IOBufferMemoryDescriptor * input,
        IOBufferMemoryDescriptor ** output,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseParameters_BufferObjects_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseParameters_BufferObjects_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseParameters_BufferObjects_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseParameters_BufferObjects_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseParameters_BufferObjects_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseParameters_BufferObjects_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->input__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.input = (OSObjectRef) input;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseParameters_BufferObjects_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseParameters_BufferObjects_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *output = OSDynamicCast(IOBufferMemoryDescriptor, (OSObject *) rpl->content.output);
        if (rpl->content.output && !*output) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::SerializableObjects(
        OSDictionary * input,
        OSData ** output,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseParameters_SerializableObjects_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseParameters_SerializableObjects_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseParameters_SerializableObjects_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseParameters_SerializableObjects_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseParameters_SerializableObjects_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseParameters_SerializableObjects_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->input__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->input__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->input__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseParameters_SerializableObjects_Msg_Content, input);
    msg->content.input = input;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseParameters_SerializableObjects_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseParameters_SerializableObjects_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *output = OSDynamicCast(OSData, (OSObject *) rpl->content.output);
        if (rpl->content.output && !*output) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::PortDispositions(
        mach_port_t made,
        mach_port_t copied,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseParameters_PortDispositions_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseParameters_PortDispositions_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseParameters_PortDispositions_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseParameters_PortDispositions_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseParameters_PortDispositions_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseParameters_PortDispositions_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 3;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->made__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->made__descriptor.disposition = MACH_MSG_TYPE_MAKE_SEND;
    msg->made__descriptor.name = made;
    msg->copied__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->copied__descriptor.disposition = MACH_MSG_TYPE_COPY_SEND;
    msg->copied__descriptor.name = copied;
#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseParameters_PortDispositions_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseParameters_PortDispositions_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::InlineInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineInput_Handler func)
{
    IIGVerifyCaseParameters_InlineInput_Invocation rpc = { _rpc };
    IIGVerifyCaseParameters_InlineInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseParameters_InlineInput_Msg *         message = rpc.message;
    const IIGVerifyCaseParameters_InlineInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseParameters_InlineInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseParameters_InlineInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseParameters_InlineInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseParameters_InlineInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseParameters_InlineInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::InlineOutput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineOutput_Handler func)
{
    IIGVerifyCaseParameters_InlineOutput_Invocation rpc = { _rpc };
    IIGVerifyCaseParameters_InlineOutput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseParameters_InlineOutput_Msg *         message = rpc.message;
    const IIGVerifyCaseParameters_InlineOutput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseParameters_InlineOutput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t valuesCount = (sizeof(MESSAGE_CONTENT(__values)) / sizeof(MESSAGE_CONTENT(__values[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(valuesCount) >= 0 && valuesCount > MESSAGE_CONTENT(valuesCount)) valuesCount = MESSAGE_CONTENT(valuesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseParameters_InlineOutput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseParameters_InlineOutput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        valuesCount,
        &reply->content.__values[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseParameters_InlineOutput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseParameters_InlineOutput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::ObjectRefs_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ObjectRefs_Handler func)
{
    IIGVerifyCaseParameters_ObjectRefs_Invocation rpc = { _rpc };
    IIGVerifyCaseParameters_ObjectRefs_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseParameters_ObjectRefs_Msg *         message = rpc.message;
    const IIGVerifyCaseParameters_ObjectRefs_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseParameters_ObjectRefs_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSObject * input;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseParameters_ObjectRefs_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseParameters_ObjectRefs_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    input = OSDynamicCast(OSObject, (OSObject *) MESSAGE_CONTENT(input));
    if (!input && MESSAGE_CONTENT(input)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        input,
        (OSObject **)&reply->content.output);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseParameters_ObjectRefs_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseParameters_ObjectRefs_Rpl_ObjRefs;
    reply->output__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::BufferObjects_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        BufferObjects_Handler func)
{
    IIGVerifyCaseParameters_BufferObjects_Invocation rpc = { _rpc };
    IIGVerifyCaseParameters_BufferObjects_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseParameters_BufferObjects_Msg *         message = rpc.message;
    const IIGVerifyCaseParameters_BufferObjects_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseParameters_BufferObjects_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    IOBufferMemoryDescriptor * input;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseParameters_BufferObjects_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseParameters_BufferObjects_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    input = OSDynamicCast(IOBufferMemoryDescriptor, (OSObject *) MESSAGE_CONTENT(input));
    if (!input && MESSAGE_CONTENT(input)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        input,
        (IOBufferMemoryDescriptor **)&reply->content.output);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseParameters_BufferObjects_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseParameters_BufferObjects_Rpl_ObjRefs;
    reply->output__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::SerializableObjects_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SerializableObjects_Handler func)
{
    IIGVerifyCaseParameters_SerializableObjects_Invocation rpc = { _rpc };
    IIGVerifyCaseParameters_SerializableObjects_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseParameters_SerializableObjects_Msg *         message = rpc.message;
    const IIGVerifyCaseParameters_SerializableObjects_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseParameters_SerializableObjects_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseParameters_SerializableObjects_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseParameters_SerializableObjects_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(input)) != NULL && OSDynamicCast(OSDictionary, (OSObject *) MESSAGE_CONTENT(input)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        MESSAGE_CONTENT(input),
        &reply->content.output);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseParameters_SerializableObjects_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseParameters_SerializableObjects_Rpl_ObjRefs;
    reply->output__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    reply->output__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    reply->output__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseParameters_SerializableObjects_Rpl_Content, output);
    reply->output__descriptor.size = 0;

    return (ret);
}

kern_return_t
IIGVerifyCaseParameters::PortDispositions_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        PortDispositions_Handler func)
{
    IIGVerifyCaseParameters_PortDispositions_Invocation rpc = { _rpc };
    IIGVerifyCaseParameters_PortDispositions_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseParameters_PortDispositions_Msg *         message = rpc.message;
    const IIGVerifyCaseParameters_PortDispositions_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseParameters_PortDispositions_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (3 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseParameters_PortDispositions_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseParameters_PortDispositions_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        message->made__descriptor.name,
        message->copied__descriptor.name);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseParameters_PortDispositions_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseParameters_PortDispositions_Rpl_ObjRefs;

    return (ret);
}



