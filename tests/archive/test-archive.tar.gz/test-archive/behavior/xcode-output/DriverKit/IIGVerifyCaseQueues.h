/* iig(DriverKit-440) generated from IIGVerifyCaseQueues.iig */

/* IIGVerifyCaseQueues.iig:1-8 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEQUEUES_H
#define _DRIVERKIT_IIGVerifyCASEQUEUES_H

#define kIIGVerifyCaseQueueA "IIGVerifyCaseQueueA"
#define kIIGVerifyCaseQueueB "IIGVerifyCaseQueueB"

/* source class IIGVerifyCasePureBase IIGVerifyCaseQueues.iig:9-19 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCasePureBase : public OSObject
{
public:
	virtual kern_return_t
	MustOverride(uint64_t value) = 0;

	virtual kern_return_t
	HostOnly(uint64_t value) LOCALHOST;

	virtual kern_return_t
	ReplyOnly(uint64_t value) REPLY LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCasePureBase IIGVerifyCaseQueues.iig:9-19 */

#define IIGVerifyCasePureBase_MustOverride_ID            0xc8dcf7ce5feaa591ULL
#define IIGVerifyCasePureBase_HostOnly_ID            0xbf3029d20694bea1ULL
#define IIGVerifyCasePureBase_ReplyOnly_ID            0xfafe66c97bace666ULL

#define IIGVerifyCasePureBase_MustOverride_Args \
        uint64_t value

#define IIGVerifyCasePureBase_HostOnly_Args \
        uint64_t value

#define IIGVerifyCasePureBase_ReplyOnly_Args \
        uint64_t value

#define IIGVerifyCasePureBase_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCasePureBase * self, const IORPC rpc);\
\
    kern_return_t\
    MustOverride(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    HostOnly(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ReplyOnly(\
        IORPC rpc,\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    HostOnly_Impl(IIGVerifyCasePureBase_HostOnly_Args);\
\
    kern_return_t\
    ReplyOnly_Impl(IIGVerifyCasePureBase_ReplyOnly_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*MustOverride_Handler)(OSMetaClassBase * target, IIGVerifyCasePureBase_MustOverride_Args);\
    static kern_return_t\
    MustOverride_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        MustOverride_Handler func);\
\
    typedef kern_return_t (*HostOnly_Handler)(OSMetaClassBase * target, IIGVerifyCasePureBase_HostOnly_Args);\
    static kern_return_t\
    HostOnly_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        HostOnly_Handler func);\
\
    typedef kern_return_t (*ReplyOnly_Handler)(OSMetaClassBase * target, IIGVerifyCasePureBase_ReplyOnly_Args);\
    static kern_return_t\
    ReplyOnly_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ReplyOnly_Handler func);\
\


#define IIGVerifyCasePureBase_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCasePureBase_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCasePureBaseMetaClass;
extern const OSClassLoadInformation IIGVerifyCasePureBase_Class;

class IIGVerifyCasePureBaseMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCasePureBaseInterface : public OSInterface
{
public:
};

struct IIGVerifyCasePureBase_IVars;
struct IIGVerifyCasePureBase_LocalIVars;

class IIGVerifyCasePureBase : public OSObject, public IIGVerifyCasePureBaseInterface
{
#if !KERNEL
    friend class IIGVerifyCasePureBaseMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCasePureBase_DECLARE_IVARS
IIGVerifyCasePureBase_DECLARE_IVARS
#else /* IIGVerifyCasePureBase_DECLARE_IVARS */
    union
    {
        IIGVerifyCasePureBase_IVars * ivars;
        IIGVerifyCasePureBase_LocalIVars * lvars;
    };
#endif /* IIGVerifyCasePureBase_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCasePureBaseMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCasePureBase_Methods
    IIGVerifyCasePureBase_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */


/* source class IIGVerifyCaseQueues IIGVerifyCaseQueues.iig:22-35 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseQueues : public IIGVerifyCasePureBase
{
public:
	virtual kern_return_t
	MustOverride(uint64_t value) override LOCAL;

	virtual kern_return_t
	OnQueueA(uint64_t value) LOCAL QUEUENAME(IIGVerifyCaseQueueA);

	virtual kern_return_t
	OnQueueB(uint64_t value) LOCAL QUEUENAME(IIGVerifyCaseQueueB);

	virtual kern_return_t
	OnQueueAAgain(uint64_t value) LOCAL QUEUENAME(IIGVerifyCaseQueueA);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseQueues IIGVerifyCaseQueues.iig:22-35 */

#define IIGVerifyCaseQueues_OnQueueA_ID            0x86c78d4243f83e03ULL
#define IIGVerifyCaseQueues_OnQueueB_ID            0xe87723562bbc4d56ULL
#define IIGVerifyCaseQueues_OnQueueAAgain_ID            0xa554b0afc74e71a4ULL

#define IIGVerifyCaseQueues_MustOverride_Args \
        uint64_t value

#define IIGVerifyCaseQueues_OnQueueA_Args \
        uint64_t value

#define IIGVerifyCaseQueues_OnQueueB_Args \
        uint64_t value

#define IIGVerifyCaseQueues_OnQueueAAgain_Args \
        uint64_t value

#define IIGVerifyCaseQueues_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseQueues * self, const IORPC rpc);\
\
    kern_return_t\
    OnQueueA(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OnQueueB(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OnQueueAAgain(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    MustOverride_Impl(IIGVerifyCasePureBase_MustOverride_Args);\
\
    kern_return_t\
    OnQueueA_Impl(IIGVerifyCaseQueues_OnQueueA_Args);\
\
    kern_return_t\
    OnQueueB_Impl(IIGVerifyCaseQueues_OnQueueB_Args);\
\
    kern_return_t\
    OnQueueAAgain_Impl(IIGVerifyCaseQueues_OnQueueAAgain_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*OnQueueA_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueues_OnQueueA_Args);\
    static kern_return_t\
    OnQueueA_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OnQueueA_Handler func);\
\
    typedef kern_return_t (*OnQueueB_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueues_OnQueueB_Args);\
    static kern_return_t\
    OnQueueB_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OnQueueB_Handler func);\
\
    typedef kern_return_t (*OnQueueAAgain_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueues_OnQueueAAgain_Args);\
    static kern_return_t\
    OnQueueAAgain_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OnQueueAAgain_Handler func);\
\


#define IIGVerifyCaseQueues_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseQueues_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseQueuesMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseQueues_Class;

class IIGVerifyCaseQueuesMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseQueuesInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseQueues_IVars;
struct IIGVerifyCaseQueues_LocalIVars;

class IIGVerifyCaseQueues : public IIGVerifyCasePureBase, public IIGVerifyCaseQueuesInterface
{
#if !KERNEL
    friend class IIGVerifyCaseQueuesMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseQueues_DECLARE_IVARS
IIGVerifyCaseQueues_DECLARE_IVARS
#else /* IIGVerifyCaseQueues_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseQueues_IVars * ivars;
        IIGVerifyCaseQueues_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseQueues_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseQueuesMetaClass; };
#endif /* KERNEL */

    using super = IIGVerifyCasePureBase;

#if !KERNEL
    IIGVerifyCaseQueues_Methods
    IIGVerifyCaseQueues_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseQueues.iig:37- */

#endif /* _DRIVERKIT_IIGVerifyCASEQUEUES_H */
