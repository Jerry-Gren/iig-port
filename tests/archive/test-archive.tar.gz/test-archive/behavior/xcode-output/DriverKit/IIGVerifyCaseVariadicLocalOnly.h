/* iig(DriverKit-440) generated from IIGVerifyCaseVariadicLocalOnly.iig */

/* IIGVerifyCaseVariadicLocalOnly.iig:1-7 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEVARIADICLOCALONLY_H
#define _DRIVERKIT_IIGVerifyCASEVARIADICLOCALONLY_H

typedef int (*IIGVerifyCaseVariadicSink)(const char *format, ...);

/* source class IIGVerifyCaseVariadicLocalOnly IIGVerifyCaseVariadicLocalOnly.iig:8-15 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseVariadicLocalOnly : public OSObject
{
public:
	virtual kern_return_t
	Log(const char * format, IIGVerifyCaseVariadicSink output) LOCALONLY;

	virtual kern_return_t
	Format(const char * format, ...) LOCALONLY;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseVariadicLocalOnly IIGVerifyCaseVariadicLocalOnly.iig:8-15 */


#define IIGVerifyCaseVariadicLocalOnly_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseVariadicLocalOnly * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyCaseVariadicLocalOnly_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseVariadicLocalOnly_VirtualMethods \
\
public:\
\
    virtual kern_return_t\
    Log(\
        const char * format,\
        IIGVerifyCaseVariadicSink output) APPLE_KEXT_OVERRIDE;\
\
    virtual kern_return_t\
    Format(\
        const char * format,\
        ...) APPLE_KEXT_OVERRIDE;\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseVariadicLocalOnlyMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseVariadicLocalOnly_Class;

class IIGVerifyCaseVariadicLocalOnlyMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseVariadicLocalOnlyInterface : public OSInterface
{
public:
    virtual kern_return_t
    Log(const char * format,
        IIGVerifyCaseVariadicSink output) = 0;

    virtual kern_return_t
    Format(const char * format) = 0;

    kern_return_t
    Log_Call(const char * format,
        IIGVerifyCaseVariadicSink output)  { return Log(format, output); };\

    kern_return_t
    Format_Call(const char * format)  { return Format(format); };\

};

struct IIGVerifyCaseVariadicLocalOnly_IVars;
struct IIGVerifyCaseVariadicLocalOnly_LocalIVars;

class IIGVerifyCaseVariadicLocalOnly : public OSObject, public IIGVerifyCaseVariadicLocalOnlyInterface
{
#if !KERNEL
    friend class IIGVerifyCaseVariadicLocalOnlyMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseVariadicLocalOnly_DECLARE_IVARS
IIGVerifyCaseVariadicLocalOnly_DECLARE_IVARS
#else /* IIGVerifyCaseVariadicLocalOnly_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseVariadicLocalOnly_IVars * ivars;
        IIGVerifyCaseVariadicLocalOnly_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseVariadicLocalOnly_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseVariadicLocalOnlyMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseVariadicLocalOnly_Methods
    IIGVerifyCaseVariadicLocalOnly_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseVariadicLocalOnly.iig:17- */

#endif /* _DRIVERKIT_IIGVerifyCASEVARIADICLOCALONLY_H */
