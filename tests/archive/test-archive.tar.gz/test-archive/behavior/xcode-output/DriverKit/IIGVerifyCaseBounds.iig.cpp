/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseBounds.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseBounds.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseBounds.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseBounds_MacroInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[7];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_MacroInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBounds_MacroInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBounds_MacroInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_MacroInput_Msg_ObjRefs (1)

struct IIGVerifyCaseBounds_MacroInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_MacroInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBounds_MacroInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBounds_MacroInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_MacroInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_MacroInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBounds_MacroInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBounds_MacroInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_MacroInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBounds_MacroInput_Invocation;
struct IIGVerifyCaseBounds_EnumInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[5];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_EnumInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBounds_EnumInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBounds_EnumInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_EnumInput_Msg_ObjRefs (1)

struct IIGVerifyCaseBounds_EnumInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_EnumInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBounds_EnumInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBounds_EnumInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_EnumInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_EnumInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBounds_EnumInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBounds_EnumInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_EnumInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBounds_EnumInput_Invocation;
struct IIGVerifyCaseBounds_TypedefOutput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_TypedefOutput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBounds_TypedefOutput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBounds_TypedefOutput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_TypedefOutput_Msg_ObjRefs (1)

struct IIGVerifyCaseBounds_TypedefOutput_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[3];
};
#pragma pack(4)
struct IIGVerifyCaseBounds_TypedefOutput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBounds_TypedefOutput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBounds_TypedefOutput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_TypedefOutput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_TypedefOutput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBounds_TypedefOutput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBounds_TypedefOutput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_TypedefOutput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBounds_TypedefOutput_Invocation;
struct IIGVerifyCaseBounds_StringPointer_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    char  name;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_StringPointer_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBounds_StringPointer_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBounds_StringPointer_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_StringPointer_Msg_ObjRefs (1)

struct IIGVerifyCaseBounds_StringPointer_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseBounds_StringPointer_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBounds_StringPointer_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBounds_StringPointer_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBounds_StringPointer_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_StringPointer_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBounds_StringPointer_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBounds_StringPointer_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBounds_StringPointer_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBounds_StringPointer_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseBounds_QueueNames  ""

#define IIGVerifyCaseBounds_MethodNames  ""

#define IIGVerifyCaseBoundsMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseBounds_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseBounds_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseBounds_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseBoundsMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseBounds_t
OSClassDescription_IIGVerifyCaseBounds =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseBounds_t),
        .name                    = "IIGVerifyCaseBounds",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBounds_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBounds_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseBounds_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBounds_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseBounds_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBounds_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseBoundsMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBounds_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseBounds_QueueNames,
    .methodNames     = IIGVerifyCaseBounds_MethodNames,
    .metaMethodNames = IIGVerifyCaseBoundsMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseBoundsMetaClass;

static kern_return_t
IIGVerifyCaseBounds_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseBounds_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseBounds.base,
    .metaPointer       = &gIIGVerifyCaseBoundsMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseBounds),

    .resv2             = {0},

    .New               = &IIGVerifyCaseBounds_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseBounds_Declaration;
const void * const
gIIGVerifyCaseBounds_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseBounds_Class;

static kern_return_t
IIGVerifyCaseBounds_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseBoundsMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseBoundsMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseBounds) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseBounds::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseBounds::_Dispatch(IIGVerifyCaseBounds * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseBounds_MacroInput_ID:
        {
            ret = IIGVerifyCaseBounds::MacroInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBounds::MacroInput_Handler, *self, &IIGVerifyCaseBounds::MacroInput_Impl));
            break;
        }
        case IIGVerifyCaseBounds_EnumInput_ID:
        {
            ret = IIGVerifyCaseBounds::EnumInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBounds::EnumInput_Handler, *self, &IIGVerifyCaseBounds::EnumInput_Impl));
            break;
        }
        case IIGVerifyCaseBounds_TypedefOutput_ID:
        {
            ret = IIGVerifyCaseBounds::TypedefOutput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBounds::TypedefOutput_Handler, *self, &IIGVerifyCaseBounds::TypedefOutput_Impl));
            break;
        }
        case IIGVerifyCaseBounds_StringPointer_ID:
        {
            ret = IIGVerifyCaseBounds::StringPointer_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBounds::StringPointer_Handler, *self, &IIGVerifyCaseBounds::StringPointer_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseBounds::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseBoundsMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::MacroInput(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBounds_MacroInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBounds_MacroInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBounds_MacroInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBounds_MacroInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBounds_MacroInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBounds_MacroInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBounds_MacroInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBounds_MacroInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::EnumInput(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBounds_EnumInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBounds_EnumInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBounds_EnumInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBounds_EnumInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBounds_EnumInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBounds_EnumInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBounds_EnumInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBounds_EnumInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::TypedefOutput(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBounds_TypedefOutput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBounds_TypedefOutput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBounds_TypedefOutput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBounds_TypedefOutput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBounds_TypedefOutput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBounds_TypedefOutput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBounds_TypedefOutput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBounds_TypedefOutput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::StringPointer(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBounds_StringPointer_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBounds_StringPointer_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBounds_StringPointer_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBounds_StringPointer_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBounds_StringPointer_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBounds_StringPointer_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = *name;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBounds_StringPointer_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBounds_StringPointer_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::MacroInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        MacroInput_Handler func)
{
    IIGVerifyCaseBounds_MacroInput_Invocation rpc = { _rpc };
    IIGVerifyCaseBounds_MacroInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBounds_MacroInput_Msg *         message = rpc.message;
    const IIGVerifyCaseBounds_MacroInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBounds_MacroInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBounds_MacroInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBounds_MacroInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBounds_MacroInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBounds_MacroInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::EnumInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        EnumInput_Handler func)
{
    IIGVerifyCaseBounds_EnumInput_Invocation rpc = { _rpc };
    IIGVerifyCaseBounds_EnumInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBounds_EnumInput_Msg *         message = rpc.message;
    const IIGVerifyCaseBounds_EnumInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBounds_EnumInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBounds_EnumInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBounds_EnumInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBounds_EnumInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBounds_EnumInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::TypedefOutput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TypedefOutput_Handler func)
{
    IIGVerifyCaseBounds_TypedefOutput_Invocation rpc = { _rpc };
    IIGVerifyCaseBounds_TypedefOutput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBounds_TypedefOutput_Msg *         message = rpc.message;
    const IIGVerifyCaseBounds_TypedefOutput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBounds_TypedefOutput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBounds_TypedefOutput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBounds_TypedefOutput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBounds_TypedefOutput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBounds_TypedefOutput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseBounds::StringPointer_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        StringPointer_Handler func)
{
    IIGVerifyCaseBounds_StringPointer_Invocation rpc = { _rpc };
    IIGVerifyCaseBounds_StringPointer_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBounds_StringPointer_Msg *         message = rpc.message;
    const IIGVerifyCaseBounds_StringPointer_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBounds_StringPointer_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBounds_StringPointer_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBounds_StringPointer_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(name));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBounds_StringPointer_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBounds_StringPointer_Rpl_ObjRefs;

    return (ret);
}



