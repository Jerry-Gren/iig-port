/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseStringConstSpellingsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseStringConstSpellingsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseStringConstSpellingsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[32];
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Invocation;
struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[33];
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Invocation;
struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[34];
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Invocation;
struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[35];
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_ObjRefs (1)

struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Invocation;
struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  name;
#if !defined(__LP64__)
    uint32_t __namePad;
#endif /* !defined(__LP64__) */
    char __name[36];
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_ObjRefs (1)

struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseStringConstSpellingsMore_QueueNames  ""

#define IIGVerifyCaseStringConstSpellingsMore_MethodNames  ""

#define IIGVerifyCaseStringConstSpellingsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseStringConstSpellingsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseStringConstSpellingsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseStringConstSpellingsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t
OSClassDescription_IIGVerifyCaseStringConstSpellingsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t),
        .name                    = "IIGVerifyCaseStringConstSpellingsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseStringConstSpellingsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseStringConstSpellingsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseStringConstSpellingsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStringConstSpellingsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseStringConstSpellingsMore_QueueNames,
    .methodNames     = IIGVerifyCaseStringConstSpellingsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseStringConstSpellingsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseStringConstSpellingsMoreMetaClass;

static kern_return_t
IIGVerifyCaseStringConstSpellingsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseStringConstSpellingsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseStringConstSpellingsMore.base,
    .metaPointer       = &gIIGVerifyCaseStringConstSpellingsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseStringConstSpellingsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseStringConstSpellingsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseStringConstSpellingsMore_Declaration;
const void * const
gIIGVerifyCaseStringConstSpellingsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseStringConstSpellingsMore_Class;

static kern_return_t
IIGVerifyCaseStringConstSpellingsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseStringConstSpellingsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseStringConstSpellingsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::_Dispatch(IIGVerifyCaseStringConstSpellingsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseStringConstSpellingsMore_LeadingConst_ID:
        {
            ret = IIGVerifyCaseStringConstSpellingsMore::LeadingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStringConstSpellingsMore::LeadingConst_Handler, *self, &IIGVerifyCaseStringConstSpellingsMore::LeadingConst_Impl));
            break;
        }
        case IIGVerifyCaseStringConstSpellingsMore_TrailingConst_ID:
        {
            ret = IIGVerifyCaseStringConstSpellingsMore::TrailingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStringConstSpellingsMore::TrailingConst_Handler, *self, &IIGVerifyCaseStringConstSpellingsMore::TrailingConst_Impl));
            break;
        }
        case IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_ID:
        {
            ret = IIGVerifyCaseStringConstSpellingsMore::AliasLeadingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStringConstSpellingsMore::AliasLeadingConst_Handler, *self, &IIGVerifyCaseStringConstSpellingsMore::AliasLeadingConst_Impl));
            break;
        }
        case IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_ID:
        {
            ret = IIGVerifyCaseStringConstSpellingsMore::AliasTrailingConst_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStringConstSpellingsMore::AliasTrailingConst_Handler, *self, &IIGVerifyCaseStringConstSpellingsMore::AliasTrailingConst_Impl));
            break;
        }
        case IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_ID:
        {
            ret = IIGVerifyCaseStringConstSpellingsMore::AliasConstElement_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStringConstSpellingsMore::AliasConstElement_Handler, *self, &IIGVerifyCaseStringConstSpellingsMore::AliasConstElement_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseStringConstSpellingsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseStringConstSpellingsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::LeadingConst(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_LeadingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStringConstSpellingsMore_LeadingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::TrailingConst(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_TrailingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStringConstSpellingsMore_TrailingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::AliasLeadingConst(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::AliasTrailingConst(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::AliasConstElement(
        const char * name,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.name = NULL;

    strlcpy(&msg->content.__name[0], name, sizeof(msg->content.__name));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::LeadingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        LeadingConst_Handler func)
{
    IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_LeadingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_LeadingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::TrailingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TrailingConst_Handler func)
{
    IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_TrailingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_TrailingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::AliasLeadingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasLeadingConst_Handler func)
{
    IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_AliasLeadingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::AliasTrailingConst_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasTrailingConst_Handler func)
{
    IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Invocation rpc = { _rpc };
    IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg *         message = rpc.message;
    const IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_AliasTrailingConst_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStringConstSpellingsMore::AliasConstElement_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        AliasConstElement_Handler func)
{
    IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Invocation rpc = { _rpc };
    IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg *         message = rpc.message;
    const IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__name[0]), sizeof(MESSAGE_CONTENT(__name))) >= sizeof(MESSAGE_CONTENT(__name))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__name[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStringConstSpellingsMore_AliasConstElement_Rpl_ObjRefs;

    return (ret);
}



