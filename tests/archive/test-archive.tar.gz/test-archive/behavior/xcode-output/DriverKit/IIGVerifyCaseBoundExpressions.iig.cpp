/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseBoundExpressions.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseBoundExpressions.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseBoundExpressions.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[4];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_ObjRefs (1)

struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBoundExpressions_MacroAliasInput_Invocation;
struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[3];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_ObjRefs (1)

struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBoundExpressions_EnumAliasInput_Invocation;
struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_ObjRefs (1)

struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[4];
};
#pragma pack(4)
struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseBoundExpressions_QueueNames  ""

#define IIGVerifyCaseBoundExpressions_MethodNames  ""

#define IIGVerifyCaseBoundExpressionsMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseBoundExpressions_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseBoundExpressions_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseBoundExpressions_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseBoundExpressionsMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseBoundExpressions_t
OSClassDescription_IIGVerifyCaseBoundExpressions =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseBoundExpressions_t),
        .name                    = "IIGVerifyCaseBoundExpressions",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBoundExpressions_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBoundExpressions_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseBoundExpressions_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBoundExpressions_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseBoundExpressions_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBoundExpressions_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseBoundExpressionsMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseBoundExpressions_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseBoundExpressions_QueueNames,
    .methodNames     = IIGVerifyCaseBoundExpressions_MethodNames,
    .metaMethodNames = IIGVerifyCaseBoundExpressionsMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseBoundExpressionsMetaClass;

static kern_return_t
IIGVerifyCaseBoundExpressions_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseBoundExpressions_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseBoundExpressions.base,
    .metaPointer       = &gIIGVerifyCaseBoundExpressionsMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseBoundExpressions),

    .resv2             = {0},

    .New               = &IIGVerifyCaseBoundExpressions_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseBoundExpressions_Declaration;
const void * const
gIIGVerifyCaseBoundExpressions_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseBoundExpressions_Class;

static kern_return_t
IIGVerifyCaseBoundExpressions_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseBoundExpressionsMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseBoundExpressionsMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseBoundExpressions) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseBoundExpressions::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseBoundExpressions::_Dispatch(IIGVerifyCaseBoundExpressions * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseBoundExpressions_MacroAliasInput_ID:
        {
            ret = IIGVerifyCaseBoundExpressions::MacroAliasInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBoundExpressions::MacroAliasInput_Handler, *self, &IIGVerifyCaseBoundExpressions::MacroAliasInput_Impl));
            break;
        }
        case IIGVerifyCaseBoundExpressions_EnumAliasInput_ID:
        {
            ret = IIGVerifyCaseBoundExpressions::EnumAliasInput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBoundExpressions::EnumAliasInput_Handler, *self, &IIGVerifyCaseBoundExpressions::EnumAliasInput_Impl));
            break;
        }
        case IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_ID:
        {
            ret = IIGVerifyCaseBoundExpressions::TypedefMacroAliasOutput_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseBoundExpressions::TypedefMacroAliasOutput_Handler, *self, &IIGVerifyCaseBoundExpressions::TypedefMacroAliasOutput_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseBoundExpressions::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseBoundExpressionsMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseBoundExpressions::MacroAliasInput(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBoundExpressions_MacroAliasInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBoundExpressions_MacroAliasInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBoundExpressions::EnumAliasInput(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBoundExpressions_EnumAliasInput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBoundExpressions_EnumAliasInput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBoundExpressions::TypedefMacroAliasOutput(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseBoundExpressions::MacroAliasInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        MacroAliasInput_Handler func)
{
    IIGVerifyCaseBoundExpressions_MacroAliasInput_Invocation rpc = { _rpc };
    IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg *         message = rpc.message;
    const IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBoundExpressions_MacroAliasInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBoundExpressions_MacroAliasInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBoundExpressions_MacroAliasInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseBoundExpressions::EnumAliasInput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        EnumAliasInput_Handler func)
{
    IIGVerifyCaseBoundExpressions_EnumAliasInput_Invocation rpc = { _rpc };
    IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg *         message = rpc.message;
    const IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBoundExpressions_EnumAliasInput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBoundExpressions_EnumAliasInput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBoundExpressions_EnumAliasInput_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseBoundExpressions::TypedefMacroAliasOutput_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TypedefMacroAliasOutput_Handler func)
{
    IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Invocation rpc = { _rpc };
    IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg *         message = rpc.message;
    const IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseBoundExpressions_TypedefMacroAliasOutput_Rpl_ObjRefs;

    return (ret);
}



