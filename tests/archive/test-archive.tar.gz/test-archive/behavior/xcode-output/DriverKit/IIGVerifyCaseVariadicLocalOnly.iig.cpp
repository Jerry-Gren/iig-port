/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseVariadicLocalOnly.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseVariadicLocalOnly.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseVariadicLocalOnly.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseVariadicLocalOnly_QueueNames  ""

#define IIGVerifyCaseVariadicLocalOnly_MethodNames  ""

#define IIGVerifyCaseVariadicLocalOnlyMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseVariadicLocalOnly_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseVariadicLocalOnly_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseVariadicLocalOnlyMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t
OSClassDescription_IIGVerifyCaseVariadicLocalOnly =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t),
        .name                    = "IIGVerifyCaseVariadicLocalOnly",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseVariadicLocalOnly_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseVariadicLocalOnly_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseVariadicLocalOnlyMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseVariadicLocalOnly_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseVariadicLocalOnly_QueueNames,
    .methodNames     = IIGVerifyCaseVariadicLocalOnly_MethodNames,
    .metaMethodNames = IIGVerifyCaseVariadicLocalOnlyMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseVariadicLocalOnlyMetaClass;

static kern_return_t
IIGVerifyCaseVariadicLocalOnly_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseVariadicLocalOnly_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseVariadicLocalOnly.base,
    .metaPointer       = &gIIGVerifyCaseVariadicLocalOnlyMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseVariadicLocalOnly),

    .resv2             = {0},

    .New               = &IIGVerifyCaseVariadicLocalOnly_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseVariadicLocalOnly_Declaration;
const void * const
gIIGVerifyCaseVariadicLocalOnly_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseVariadicLocalOnly_Class;

static kern_return_t
IIGVerifyCaseVariadicLocalOnly_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseVariadicLocalOnlyMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseVariadicLocalOnlyMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseVariadicLocalOnly) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseVariadicLocalOnly::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseVariadicLocalOnly::_Dispatch(IIGVerifyCaseVariadicLocalOnly * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseVariadicLocalOnly::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseVariadicLocalOnlyMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}



