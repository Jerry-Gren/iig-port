/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseCountAssociationsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseCountAssociationsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseCountAssociationsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[4];
    uint32_t  byteCount;
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_ObjRefs (1)

struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Invocation;
struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
    uint32_t  otherCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_ObjRefs (1)

struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[5];
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Invocation;
struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[3];
    uint32_t  objectsCount;
    uint32_t  unrelatedCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[3];
};
struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[3];
    IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_ObjRefs (4)

struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Invocation;
struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  buffersCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_ObjRefs (1)

struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef __buffers[2];
    uint32_t  buffersCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t buffers__descriptor[2];
};
struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t buffers__descriptor[2];
    IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_ObjRefs (2)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Invocation;
struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSDictionary * dictionaries;
#if !defined(__LP64__)
    uint32_t __dictionariesPad;
#endif /* !defined(__LP64__) */
    uint32_t  dictionariesCount;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  dictionaries__descriptor;
};
struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_ool_descriptor_t  dictionaries__descriptor;
    IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_ObjRefs (2)

struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gIOServiceMetaClass;
extern OSMetaClass * gIOMemoryMapMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseCountAssociationsMore_QueueNames  ""

#define IIGVerifyCaseCountAssociationsMore_MethodNames  ""

#define IIGVerifyCaseCountAssociationsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseCountAssociationsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseCountAssociationsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseCountAssociationsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t
OSClassDescription_IIGVerifyCaseCountAssociationsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseCountAssociationsMore_t),
        .name                    = "IIGVerifyCaseCountAssociationsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseCountAssociationsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseCountAssociationsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseCountAssociationsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCountAssociationsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseCountAssociationsMore_QueueNames,
    .methodNames     = IIGVerifyCaseCountAssociationsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseCountAssociationsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseCountAssociationsMoreMetaClass;

static kern_return_t
IIGVerifyCaseCountAssociationsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseCountAssociationsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseCountAssociationsMore.base,
    .metaPointer       = &gIIGVerifyCaseCountAssociationsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseCountAssociationsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseCountAssociationsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseCountAssociationsMore_Declaration;
const void * const
gIIGVerifyCaseCountAssociationsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseCountAssociationsMore_Class;

static kern_return_t
IIGVerifyCaseCountAssociationsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseCountAssociationsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseCountAssociationsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseCountAssociationsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseCountAssociationsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::_Dispatch(IIGVerifyCaseCountAssociationsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_ID:
        {
            ret = IIGVerifyCaseCountAssociationsMore::InputBytesWithExtraCount_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountAssociationsMore::InputBytesWithExtraCount_Handler, *self, &IIGVerifyCaseCountAssociationsMore::InputBytesWithExtraCount_Impl));
            break;
        }
        case IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_ID:
        {
            ret = IIGVerifyCaseCountAssociationsMore::OutputWordsCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountAssociationsMore::OutputWordsCountBefore_Handler, *self, &IIGVerifyCaseCountAssociationsMore::OutputWordsCountBefore_Impl));
            break;
        }
        case IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_ID:
        {
            ret = IIGVerifyCaseCountAssociationsMore::InputObjectsCountAfter_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountAssociationsMore::InputObjectsCountAfter_Handler, *self, &IIGVerifyCaseCountAssociationsMore::InputObjectsCountAfter_Impl));
            break;
        }
        case IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_ID:
        {
            ret = IIGVerifyCaseCountAssociationsMore::OutputBuffersCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountAssociationsMore::OutputBuffersCountBefore_Handler, *self, &IIGVerifyCaseCountAssociationsMore::OutputBuffersCountBefore_Impl));
            break;
        }
        case IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_ID:
        {
            ret = IIGVerifyCaseCountAssociationsMore::SerializableCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCountAssociationsMore::SerializableCountBefore_Handler, *self, &IIGVerifyCaseCountAssociationsMore::SerializableCountBefore_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseCountAssociationsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseCountAssociationsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::InputBytesWithExtraCount(
        const unsigned char * bytes,
        uint32_t byteCount,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.byteCount = byteCount;

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::OutputWordsCountBefore(
        uint32_t wordsCount,
        unsigned int * words,
        uint32_t otherCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

    msg->content.otherCount = otherCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::InputObjectsCountAfter(
        OSObject ** const objects,
        uint32_t objectsCount,
        uint32_t unrelatedCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 4;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 3; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

    msg->content.objectsCount = objectsCount;

    msg->content.unrelatedCount = unrelatedCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::OutputBuffersCountBefore(
        uint32_t buffersCount,
        IOBufferMemoryDescriptor ** buffers,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.buffersCount = buffersCount;

    if (*buffersCount > (sizeof(rpl->content.__buffers) / sizeof(rpl->content.__buffers[0]))) return kIOReturnOverrun;
    msg->content.buffersCount = *buffersCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 2) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.buffersCount < *buffersCount) *buffersCount = rpl->content.buffersCount;
        for (unsigned int idx = 0; idx < *buffersCount; idx++)
        {
           buffers[idx] = OSDynamicCast(IOBufferMemoryDescriptor, (OSObject *) rpl->content.__buffers[idx]);
        }
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::SerializableCountBefore(
        uint32_t dictionariesCount,
        const OSDictionary * dictionaries,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.dictionariesCount = dictionariesCount;

    msg->dictionaries__descriptor.type = MACH_MSG_OOL_DESCRIPTOR;
    msg->dictionaries__descriptor.copy = MACH_MSG_VIRTUAL_COPY;
    msg->dictionaries__descriptor.address = (void *) __builtin_offsetof(IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_Content, dictionaries);
    msg->content.dictionaries = dictionaries;

    if (dictionariesCount > (sizeof(msg->content.__dictionaries) / sizeof(msg->content.__dictionaries[0]))) return kIOReturnOverrun;
    bcopy(dictionaries, &msg->content.__dictionaries[0], dictionariesCount * sizeof(msg->content.__dictionaries[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::InputBytesWithExtraCount_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputBytesWithExtraCount_Handler func)
{
    IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Invocation rpc = { _rpc };
    IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg *         message = rpc.message;
    const IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        MESSAGE_CONTENT(byteCount),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_InputBytesWithExtraCount_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::OutputWordsCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputWordsCountBefore_Handler func)
{
    IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0],
        MESSAGE_CONTENT(otherCount));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_OutputWordsCountBefore_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::InputObjectsCountAfter_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputObjectsCountAfter_Handler func)
{
    IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Invocation rpc = { _rpc };
    IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg *         message = rpc.message;
    const IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    OSObject * objects[3] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop

    if (4 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (OSObject *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (OSObject **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(OSObject, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        objects,
        objectsCount,
        MESSAGE_CONTENT(unrelatedCount));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_InputObjectsCountAfter_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::OutputBuffersCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputBuffersCountBefore_Handler func)
{
    IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t buffersCount = (sizeof(MESSAGE_CONTENT(__buffers)) / sizeof(MESSAGE_CONTENT(__buffers[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(buffersCount) >= 0 && buffersCount > MESSAGE_CONTENT(buffersCount)) buffersCount = MESSAGE_CONTENT(buffersCount);
#pragma clang diagnostic pop
#if !__LP64__
    IOBufferMemoryDescriptor * buffers[2] = {};
#else /* !__LP64__ */
    IOBufferMemoryDescriptor ** buffers;
#endif /* __LP64__ */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if __LP64__
    buffers = (IOBufferMemoryDescriptor **)(uintptr_t) &reply->content.__buffers[0];
#endif /* __LP64__ */

    ret = (*func)(target,
        buffersCount,
        buffers);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 2;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_OutputBuffersCountBefore_Rpl_ObjRefs;
    for (unsigned int idx = 0; idx < 2; idx++)
    {
        reply->buffers__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
#if !__LP64__
        reply->content.__buffers[idx] = (OSObjectRef)(uintptr_t) buffers[idx];
#endif /* !_LP64__ */
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseCountAssociationsMore::SerializableCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SerializableCountBefore_Handler func)
{
    IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t dictionariesCount = (sizeof(MESSAGE_CONTENT(__dictionaries)) / sizeof(MESSAGE_CONTENT(__dictionaries[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(dictionariesCount) >= 0 && dictionariesCount > MESSAGE_CONTENT(dictionariesCount)) dictionariesCount = MESSAGE_CONTENT(dictionariesCount);
#pragma clang diagnostic pop

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (((OSObject *) MESSAGE_CONTENT(dictionaries)) != NULL && OSDynamicCast(OSDictionary, (OSObject *) MESSAGE_CONTENT(dictionaries)) == NULL) { return kIOReturnBadArgument; } 

    ret = (*func)(target,
        dictionariesCount,
        MESSAGE_CONTENT(dictionaries));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCountAssociationsMore_SerializableCountBefore_Rpl_ObjRefs;

    return (ret);
}



