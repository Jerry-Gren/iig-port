/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseArithmeticBoundExpressions.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseArithmeticBoundExpressions.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseArithmeticBoundExpressions.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[5];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_ObjRefs (1)

struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseArithmeticBoundExpressions_QueueNames  ""

#define IIGVerifyCaseArithmeticBoundExpressions_MethodNames  ""

#define IIGVerifyCaseArithmeticBoundExpressionsMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseArithmeticBoundExpressions_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseArithmeticBoundExpressions_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseArithmeticBoundExpressionsMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t
OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t),
        .name                    = "IIGVerifyCaseArithmeticBoundExpressions",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseArithmeticBoundExpressions_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseArithmeticBoundExpressions_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseArithmeticBoundExpressionsMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseArithmeticBoundExpressions_QueueNames,
    .methodNames     = IIGVerifyCaseArithmeticBoundExpressions_MethodNames,
    .metaMethodNames = IIGVerifyCaseArithmeticBoundExpressionsMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseArithmeticBoundExpressionsMetaClass;

static kern_return_t
IIGVerifyCaseArithmeticBoundExpressions_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseArithmeticBoundExpressions_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseArithmeticBoundExpressions.base,
    .metaPointer       = &gIIGVerifyCaseArithmeticBoundExpressionsMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseArithmeticBoundExpressions),

    .resv2             = {0},

    .New               = &IIGVerifyCaseArithmeticBoundExpressions_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseArithmeticBoundExpressions_Declaration;
const void * const
gIIGVerifyCaseArithmeticBoundExpressions_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseArithmeticBoundExpressions_Class;

static kern_return_t
IIGVerifyCaseArithmeticBoundExpressions_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseArithmeticBoundExpressionsMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseArithmeticBoundExpressionsMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseArithmeticBoundExpressions) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseArithmeticBoundExpressions::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseArithmeticBoundExpressions::_Dispatch(IIGVerifyCaseArithmeticBoundExpressions * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_ID:
        {
            ret = IIGVerifyCaseArithmeticBoundExpressions::InlineAddExpression_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseArithmeticBoundExpressions::InlineAddExpression_Handler, *self, &IIGVerifyCaseArithmeticBoundExpressions::InlineAddExpression_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseArithmeticBoundExpressions::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseArithmeticBoundExpressionsMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseArithmeticBoundExpressions::InlineAddExpression(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseArithmeticBoundExpressions::InlineAddExpression_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineAddExpression_Handler func)
{
    IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Invocation rpc = { _rpc };
    IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg *         message = rpc.message;
    const IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseArithmeticBoundExpressions_InlineAddExpression_Rpl_ObjRefs;

    return (ret);
}



