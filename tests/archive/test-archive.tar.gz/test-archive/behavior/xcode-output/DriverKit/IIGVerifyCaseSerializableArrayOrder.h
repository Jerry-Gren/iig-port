/* iig(DriverKit-440) generated from IIGVerifyCaseSerializableArrayOrder.iig */

/* IIGVerifyCaseSerializableArrayOrder.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESERIALIZABLEARRAYORDER_H
#define _DRIVERKIT_IIGVerifyCASESERIALIZABLEARRAYORDER_H

/* source class IIGVerifyCaseSerializableArrayOrder IIGVerifyCaseSerializableArrayOrder.iig:6-23 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseSerializableArrayOrder : public OSObject
{
public:
	virtual kern_return_t
	InstanceCountAfter(OSDictionary * const dictionaries[3],
	    uint32_t dictionariesCount) LOCAL;

	virtual kern_return_t
	InstanceCountBefore(uint32_t stringsCount,
	    OSString * const strings[2]) LOCAL;

	static kern_return_t
	StaticCountAfter(OSArray * const arrays[2],
	    uint32_t arraysCount) LOCAL;

	static kern_return_t
	StaticCountBefore(uint32_t setsCount,
	    OSSet * const sets[2]) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseSerializableArrayOrder IIGVerifyCaseSerializableArrayOrder.iig:6-23 */

#define IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_ID            0xd70864f111816e08ULL
#define IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_ID            0xc6195f9b699fb63fULL
#define IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_ID            0xbeecf07f17583decULL
#define IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_ID            0xa7b31f1920743665ULL

#define IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Args \
        const OSDictionary * dictionaries, \
        uint32_t dictionariesCount

#define IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Args \
        uint32_t stringsCount, \
        const OSString * strings

#define IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Args \
        const OSArray * arrays, \
        uint32_t arraysCount

#define IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Args \
        uint32_t setsCount, \
        const OSSet * sets

#define IIGVerifyCaseSerializableArrayOrder_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseSerializableArrayOrder * self, const IORPC rpc);\
\
    kern_return_t\
    InstanceCountAfter(\
        const OSDictionary * dictionaries,\
        uint32_t dictionariesCount,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    InstanceCountBefore(\
        uint32_t stringsCount,\
        const OSString * strings,\
        OSDispatchMethod supermethod = NULL);\
\
    static kern_return_t\
    StaticCountAfter(\
        const OSArray * arrays,\
        uint32_t arraysCount);\
\
    static kern_return_t\
    StaticCountBefore(\
        uint32_t setsCount,\
        const OSSet * sets);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InstanceCountAfter_Impl(IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Args);\
\
    kern_return_t\
    InstanceCountBefore_Impl(IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Args);\
\
    static kern_return_t\
    StaticCountAfter_Call(IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Args);\
\
    static kern_return_t\
    StaticCountBefore_Call(IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InstanceCountAfter_Handler)(OSMetaClassBase * target, IIGVerifyCaseSerializableArrayOrder_InstanceCountAfter_Args);\
    static kern_return_t\
    InstanceCountAfter_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceCountAfter_Handler func);\
\
    typedef kern_return_t (*InstanceCountBefore_Handler)(OSMetaClassBase * target, IIGVerifyCaseSerializableArrayOrder_InstanceCountBefore_Args);\
    static kern_return_t\
    InstanceCountBefore_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InstanceCountBefore_Handler func);\
\
    typedef kern_return_t (*StaticCountAfter_Handler)(IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Args);\
    static kern_return_t\
    StaticCountAfter_Invoke(const IORPC rpc,\
        StaticCountAfter_Handler func);\
\
    typedef kern_return_t (*StaticCountBefore_Handler)(IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Args);\
    static kern_return_t\
    StaticCountBefore_Invoke(const IORPC rpc,\
        StaticCountBefore_Handler func);\
\


#define IIGVerifyCaseSerializableArrayOrder_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    static kern_return_t\
    StaticCountAfter_Impl(IIGVerifyCaseSerializableArrayOrder_StaticCountAfter_Args);\
\
    static kern_return_t\
    StaticCountBefore_Impl(IIGVerifyCaseSerializableArrayOrder_StaticCountBefore_Args);\
\


#define IIGVerifyCaseSerializableArrayOrder_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseSerializableArrayOrderMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseSerializableArrayOrder_Class;

class IIGVerifyCaseSerializableArrayOrderMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseSerializableArrayOrderInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseSerializableArrayOrder_IVars;
struct IIGVerifyCaseSerializableArrayOrder_LocalIVars;

class IIGVerifyCaseSerializableArrayOrder : public OSObject, public IIGVerifyCaseSerializableArrayOrderInterface
{
#if !KERNEL
    friend class IIGVerifyCaseSerializableArrayOrderMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseSerializableArrayOrder_DECLARE_IVARS
IIGVerifyCaseSerializableArrayOrder_DECLARE_IVARS
#else /* IIGVerifyCaseSerializableArrayOrder_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseSerializableArrayOrder_IVars * ivars;
        IIGVerifyCaseSerializableArrayOrder_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseSerializableArrayOrder_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseSerializableArrayOrderMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseSerializableArrayOrder_Methods
    IIGVerifyCaseSerializableArrayOrder_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseSerializableArrayOrder.iig:25- */

#endif /* _DRIVERKIT_IIGVerifyCASESERIALIZABLEARRAYORDER_H */
