/* iig(DriverKit-440) generated from IIGVerifyCaseMethodAttributesMore.iig */

/* IIGVerifyCaseMethodAttributesMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEMETHODATTRIBUTESMORE_H
#define _DRIVERKIT_IIGVerifyCASEMETHODATTRIBUTESMORE_H

/* source class IIGVerifyCaseMethodAttributesBase IIGVerifyCaseMethodAttributesMore.iig:6-12 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseMethodAttributesBase : public OSObject
{
public:
	virtual kern_return_t
	BaseAvailable(uint64_t value)
	    LOCAL
	    __attribute__((availability(driverkit,introduced=20.0))) = 0;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseMethodAttributesBase IIGVerifyCaseMethodAttributesMore.iig:6-12 */

#define IIGVerifyCaseMethodAttributesBase_BaseAvailable_ID            0x9cc3811f2d50aac4ULL

#define IIGVerifyCaseMethodAttributesBase_BaseAvailable_Args \
        uint64_t value

#define IIGVerifyCaseMethodAttributesBase_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseMethodAttributesBase * self, const IORPC rpc);\
\
    kern_return_t\
    BaseAvailable(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL) __attribute__((availability(driverkit,introduced=20.0)));\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*BaseAvailable_Handler)(OSMetaClassBase * target, IIGVerifyCaseMethodAttributesBase_BaseAvailable_Args);\
    static kern_return_t\
    BaseAvailable_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        BaseAvailable_Handler func);\
\


#define IIGVerifyCaseMethodAttributesBase_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseMethodAttributesBase_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseMethodAttributesBaseMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseMethodAttributesBase_Class;

class IIGVerifyCaseMethodAttributesBaseMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseMethodAttributesBaseInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseMethodAttributesBase_IVars;
struct IIGVerifyCaseMethodAttributesBase_LocalIVars;

class IIGVerifyCaseMethodAttributesBase : public OSObject, public IIGVerifyCaseMethodAttributesBaseInterface
{
#if !KERNEL
    friend class IIGVerifyCaseMethodAttributesBaseMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseMethodAttributesBase_DECLARE_IVARS
IIGVerifyCaseMethodAttributesBase_DECLARE_IVARS
#else /* IIGVerifyCaseMethodAttributesBase_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseMethodAttributesBase_IVars * ivars;
        IIGVerifyCaseMethodAttributesBase_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseMethodAttributesBase_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseMethodAttributesBaseMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseMethodAttributesBase_Methods
    IIGVerifyCaseMethodAttributesBase_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */


/* source class IIGVerifyCaseMethodAttributesMore IIGVerifyCaseMethodAttributesMore.iig:15-28 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseMethodAttributesMore : public IIGVerifyCaseMethodAttributesBase
{
public:
	virtual kern_return_t
	BaseAvailable(uint64_t value)
	    override
	    LOCAL
	    __attribute__((availability(driverkit,introduced=20.0)));

	virtual kern_return_t
	FinalAvailable(uint64_t value)
	    final
	    LOCAL
	    __attribute__((availability(driverkit,introduced=21.0)));
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseMethodAttributesMore IIGVerifyCaseMethodAttributesMore.iig:15-28 */

#define IIGVerifyCaseMethodAttributesMore_FinalAvailable_ID            0x8338c00b6263d9b7ULL

#define IIGVerifyCaseMethodAttributesMore_BaseAvailable_Args \
        uint64_t value

#define IIGVerifyCaseMethodAttributesMore_FinalAvailable_Args \
        uint64_t value

#define IIGVerifyCaseMethodAttributesMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseMethodAttributesMore * self, const IORPC rpc);\
\
    kern_return_t\
    FinalAvailable(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL) __attribute__((availability(driverkit,introduced=21.0)));\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    BaseAvailable_Impl(IIGVerifyCaseMethodAttributesBase_BaseAvailable_Args);\
\
    kern_return_t\
    FinalAvailable_Impl(IIGVerifyCaseMethodAttributesMore_FinalAvailable_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*FinalAvailable_Handler)(OSMetaClassBase * target, IIGVerifyCaseMethodAttributesMore_FinalAvailable_Args);\
    static kern_return_t\
    FinalAvailable_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        FinalAvailable_Handler func);\
\


#define IIGVerifyCaseMethodAttributesMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseMethodAttributesMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseMethodAttributesMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseMethodAttributesMore_Class;

class IIGVerifyCaseMethodAttributesMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseMethodAttributesMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseMethodAttributesMore_IVars;
struct IIGVerifyCaseMethodAttributesMore_LocalIVars;

class IIGVerifyCaseMethodAttributesMore : public IIGVerifyCaseMethodAttributesBase, public IIGVerifyCaseMethodAttributesMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseMethodAttributesMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseMethodAttributesMore_DECLARE_IVARS
IIGVerifyCaseMethodAttributesMore_DECLARE_IVARS
#else /* IIGVerifyCaseMethodAttributesMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseMethodAttributesMore_IVars * ivars;
        IIGVerifyCaseMethodAttributesMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseMethodAttributesMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseMethodAttributesMoreMetaClass; };
#endif /* KERNEL */

    using super = IIGVerifyCaseMethodAttributesBase;

#if !KERNEL
    IIGVerifyCaseMethodAttributesMore_Methods
    IIGVerifyCaseMethodAttributesMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseMethodAttributesMore.iig:30- */

#endif /* _DRIVERKIT_IIGVerifyCASEMETHODATTRIBUTESMORE_H */
