/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseObjectArrayQualifiersMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseObjectArrayQualifiersMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseObjectArrayQualifiersMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_ObjRefs (1)

struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef __objects[3];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objects__descriptor[3];
};
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objects__descriptor[3];
    IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_ObjRefs (3)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Invocation;
struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[4];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[4];
};
struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[4];
    IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_ObjRefs (5)

struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Invocation;
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_ObjRefs (1)

struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef __objects[5];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objects__descriptor[5];
};
struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t objects__descriptor[5];
    IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_ObjRefs (5)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Invocation;
struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[6];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[6];
};
struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[6];
    IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_ObjRefs (7)

struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseObjectArrayQualifiersMore_QueueNames  ""

#define IIGVerifyCaseObjectArrayQualifiersMore_MethodNames  ""

#define IIGVerifyCaseObjectArrayQualifiersMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseObjectArrayQualifiersMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseObjectArrayQualifiersMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseObjectArrayQualifiersMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t
OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t),
        .name                    = "IIGVerifyCaseObjectArrayQualifiersMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseObjectArrayQualifiersMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseObjectArrayQualifiersMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseObjectArrayQualifiersMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseObjectArrayQualifiersMore_QueueNames,
    .methodNames     = IIGVerifyCaseObjectArrayQualifiersMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseObjectArrayQualifiersMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseObjectArrayQualifiersMoreMetaClass;

static kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseObjectArrayQualifiersMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseObjectArrayQualifiersMore.base,
    .metaPointer       = &gIIGVerifyCaseObjectArrayQualifiersMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseObjectArrayQualifiersMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseObjectArrayQualifiersMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseObjectArrayQualifiersMore_Declaration;
const void * const
gIIGVerifyCaseObjectArrayQualifiersMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseObjectArrayQualifiersMore_Class;

static kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseObjectArrayQualifiersMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseObjectArrayQualifiersMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::_Dispatch(IIGVerifyCaseObjectArrayQualifiersMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_ID:
        {
            ret = IIGVerifyCaseObjectArrayQualifiersMore::OutputTypedefArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrayQualifiersMore::OutputTypedefArray_Handler, *self, &IIGVerifyCaseObjectArrayQualifiersMore::OutputTypedefArray_Impl));
            break;
        }
        case IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_ID:
        {
            ret = IIGVerifyCaseObjectArrayQualifiersMore::InputConstTypedefArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrayQualifiersMore::InputConstTypedefArray_Handler, *self, &IIGVerifyCaseObjectArrayQualifiersMore::InputConstTypedefArray_Impl));
            break;
        }
        case IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_ID:
        {
            ret = IIGVerifyCaseObjectArrayQualifiersMore::OutputAliasArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrayQualifiersMore::OutputAliasArray_Handler, *self, &IIGVerifyCaseObjectArrayQualifiersMore::OutputAliasArray_Impl));
            break;
        }
        case IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_ID:
        {
            ret = IIGVerifyCaseObjectArrayQualifiersMore::InputAliasConstArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseObjectArrayQualifiersMore::InputAliasConstArray_Handler, *self, &IIGVerifyCaseObjectArrayQualifiersMore::InputAliasConstArray_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseObjectArrayQualifiersMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::OutputTypedefArray(
        uint32_t objectsCount,
        OSObject ** objects,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.objectsCount = objectsCount;

    if (*objectsCount > (sizeof(rpl->content.__objects) / sizeof(rpl->content.__objects[0]))) return kIOReturnOverrun;
    msg->content.objectsCount = *objectsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 3) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.objectsCount < *objectsCount) *objectsCount = rpl->content.objectsCount;
        for (unsigned int idx = 0; idx < *objectsCount; idx++)
        {
           objects[idx] = OSDynamicCast(OSObject, (OSObject *) rpl->content.__objects[idx]);
        }
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::InputConstTypedefArray(
        OSObject ** const objects,
        uint32_t objectsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 5;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 4; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

    msg->content.objectsCount = objectsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::OutputAliasArray(
        uint32_t objectsCount,
        OSObject ** objects,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.objectsCount = objectsCount;

    if (*objectsCount > (sizeof(rpl->content.__objects) / sizeof(rpl->content.__objects[0]))) return kIOReturnOverrun;
    msg->content.objectsCount = *objectsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 5) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.objectsCount < *objectsCount) *objectsCount = rpl->content.objectsCount;
        for (unsigned int idx = 0; idx < *objectsCount; idx++)
        {
           objects[idx] = OSDynamicCast(OSObject, (OSObject *) rpl->content.__objects[idx]);
        }
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::InputAliasConstArray(
        OSObject ** const objects,
        uint32_t objectsCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 7;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 6; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

    msg->content.objectsCount = objectsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::OutputTypedefArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputTypedefArray_Handler func)
{
    IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop
#if !__LP64__
    OSObject * objects[3] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if __LP64__
    objects = (OSObject **)(uintptr_t) &reply->content.__objects[0];
#endif /* __LP64__ */

    ret = (*func)(target,
        objectsCount,
        objects);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 3;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_OutputTypedefArray_Rpl_ObjRefs;
    for (unsigned int idx = 0; idx < 3; idx++)
    {
        reply->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
#if !__LP64__
        reply->content.__objects[idx] = (OSObjectRef)(uintptr_t) objects[idx];
#endif /* !_LP64__ */
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::InputConstTypedefArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputConstTypedefArray_Handler func)
{
    IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    OSObject * objects[4] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop

    if (5 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (OSObject *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (OSObject **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(OSObject, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        objects,
        objectsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_InputConstTypedefArray_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::OutputAliasArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputAliasArray_Handler func)
{
    IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop
#if !__LP64__
    OSObject * objects[5] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if __LP64__
    objects = (OSObject **)(uintptr_t) &reply->content.__objects[0];
#endif /* __LP64__ */

    ret = (*func)(target,
        objectsCount,
        objects);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 5;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_OutputAliasArray_Rpl_ObjRefs;
    for (unsigned int idx = 0; idx < 5; idx++)
    {
        reply->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
#if !__LP64__
        reply->content.__objects[idx] = (OSObjectRef)(uintptr_t) objects[idx];
#endif /* !_LP64__ */
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseObjectArrayQualifiersMore::InputAliasConstArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputAliasConstArray_Handler func)
{
    IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Invocation rpc = { _rpc };
    IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg *         message = rpc.message;
    const IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    OSObject * objects[6] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop

    if (7 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (OSObject *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (OSObject **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(OSObject, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        objects,
        objectsCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseObjectArrayQualifiersMore_InputAliasConstArray_Rpl_ObjRefs;

    return (ret);
}



