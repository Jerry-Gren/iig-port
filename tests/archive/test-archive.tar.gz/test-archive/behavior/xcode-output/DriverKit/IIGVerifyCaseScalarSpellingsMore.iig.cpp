/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseScalarSpellingsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseScalarSpellingsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseScalarSpellingsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_ObjRefs (1)

struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_Content
{
    IORPCMessage __hdr;
    signed char  byte;
    short  half;
    int  word;
    long long  wide;
};
#pragma pack(4)
struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseScalarSpellingsMore_OutputSigned_Invocation;
struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_ObjRefs (1)

struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_Content
{
    IORPCMessage __hdr;
    unsigned long  size;
    unsigned long  pointer;
    bool  flag;
};
#pragma pack(4)
struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseScalarSpellingsMore_OutputNative_Invocation;
struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    int8_t  byte;
    int16_t  half;
    int32_t  word;
    int64_t  wide;
};
#pragma pack(4)
struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_ObjRefs (1)

struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseScalarSpellingsMore_InputSigned_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseScalarSpellingsMore_QueueNames  ""

#define IIGVerifyCaseScalarSpellingsMore_MethodNames  ""

#define IIGVerifyCaseScalarSpellingsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseScalarSpellingsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseScalarSpellingsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseScalarSpellingsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t
OSClassDescription_IIGVerifyCaseScalarSpellingsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t),
        .name                    = "IIGVerifyCaseScalarSpellingsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseScalarSpellingsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseScalarSpellingsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseScalarSpellingsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseScalarSpellingsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseScalarSpellingsMore_QueueNames,
    .methodNames     = IIGVerifyCaseScalarSpellingsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseScalarSpellingsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseScalarSpellingsMoreMetaClass;

static kern_return_t
IIGVerifyCaseScalarSpellingsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseScalarSpellingsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseScalarSpellingsMore.base,
    .metaPointer       = &gIIGVerifyCaseScalarSpellingsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseScalarSpellingsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseScalarSpellingsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseScalarSpellingsMore_Declaration;
const void * const
gIIGVerifyCaseScalarSpellingsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseScalarSpellingsMore_Class;

static kern_return_t
IIGVerifyCaseScalarSpellingsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseScalarSpellingsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseScalarSpellingsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseScalarSpellingsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::_Dispatch(IIGVerifyCaseScalarSpellingsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseScalarSpellingsMore_OutputSigned_ID:
        {
            ret = IIGVerifyCaseScalarSpellingsMore::OutputSigned_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseScalarSpellingsMore::OutputSigned_Handler, *self, &IIGVerifyCaseScalarSpellingsMore::OutputSigned_Impl));
            break;
        }
        case IIGVerifyCaseScalarSpellingsMore_OutputNative_ID:
        {
            ret = IIGVerifyCaseScalarSpellingsMore::OutputNative_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseScalarSpellingsMore::OutputNative_Handler, *self, &IIGVerifyCaseScalarSpellingsMore::OutputNative_Impl));
            break;
        }
        case IIGVerifyCaseScalarSpellingsMore_InputSigned_ID:
        {
            ret = IIGVerifyCaseScalarSpellingsMore::InputSigned_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseScalarSpellingsMore::InputSigned_Handler, *self, &IIGVerifyCaseScalarSpellingsMore::InputSigned_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseScalarSpellingsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseScalarSpellingsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::OutputSigned(
        int8_t * byte,
        int16_t * half,
        int32_t * word,
        int64_t * wide,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseScalarSpellingsMore_OutputSigned_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseScalarSpellingsMore_OutputSigned_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (byte) *byte = rpl->content.byte;
        if (half) *half = rpl->content.half;
        if (word) *word = rpl->content.word;
        if (wide) *wide = rpl->content.wide;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::OutputNative(
        size_t * size,
        uintptr_t * pointer,
        bool * flag,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseScalarSpellingsMore_OutputNative_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseScalarSpellingsMore_OutputNative_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (size) *size = rpl->content.size;
        if (pointer) *pointer = rpl->content.pointer;
        if (flag) *flag = rpl->content.flag;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::InputSigned(
        int8_t byte,
        int16_t half,
        int32_t word,
        int64_t wide,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseScalarSpellingsMore_InputSigned_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.byte = byte;

    msg->content.half = half;

    msg->content.word = word;

    msg->content.wide = wide;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseScalarSpellingsMore_InputSigned_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::OutputSigned_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputSigned_Handler func)
{
    IIGVerifyCaseScalarSpellingsMore_OutputSigned_Invocation rpc = { _rpc };
    IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg *         message = rpc.message;
    const IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseScalarSpellingsMore_OutputSigned_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.byte,
        &reply->content.half,
        &reply->content.word,
        &reply->content.wide);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseScalarSpellingsMore_OutputSigned_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseScalarSpellingsMore_OutputSigned_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::OutputNative_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputNative_Handler func)
{
    IIGVerifyCaseScalarSpellingsMore_OutputNative_Invocation rpc = { _rpc };
    IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg *         message = rpc.message;
    const IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseScalarSpellingsMore_OutputNative_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.size,
        &reply->content.pointer,
        &reply->content.flag);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseScalarSpellingsMore_OutputNative_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseScalarSpellingsMore_OutputNative_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseScalarSpellingsMore::InputSigned_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InputSigned_Handler func)
{
    IIGVerifyCaseScalarSpellingsMore_InputSigned_Invocation rpc = { _rpc };
    IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg *         message = rpc.message;
    const IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseScalarSpellingsMore_InputSigned_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        MESSAGE_CONTENT(byte),
        MESSAGE_CONTENT(half),
        MESSAGE_CONTENT(word),
        MESSAGE_CONTENT(wide));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseScalarSpellingsMore_InputSigned_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseScalarSpellingsMore_InputSigned_Rpl_ObjRefs;

    return (ret);
}



