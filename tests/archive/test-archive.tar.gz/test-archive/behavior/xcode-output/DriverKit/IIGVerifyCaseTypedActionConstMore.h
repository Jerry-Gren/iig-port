/* iig(DriverKit-440) generated from IIGVerifyCaseTypedActionConstMore.iig */

/* IIGVerifyCaseTypedActionConstMore.iig:1-5 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASETYPEDACTIONCONSTMORE_H
#define _DRIVERKIT_IIGVerifyCASETYPEDACTIONCONSTMORE_H

/* source class IIGVerifyCaseTypedActionConstMore IIGVerifyCaseTypedActionConstMore.iig:6-25 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseTypedActionConstMore : public OSObject
{
public:
	virtual void
	Completion(OSAction * action TARGET,
	    uint64_t token) REPLY LOCAL;

	virtual kern_return_t
	SubmitConst(const OSAction * completion TYPE(IIGVerifyCaseTypedActionConstMore::Completion),
	    uint64_t token) LOCAL;

	virtual kern_return_t
	SubmitTopConst(OSAction * const completion TYPE(IIGVerifyCaseTypedActionConstMore::Completion),
	    uint64_t token) LOCAL;

	virtual void
	KernelCompletion(OSAction * action TARGET,
	    uint64_t token)
	    KERNEL
	    TYPE(IIGVerifyCaseTypedActionConstMore::Completion);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseTypedActionConstMore IIGVerifyCaseTypedActionConstMore.iig:6-25 */

#define IIGVerifyCaseTypedActionConstMore_Completion_ID            0xccc6ce98c3d998d9ULL
#define IIGVerifyCaseTypedActionConstMore_SubmitConst_ID            0x981547a509fadc1fULL
#define IIGVerifyCaseTypedActionConstMore_SubmitTopConst_ID            0xf4547a09e19e4c8dULL
#define IIGVerifyCaseTypedActionConstMore_KernelCompletion_ID            0xbe3a8475c29ce575ULL

#define IIGVerifyCaseTypedActionConstMore_Completion_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseTypedActionConstMore_SubmitConst_Args \
        const OSAction * completion, \
        uint64_t token

#define IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Args \
        OSAction *const completion, \
        uint64_t token

#define IIGVerifyCaseTypedActionConstMore_KernelCompletion_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseTypedActionConstMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseTypedActionConstMore * self, const IORPC rpc);\
\
    kern_return_t\
    Completion(\
        IORPC rpc,\
        OSAction * action,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitConst(\
        const OSAction * completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitTopConst(\
        OSAction *const completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CreateActionKernelCompletion(size_t referenceSize, OSAction ** action);\
\
\
protected:\
    /* _Impl methods */\
\
    void\
    Completion_Impl(IIGVerifyCaseTypedActionConstMore_Completion_Args);\
\
    kern_return_t\
    SubmitConst_Impl(IIGVerifyCaseTypedActionConstMore_SubmitConst_Args);\
\
    kern_return_t\
    SubmitTopConst_Impl(IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef void (*Completion_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedActionConstMore_Completion_Args);\
    static kern_return_t\
    Completion_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Completion_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    Completion_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Completion_Handler func);\
\
    typedef kern_return_t (*SubmitConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedActionConstMore_SubmitConst_Args);\
    static kern_return_t\
    SubmitConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitConst_Handler func);\
\
    typedef kern_return_t (*SubmitTopConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseTypedActionConstMore_SubmitTopConst_Args);\
    static kern_return_t\
    SubmitTopConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitTopConst_Handler func);\
\


#define IIGVerifyCaseTypedActionConstMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    void\
    KernelCompletion_Impl(IIGVerifyCaseTypedActionConstMore_KernelCompletion_Args);\
\


#define IIGVerifyCaseTypedActionConstMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseTypedActionConstMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseTypedActionConstMore_Class;

class IIGVerifyCaseTypedActionConstMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseTypedActionConstMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseTypedActionConstMore_IVars;
struct IIGVerifyCaseTypedActionConstMore_LocalIVars;

class IIGVerifyCaseTypedActionConstMore : public OSObject, public IIGVerifyCaseTypedActionConstMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseTypedActionConstMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseTypedActionConstMore_DECLARE_IVARS
IIGVerifyCaseTypedActionConstMore_DECLARE_IVARS
#else /* IIGVerifyCaseTypedActionConstMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseTypedActionConstMore_IVars * ivars;
        IIGVerifyCaseTypedActionConstMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseTypedActionConstMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseTypedActionConstMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseTypedActionConstMore_Methods
    IIGVerifyCaseTypedActionConstMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#define OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass;
extern const OSClassLoadInformation OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Class;

class OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

class  __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionInterface : public OSInterface
{
public:
};

struct OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_IVars;
struct OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_LocalIVars;

class __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion : public OSAction, public OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionInterface
{
#if KERNEL
    OSDeclareDefaultStructorsWithDispatch(OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion);
#endif /* KERNEL */

#if !KERNEL
    friend class OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass;
#endif /* !KERNEL */

public:
#ifdef OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_DECLARE_IVARS
OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_DECLARE_IVARS
#else /* OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_DECLARE_IVARS */
    union
    {
        OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_IVars * ivars;
        OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_LocalIVars * lvars;
    };
#endif /* OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_DECLARE_IVARS */
#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass; };
    virtual const OSMetaClass *
    getMetaClass() const APPLE_KEXT_OVERRIDE { return gOSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletionMetaClass; };
#endif /* KERNEL */

    using super = OSAction;

#if !KERNEL
    OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_Methods
#endif /* !KERNEL */

    OSAction_IIGVerifyCaseTypedActionConstMore_KernelCompletion_VirtualMethods
};

#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseTypedActionConstMore.iig:27- */

#endif /* _DRIVERKIT_IIGVerifyCASETYPEDACTIONCONSTMORE_H */
