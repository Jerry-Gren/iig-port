/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseRetainedPrefixMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseRetainedPrefixMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseRetainedPrefixMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Invocation;
struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixMore_getLowerObject_Invocation;
struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixMore_CopyObject_Invocation;
struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_ObjRefs (1)

struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_Content
{
    IORPCMessage __hdr;
    unsigned long long  value;
};
#pragma pack(4)
struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseRetainedPrefixMore_GetScalar_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseRetainedPrefixMore_QueueNames  ""

#define IIGVerifyCaseRetainedPrefixMore_MethodNames  ""

#define IIGVerifyCaseRetainedPrefixMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseRetainedPrefixMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseRetainedPrefixMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseRetainedPrefixMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t
OSClassDescription_IIGVerifyCaseRetainedPrefixMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t),
        .name                    = "IIGVerifyCaseRetainedPrefixMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseRetainedPrefixMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseRetainedPrefixMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseRetainedPrefixMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseRetainedPrefixMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseRetainedPrefixMore_QueueNames,
    .methodNames     = IIGVerifyCaseRetainedPrefixMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseRetainedPrefixMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseRetainedPrefixMoreMetaClass;

static kern_return_t
IIGVerifyCaseRetainedPrefixMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseRetainedPrefixMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseRetainedPrefixMore.base,
    .metaPointer       = &gIIGVerifyCaseRetainedPrefixMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseRetainedPrefixMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseRetainedPrefixMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseRetainedPrefixMore_Declaration;
const void * const
gIIGVerifyCaseRetainedPrefixMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseRetainedPrefixMore_Class;

static kern_return_t
IIGVerifyCaseRetainedPrefixMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseRetainedPrefixMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseRetainedPrefixMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseRetainedPrefixMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::_Dispatch(IIGVerifyCaseRetainedPrefixMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseRetainedPrefixMore_GetUpperObject_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixMore::GetUpperObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixMore::GetUpperObject_Handler, *self, &IIGVerifyCaseRetainedPrefixMore::GetUpperObject_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixMore_getLowerObject_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixMore::getLowerObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixMore::getLowerObject_Handler, *self, &IIGVerifyCaseRetainedPrefixMore::getLowerObject_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixMore_CopyObject_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixMore::CopyObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixMore::CopyObject_Handler, *self, &IIGVerifyCaseRetainedPrefixMore::CopyObject_Impl));
            break;
        }
        case IIGVerifyCaseRetainedPrefixMore_GetScalar_ID:
        {
            ret = IIGVerifyCaseRetainedPrefixMore::GetScalar_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseRetainedPrefixMore::GetScalar_Handler, *self, &IIGVerifyCaseRetainedPrefixMore::GetScalar_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseRetainedPrefixMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseRetainedPrefixMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::GetUpperObject(
        OSObject ** object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_GetUpperObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixMore_GetUpperObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::getLowerObject(
        OSObject ** object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_getLowerObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixMore_getLowerObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::CopyObject(
        OSObject ** object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_CopyObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixMore_CopyObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *object = OSDynamicCast(OSObject, (OSObject *) rpl->content.object);
        if (rpl->content.object && !*object) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::GetScalar(
        uint64_t * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_GetScalar_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseRetainedPrefixMore_GetScalar_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (value) *value = rpl->content.value;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::GetUpperObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        GetUpperObject_Handler func)
{
    IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_GetUpperObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_GetUpperObject_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::getLowerObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        getLowerObject_Handler func)
{
    IIGVerifyCaseRetainedPrefixMore_getLowerObject_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixMore_getLowerObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_getLowerObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_getLowerObject_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::CopyObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        CopyObject_Handler func)
{
    IIGVerifyCaseRetainedPrefixMore_CopyObject_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixMore_CopyObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        (OSObject **)&reply->content.object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_CopyObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_CopyObject_Rpl_ObjRefs;
    reply->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseRetainedPrefixMore::GetScalar_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        GetScalar_Handler func)
{
    IIGVerifyCaseRetainedPrefixMore_GetScalar_Invocation rpc = { _rpc };
    IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg *         message = rpc.message;
    const IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseRetainedPrefixMore_GetScalar_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &reply->content.value);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseRetainedPrefixMore_GetScalar_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseRetainedPrefixMore_GetScalar_Rpl_ObjRefs;

    return (ret);
}



