/* iig(DriverKit-440) generated from IIGVerifyCaseAvailabilityMore.iig */

/* IIGVerifyCaseAvailabilityMore.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEAVAILABILITYMORE_H
#define _DRIVERKIT_IIGVerifyCASEAVAILABILITYMORE_H

/* source class IIGVerifyCaseAvailabilityMore IIGVerifyCaseAvailabilityMore.iig:6-17 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseAvailabilityMore : public OSObject
{
public:
	virtual kern_return_t
	IntroducedDeprecated(uint64_t value)
	    LOCAL
	    __attribute__((availability(driverkit,introduced=20.0,deprecated=22.0,message="use Newer")));

	virtual kern_return_t
	Newer(uint64_t value)
	    LOCAL
	    __attribute__((availability(driverkit,introduced=22.0)));
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseAvailabilityMore IIGVerifyCaseAvailabilityMore.iig:6-17 */

#define IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_ID            0xbbecaebc6fe241adULL
#define IIGVerifyCaseAvailabilityMore_Newer_ID            0x9bd57cf879935fb9ULL

#define IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Args \
        uint64_t value

#define IIGVerifyCaseAvailabilityMore_Newer_Args \
        uint64_t value

#define IIGVerifyCaseAvailabilityMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseAvailabilityMore * self, const IORPC rpc);\
\
    kern_return_t\
    IntroducedDeprecated(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL) __attribute__((availability(driverkit,introduced=20.0,deprecated=22.0,message="use Newer")));\
\
    kern_return_t\
    Newer(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL) __attribute__((availability(driverkit,introduced=22.0)));\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    IntroducedDeprecated_Impl(IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Args);\
\
    kern_return_t\
    Newer_Impl(IIGVerifyCaseAvailabilityMore_Newer_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*IntroducedDeprecated_Handler)(OSMetaClassBase * target, IIGVerifyCaseAvailabilityMore_IntroducedDeprecated_Args);\
    static kern_return_t\
    IntroducedDeprecated_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        IntroducedDeprecated_Handler func);\
\
    typedef kern_return_t (*Newer_Handler)(OSMetaClassBase * target, IIGVerifyCaseAvailabilityMore_Newer_Args);\
    static kern_return_t\
    Newer_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        Newer_Handler func);\
\


#define IIGVerifyCaseAvailabilityMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseAvailabilityMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseAvailabilityMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseAvailabilityMore_Class;

class IIGVerifyCaseAvailabilityMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseAvailabilityMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseAvailabilityMore_IVars;
struct IIGVerifyCaseAvailabilityMore_LocalIVars;

class IIGVerifyCaseAvailabilityMore : public OSObject, public IIGVerifyCaseAvailabilityMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseAvailabilityMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseAvailabilityMore_DECLARE_IVARS
IIGVerifyCaseAvailabilityMore_DECLARE_IVARS
#else /* IIGVerifyCaseAvailabilityMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseAvailabilityMore_IVars * ivars;
        IIGVerifyCaseAvailabilityMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseAvailabilityMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseAvailabilityMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseAvailabilityMore_Methods
    IIGVerifyCaseAvailabilityMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseAvailabilityMore.iig:19- */

#endif /* _DRIVERKIT_IIGVerifyCASEAVAILABILITYMORE_H */
