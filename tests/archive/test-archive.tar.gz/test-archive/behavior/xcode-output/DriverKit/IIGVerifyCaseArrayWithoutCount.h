/* iig(DriverKit-440) generated from IIGVerifyCaseArrayWithoutCount.iig */

/* IIGVerifyCaseArrayWithoutCount.iig:1-5 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEARRAYWITHOUTCOUNT_H
#define _DRIVERKIT_IIGVerifyCASEARRAYWITHOUTCOUNT_H

/* source class IIGVerifyCaseArrayWithoutCount IIGVerifyCaseArrayWithoutCount.iig:6-13 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseArrayWithoutCount : public OSObject
{
public:
	virtual kern_return_t
	InlineInputNoCount(const uint8_t bytes[4]) LOCAL;

	virtual kern_return_t
	ObjectInputNoCount(OSObject * const objects[2]) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseArrayWithoutCount IIGVerifyCaseArrayWithoutCount.iig:6-13 */

#define IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_ID            0xca04df556f449646ULL
#define IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_ID            0xd82f7818bfb8507cULL

#define IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Args \
        const unsigned char * bytes

#define IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Args \
        OSObject ** const objects

#define IIGVerifyCaseArrayWithoutCount_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseArrayWithoutCount * self, const IORPC rpc);\
\
    kern_return_t\
    InlineInputNoCount(\
        const unsigned char * bytes,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ObjectInputNoCount(\
        OSObject ** const objects,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InlineInputNoCount_Impl(IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Args);\
\
    kern_return_t\
    ObjectInputNoCount_Impl(IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InlineInputNoCount_Handler)(OSMetaClassBase * target, IIGVerifyCaseArrayWithoutCount_InlineInputNoCount_Args);\
    static kern_return_t\
    InlineInputNoCount_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InlineInputNoCount_Handler func);\
\
    typedef kern_return_t (*ObjectInputNoCount_Handler)(OSMetaClassBase * target, IIGVerifyCaseArrayWithoutCount_ObjectInputNoCount_Args);\
    static kern_return_t\
    ObjectInputNoCount_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ObjectInputNoCount_Handler func);\
\


#define IIGVerifyCaseArrayWithoutCount_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseArrayWithoutCount_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseArrayWithoutCountMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseArrayWithoutCount_Class;

class IIGVerifyCaseArrayWithoutCountMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseArrayWithoutCountInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseArrayWithoutCount_IVars;
struct IIGVerifyCaseArrayWithoutCount_LocalIVars;

class IIGVerifyCaseArrayWithoutCount : public OSObject, public IIGVerifyCaseArrayWithoutCountInterface
{
#if !KERNEL
    friend class IIGVerifyCaseArrayWithoutCountMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseArrayWithoutCount_DECLARE_IVARS
IIGVerifyCaseArrayWithoutCount_DECLARE_IVARS
#else /* IIGVerifyCaseArrayWithoutCount_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseArrayWithoutCount_IVars * ivars;
        IIGVerifyCaseArrayWithoutCount_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseArrayWithoutCount_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseArrayWithoutCountMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseArrayWithoutCount_Methods
    IIGVerifyCaseArrayWithoutCount_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseArrayWithoutCount.iig:15- */

#endif /* _DRIVERKIT_IIGVerifyCASEARRAYWITHOUTCOUNT_H */
