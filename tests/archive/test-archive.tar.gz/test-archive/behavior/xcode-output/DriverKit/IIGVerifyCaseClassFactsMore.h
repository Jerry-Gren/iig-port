/* iig(DriverKit-440) generated from IIGVerifyCaseClassFactsMore.iig */

/* IIGVerifyCaseClassFactsMore.iig:1-10 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASECLASSFACTSMORE_H
#define _DRIVERKIT_IIGVerifyCASECLASSFACTSMORE_H

struct IIGVerifyClassFactsStruct
{
	uint64_t value;
};

/* source class IIGVerifyClassFactsSerializable IIGVerifyCaseClassFactsMore.iig:11-14 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class IIG_SERIALIZABLE IIGVerifyClassFactsSerializable : public OSObject
{
public:
	uint64_t value;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyClassFactsSerializable IIGVerifyCaseClassFactsMore.iig:11-14 */


#define IIGVerifyClassFactsSerializable_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyClassFactsSerializable * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define IIGVerifyClassFactsSerializable_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyClassFactsSerializable_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyClassFactsSerializableMetaClass;
extern const OSClassLoadInformation IIGVerifyClassFactsSerializable_Class;

class IIGVerifyClassFactsSerializableMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyClassFactsSerializableInterface : public OSInterface
{
public:
};

struct IIGVerifyClassFactsSerializable_IVars;
struct IIGVerifyClassFactsSerializable_LocalIVars;

class IIGVerifyClassFactsSerializable : public OSObject, public IIGVerifyClassFactsSerializableInterface
{
#if !KERNEL
    friend class IIGVerifyClassFactsSerializableMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyClassFactsSerializable_DECLARE_IVARS
IIGVerifyClassFactsSerializable_DECLARE_IVARS
#else /* IIGVerifyClassFactsSerializable_DECLARE_IVARS */
    union
    {
        IIGVerifyClassFactsSerializable_IVars * ivars;
        IIGVerifyClassFactsSerializable_LocalIVars * lvars;
    };
#endif /* IIGVerifyClassFactsSerializable_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyClassFactsSerializableMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyClassFactsSerializable_Methods
    IIGVerifyClassFactsSerializable_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseClassFactsMore.iig:16-23 */

typedef OSObject * IIGVerifyObjectAlias;
typedef const OSObject * IIGVerifyConstObjectAlias;
typedef IIGVerifyClassFactsSerializable * IIGVerifySerializableAlias;
typedef const IIGVerifyClassFactsSerializable * IIGVerifyConstSerializableAlias;
typedef IIGVerifyClassFactsStruct * IIGVerifyStructOutAlias;
typedef const IIGVerifyClassFactsStruct * IIGVerifyStructInAlias;

/* source class IIGVerifyCaseClassFactsMore IIGVerifyCaseClassFactsMore.iig:24-34 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseClassFactsMore : public OSObject
{
public:
	virtual kern_return_t
	MixFacts(IIGVerifyObjectAlias object,
	    IIGVerifyObjectAlias * objectOut,
	    IIGVerifyConstObjectAlias constObject,
	    IIGVerifySerializableAlias serializableOut,
	    IIGVerifyConstSerializableAlias serializableIn,
	    IIGVerifyStructOutAlias structOut,
	    IIGVerifyStructInAlias structIn) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseClassFactsMore IIGVerifyCaseClassFactsMore.iig:24-34 */

#define IIGVerifyCaseClassFactsMore_MixFacts_ID            0x88616782fef7755cULL

#define IIGVerifyCaseClassFactsMore_MixFacts_Args \
        IIGVerifyObjectAlias object, \
        IIGVerifyObjectAlias * objectOut, \
        IIGVerifyConstObjectAlias constObject, \
        IIGVerifySerializableAlias serializableOut, \
        IIGVerifyConstSerializableAlias serializableIn, \
        IIGVerifyStructOutAlias structOut, \
        IIGVerifyStructInAlias structIn

#define IIGVerifyCaseClassFactsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseClassFactsMore * self, const IORPC rpc);\
\
    kern_return_t\
    MixFacts(\
        IIGVerifyObjectAlias object,\
        IIGVerifyObjectAlias * objectOut,\
        IIGVerifyConstObjectAlias constObject,\
        IIGVerifySerializableAlias serializableOut,\
        IIGVerifyConstSerializableAlias serializableIn,\
        IIGVerifyStructOutAlias structOut,\
        IIGVerifyStructInAlias structIn,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    MixFacts_Impl(IIGVerifyCaseClassFactsMore_MixFacts_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*MixFacts_Handler)(OSMetaClassBase * target, IIGVerifyCaseClassFactsMore_MixFacts_Args);\
    static kern_return_t\
    MixFacts_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        MixFacts_Handler func);\
\


#define IIGVerifyCaseClassFactsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseClassFactsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseClassFactsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseClassFactsMore_Class;

class IIGVerifyCaseClassFactsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseClassFactsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseClassFactsMore_IVars;
struct IIGVerifyCaseClassFactsMore_LocalIVars;

class IIGVerifyCaseClassFactsMore : public OSObject, public IIGVerifyCaseClassFactsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseClassFactsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseClassFactsMore_DECLARE_IVARS
IIGVerifyCaseClassFactsMore_DECLARE_IVARS
#else /* IIGVerifyCaseClassFactsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseClassFactsMore_IVars * ivars;
        IIGVerifyCaseClassFactsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseClassFactsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseClassFactsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseClassFactsMore_Methods
    IIGVerifyCaseClassFactsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseClassFactsMore.iig:36- */

#endif /* _DRIVERKIT_IIGVerifyCASECLASSFACTSMORE_H */
