/* iig(DriverKit-440) generated from IIGVerifyCaseQueueOrder.iig */

/* IIGVerifyCaseQueueOrder.iig:1-9 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEQUEUEORDER_H
#define _DRIVERKIT_IIGVerifyCASEQUEUEORDER_H

#define kIIGVerifyQueueOrderA "IIGVerifyQueueOrderA"
#define kIIGVerifyQueueOrderB "IIGVerifyQueueOrderB"
#define kIIGVerifyQueueOrderC "IIGVerifyQueueOrderC"

/* source class IIGVerifyCaseQueueOrder IIGVerifyCaseQueueOrder.iig:10-23 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseQueueOrder : public OSObject
{
public:
	virtual kern_return_t
	QueueOrderM0(uint64_t value) LOCAL QUEUENAME(IIGVerifyQueueOrderA);

	virtual kern_return_t
	QueueOrderM1(uint64_t value) LOCAL QUEUENAME(IIGVerifyQueueOrderB);

	virtual kern_return_t
	QueueOrderM2(uint64_t value) LOCAL QUEUENAME(IIGVerifyQueueOrderC);

	virtual kern_return_t
	QueueOrderM3(uint64_t value) LOCAL QUEUENAME(IIGVerifyQueueOrderA);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseQueueOrder IIGVerifyCaseQueueOrder.iig:10-23 */

#define IIGVerifyCaseQueueOrder_QueueOrderM0_ID            0xbe7c0c14223a80d9ULL
#define IIGVerifyCaseQueueOrder_QueueOrderM1_ID            0xf76a814b75adf52dULL
#define IIGVerifyCaseQueueOrder_QueueOrderM2_ID            0xfb6330bb3405954aULL
#define IIGVerifyCaseQueueOrder_QueueOrderM3_ID            0xe8471f74dd093c6aULL

#define IIGVerifyCaseQueueOrder_QueueOrderM0_Args \
        uint64_t value

#define IIGVerifyCaseQueueOrder_QueueOrderM1_Args \
        uint64_t value

#define IIGVerifyCaseQueueOrder_QueueOrderM2_Args \
        uint64_t value

#define IIGVerifyCaseQueueOrder_QueueOrderM3_Args \
        uint64_t value

#define IIGVerifyCaseQueueOrder_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseQueueOrder * self, const IORPC rpc);\
\
    kern_return_t\
    QueueOrderM0(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    QueueOrderM1(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    QueueOrderM2(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    QueueOrderM3(\
        uint64_t value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    QueueOrderM0_Impl(IIGVerifyCaseQueueOrder_QueueOrderM0_Args);\
\
    kern_return_t\
    QueueOrderM1_Impl(IIGVerifyCaseQueueOrder_QueueOrderM1_Args);\
\
    kern_return_t\
    QueueOrderM2_Impl(IIGVerifyCaseQueueOrder_QueueOrderM2_Args);\
\
    kern_return_t\
    QueueOrderM3_Impl(IIGVerifyCaseQueueOrder_QueueOrderM3_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*QueueOrderM0_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueueOrder_QueueOrderM0_Args);\
    static kern_return_t\
    QueueOrderM0_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        QueueOrderM0_Handler func);\
\
    typedef kern_return_t (*QueueOrderM1_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueueOrder_QueueOrderM1_Args);\
    static kern_return_t\
    QueueOrderM1_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        QueueOrderM1_Handler func);\
\
    typedef kern_return_t (*QueueOrderM2_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueueOrder_QueueOrderM2_Args);\
    static kern_return_t\
    QueueOrderM2_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        QueueOrderM2_Handler func);\
\
    typedef kern_return_t (*QueueOrderM3_Handler)(OSMetaClassBase * target, IIGVerifyCaseQueueOrder_QueueOrderM3_Args);\
    static kern_return_t\
    QueueOrderM3_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        QueueOrderM3_Handler func);\
\


#define IIGVerifyCaseQueueOrder_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseQueueOrder_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseQueueOrderMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseQueueOrder_Class;

class IIGVerifyCaseQueueOrderMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseQueueOrderInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseQueueOrder_IVars;
struct IIGVerifyCaseQueueOrder_LocalIVars;

class IIGVerifyCaseQueueOrder : public OSObject, public IIGVerifyCaseQueueOrderInterface
{
#if !KERNEL
    friend class IIGVerifyCaseQueueOrderMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseQueueOrder_DECLARE_IVARS
IIGVerifyCaseQueueOrder_DECLARE_IVARS
#else /* IIGVerifyCaseQueueOrder_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseQueueOrder_IVars * ivars;
        IIGVerifyCaseQueueOrder_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseQueueOrder_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseQueueOrderMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseQueueOrder_Methods
    IIGVerifyCaseQueueOrder_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseQueueOrder.iig:25- */

#endif /* _DRIVERKIT_IIGVerifyCASEQUEUEORDER_H */
