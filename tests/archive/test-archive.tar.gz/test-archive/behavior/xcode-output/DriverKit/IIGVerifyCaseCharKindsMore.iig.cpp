/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseCharKindsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseCharKindsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseCharKindsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const char *  text;
#if !defined(__LP64__)
    uint32_t __textPad;
#endif /* !defined(__LP64__) */
    char __text[7];
};
#pragma pack(4)
struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_ObjRefs (1)

struct IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCharKindsMore_PlainCharArray_Invocation;
struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const signed char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    signed char __bytes[8];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_ObjRefs (1)

struct IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCharKindsMore_SignedCharArray_Invocation;
struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[9];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_ObjRefs (1)

struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseCharKindsMore_UnsignedCharArray_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseCharKindsMore_QueueNames  ""

#define IIGVerifyCaseCharKindsMore_MethodNames  ""

#define IIGVerifyCaseCharKindsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseCharKindsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseCharKindsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseCharKindsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseCharKindsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseCharKindsMore_t
OSClassDescription_IIGVerifyCaseCharKindsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseCharKindsMore_t),
        .name                    = "IIGVerifyCaseCharKindsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCharKindsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCharKindsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseCharKindsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCharKindsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseCharKindsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCharKindsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseCharKindsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseCharKindsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseCharKindsMore_QueueNames,
    .methodNames     = IIGVerifyCaseCharKindsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseCharKindsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseCharKindsMoreMetaClass;

static kern_return_t
IIGVerifyCaseCharKindsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseCharKindsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseCharKindsMore.base,
    .metaPointer       = &gIIGVerifyCaseCharKindsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseCharKindsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseCharKindsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseCharKindsMore_Declaration;
const void * const
gIIGVerifyCaseCharKindsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseCharKindsMore_Class;

static kern_return_t
IIGVerifyCaseCharKindsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseCharKindsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseCharKindsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseCharKindsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseCharKindsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseCharKindsMore::_Dispatch(IIGVerifyCaseCharKindsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseCharKindsMore_PlainCharArray_ID:
        {
            ret = IIGVerifyCaseCharKindsMore::PlainCharArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCharKindsMore::PlainCharArray_Handler, *self, &IIGVerifyCaseCharKindsMore::PlainCharArray_Impl));
            break;
        }
        case IIGVerifyCaseCharKindsMore_SignedCharArray_ID:
        {
            ret = IIGVerifyCaseCharKindsMore::SignedCharArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCharKindsMore::SignedCharArray_Handler, *self, &IIGVerifyCaseCharKindsMore::SignedCharArray_Impl));
            break;
        }
        case IIGVerifyCaseCharKindsMore_UnsignedCharArray_ID:
        {
            ret = IIGVerifyCaseCharKindsMore::UnsignedCharArray_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseCharKindsMore::UnsignedCharArray_Handler, *self, &IIGVerifyCaseCharKindsMore::UnsignedCharArray_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseCharKindsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseCharKindsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseCharKindsMore::PlainCharArray(
        const char * text,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCharKindsMore_PlainCharArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.text = NULL;

    strlcpy(&msg->content.__text[0], text, sizeof(msg->content.__text));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCharKindsMore_PlainCharArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCharKindsMore::SignedCharArray(
        const signed char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCharKindsMore_SignedCharArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCharKindsMore_SignedCharArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCharKindsMore::UnsignedCharArray(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseCharKindsMore_UnsignedCharArray_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseCharKindsMore_UnsignedCharArray_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseCharKindsMore::PlainCharArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        PlainCharArray_Handler func)
{
    IIGVerifyCaseCharKindsMore_PlainCharArray_Invocation rpc = { _rpc };
    IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCharKindsMore_PlainCharArray_Msg *         message = rpc.message;
    const IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCharKindsMore_PlainCharArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    if (strnlen(&MESSAGE_CONTENT(__text[0]), sizeof(MESSAGE_CONTENT(__text))) >= sizeof(MESSAGE_CONTENT(__text))) return kIOReturnBadArgument;

    ret = (*func)(target,
        &MESSAGE_CONTENT(__text[0]));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCharKindsMore_PlainCharArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCharKindsMore_PlainCharArray_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCharKindsMore::SignedCharArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SignedCharArray_Handler func)
{
    IIGVerifyCaseCharKindsMore_SignedCharArray_Invocation rpc = { _rpc };
    IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCharKindsMore_SignedCharArray_Msg *         message = rpc.message;
    const IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCharKindsMore_SignedCharArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCharKindsMore_SignedCharArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCharKindsMore_SignedCharArray_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseCharKindsMore::UnsignedCharArray_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        UnsignedCharArray_Handler func)
{
    IIGVerifyCaseCharKindsMore_UnsignedCharArray_Invocation rpc = { _rpc };
    IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg *         message = rpc.message;
    const IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseCharKindsMore_UnsignedCharArray_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseCharKindsMore_UnsignedCharArray_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseCharKindsMore_UnsignedCharArray_Rpl_ObjRefs;

    return (ret);
}



