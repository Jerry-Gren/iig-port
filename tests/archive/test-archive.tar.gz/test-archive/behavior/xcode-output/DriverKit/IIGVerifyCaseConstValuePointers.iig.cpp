/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseConstValuePointers.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseConstValuePointers.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseConstValuePointers.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseConstValuePointers_ConstByte_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    unsigned char  value;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstByte_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseConstValuePointers_ConstByte_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseConstValuePointers_ConstByte_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstByte_Msg_ObjRefs (1)

struct IIGVerifyCaseConstValuePointers_ConstByte_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstByte_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseConstValuePointers_ConstByte_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseConstValuePointers_ConstByte_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstByte_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstByte_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseConstValuePointers_ConstByte_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseConstValuePointers_ConstByte_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstByte_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseConstValuePointers_ConstByte_Invocation;
struct IIGVerifyCaseConstValuePointers_ConstBool_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    bool  flag;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstBool_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseConstValuePointers_ConstBool_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseConstValuePointers_ConstBool_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstBool_Msg_ObjRefs (1)

struct IIGVerifyCaseConstValuePointers_ConstBool_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstBool_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseConstValuePointers_ConstBool_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseConstValuePointers_ConstBool_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstBool_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstBool_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseConstValuePointers_ConstBool_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseConstValuePointers_ConstBool_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstBool_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseConstValuePointers_ConstBool_Invocation;
struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    IIGVerifyCaseConstValueStruct  value;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseConstValuePointers_ConstStruct_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstStruct_Msg_ObjRefs (1)

struct IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstStruct_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseConstValuePointers_ConstStruct_Invocation;
struct IIGVerifyCaseConstValuePointers_ConstObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObject  object;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseConstValuePointers_ConstObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseConstValuePointers_ConstObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstObject_Msg_ObjRefs (1)

struct IIGVerifyCaseConstValuePointers_ConstObject_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_ConstObject_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseConstValuePointers_ConstObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseConstValuePointers_ConstObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_ConstObject_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseConstValuePointers_ConstObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseConstValuePointers_ConstObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_ConstObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseConstValuePointers_ConstObject_Invocation;
struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef  object;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
};
struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t object__descriptor;
    IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_ObjRefs (2)

struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseConstValuePointers_TopLevelConstObject_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseConstValuePointers_QueueNames  ""

#define IIGVerifyCaseConstValuePointers_MethodNames  ""

#define IIGVerifyCaseConstValuePointersMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseConstValuePointers_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseConstValuePointers_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseConstValuePointers_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseConstValuePointersMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseConstValuePointers_t
OSClassDescription_IIGVerifyCaseConstValuePointers =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseConstValuePointers_t),
        .name                    = "IIGVerifyCaseConstValuePointers",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConstValuePointers_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConstValuePointers_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseConstValuePointers_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConstValuePointers_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseConstValuePointers_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConstValuePointers_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseConstValuePointersMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseConstValuePointers_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseConstValuePointers_QueueNames,
    .methodNames     = IIGVerifyCaseConstValuePointers_MethodNames,
    .metaMethodNames = IIGVerifyCaseConstValuePointersMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseConstValuePointersMetaClass;

static kern_return_t
IIGVerifyCaseConstValuePointers_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseConstValuePointers_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseConstValuePointers.base,
    .metaPointer       = &gIIGVerifyCaseConstValuePointersMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseConstValuePointers),

    .resv2             = {0},

    .New               = &IIGVerifyCaseConstValuePointers_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseConstValuePointers_Declaration;
const void * const
gIIGVerifyCaseConstValuePointers_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseConstValuePointers_Class;

static kern_return_t
IIGVerifyCaseConstValuePointers_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseConstValuePointersMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseConstValuePointersMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseConstValuePointers) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseConstValuePointers::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseConstValuePointers::_Dispatch(IIGVerifyCaseConstValuePointers * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseConstValuePointers_ConstByte_ID:
        {
            ret = IIGVerifyCaseConstValuePointers::ConstByte_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseConstValuePointers::ConstByte_Handler, *self, &IIGVerifyCaseConstValuePointers::ConstByte_Impl));
            break;
        }
        case IIGVerifyCaseConstValuePointers_ConstBool_ID:
        {
            ret = IIGVerifyCaseConstValuePointers::ConstBool_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseConstValuePointers::ConstBool_Handler, *self, &IIGVerifyCaseConstValuePointers::ConstBool_Impl));
            break;
        }
        case IIGVerifyCaseConstValuePointers_ConstStruct_ID:
        {
            ret = IIGVerifyCaseConstValuePointers::ConstStruct_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseConstValuePointers::ConstStruct_Handler, *self, &IIGVerifyCaseConstValuePointers::ConstStruct_Impl));
            break;
        }
        case IIGVerifyCaseConstValuePointers_ConstObject_ID:
        {
            ret = IIGVerifyCaseConstValuePointers::ConstObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseConstValuePointers::ConstObject_Handler, *self, &IIGVerifyCaseConstValuePointers::ConstObject_Impl));
            break;
        }
        case IIGVerifyCaseConstValuePointers_TopLevelConstObject_ID:
        {
            ret = IIGVerifyCaseConstValuePointers::TopLevelConstObject_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseConstValuePointers::TopLevelConstObject_Handler, *self, &IIGVerifyCaseConstValuePointers::TopLevelConstObject_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseConstValuePointers::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseConstValuePointersMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstByte(
        const uint8_t * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseConstValuePointers_ConstByte_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseConstValuePointers_ConstByte_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseConstValuePointers_ConstByte_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseConstValuePointers_ConstByte_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstByte_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstByte_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseConstValuePointers_ConstByte_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseConstValuePointers_ConstByte_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstBool(
        const bool * flag,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseConstValuePointers_ConstBool_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseConstValuePointers_ConstBool_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseConstValuePointers_ConstBool_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseConstValuePointers_ConstBool_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstBool_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstBool_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.flag = *flag;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseConstValuePointers_ConstBool_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseConstValuePointers_ConstBool_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstStruct(
        const IIGVerifyCaseConstValueStruct * value,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseConstValuePointers_ConstStruct_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseConstValuePointers_ConstStruct_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstStruct_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstStruct_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.value = *value;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseConstValuePointers_ConstStruct_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstObject(
        const OSObject * object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseConstValuePointers_ConstObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseConstValuePointers_ConstObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseConstValuePointers_ConstObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseConstValuePointers_ConstObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.object = *object;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseConstValuePointers_ConstObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseConstValuePointers_ConstObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::TopLevelConstObject(
        OSObject *const object,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_TopLevelConstObject_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->content.object = (OSObjectRef) object;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseConstValuePointers_TopLevelConstObject_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstByte_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstByte_Handler func)
{
    IIGVerifyCaseConstValuePointers_ConstByte_Invocation rpc = { _rpc };
    IIGVerifyCaseConstValuePointers_ConstByte_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseConstValuePointers_ConstByte_Msg *         message = rpc.message;
    const IIGVerifyCaseConstValuePointers_ConstByte_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseConstValuePointers_ConstByte_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseConstValuePointers_ConstByte_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseConstValuePointers_ConstByte_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstByte_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstByte_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstBool_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstBool_Handler func)
{
    IIGVerifyCaseConstValuePointers_ConstBool_Invocation rpc = { _rpc };
    IIGVerifyCaseConstValuePointers_ConstBool_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseConstValuePointers_ConstBool_Msg *         message = rpc.message;
    const IIGVerifyCaseConstValuePointers_ConstBool_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseConstValuePointers_ConstBool_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseConstValuePointers_ConstBool_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseConstValuePointers_ConstBool_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(flag));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstBool_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstBool_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstStruct_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstStruct_Handler func)
{
    IIGVerifyCaseConstValuePointers_ConstStruct_Invocation rpc = { _rpc };
    IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseConstValuePointers_ConstStruct_Msg *         message = rpc.message;
    const IIGVerifyCaseConstValuePointers_ConstStruct_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseConstValuePointers_ConstStruct_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseConstValuePointers_ConstStruct_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseConstValuePointers_ConstStruct_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(value));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstStruct_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstStruct_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::ConstObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        ConstObject_Handler func)
{
    IIGVerifyCaseConstValuePointers_ConstObject_Invocation rpc = { _rpc };
    IIGVerifyCaseConstValuePointers_ConstObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseConstValuePointers_ConstObject_Msg *         message = rpc.message;
    const IIGVerifyCaseConstValuePointers_ConstObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseConstValuePointers_ConstObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseConstValuePointers_ConstObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseConstValuePointers_ConstObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(object));

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_ConstObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_ConstObject_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseConstValuePointers::TopLevelConstObject_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        TopLevelConstObject_Handler func)
{
    IIGVerifyCaseConstValuePointers_TopLevelConstObject_Invocation rpc = { _rpc };
    IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg *         message = rpc.message;
    const IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    OSObject * object;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseConstValuePointers_TopLevelConstObject_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
    object = OSDynamicCast(OSObject, (OSObject *) MESSAGE_CONTENT(object));
    if (!object && MESSAGE_CONTENT(object)) return (kIOReturnBadArgument);

    ret = (*func)(target,
        object);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseConstValuePointers_TopLevelConstObject_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseConstValuePointers_TopLevelConstObject_Rpl_ObjRefs;

    return (ret);
}



