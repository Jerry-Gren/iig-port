/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseIntegerOperatorsMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseIntegerOperatorsMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseIntegerOperatorsMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[8];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerOperatorsMore_InlineShift_Invocation;
struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[8];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Invocation;
struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[3];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Invocation;
struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    const unsigned char *  bytes;
#if !defined(__LP64__)
    uint32_t __bytesPad;
#endif /* !defined(__LP64__) */
    unsigned char __bytes[6];
    uint32_t  bytesCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Invocation;
struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[7];
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Invocation;
struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    uint32_t  wordsCount;
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
};
struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_ObjRefs (1)

struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_Content
{
    IORPCMessage __hdr;
    uint32_t  wordsCount;
    unsigned int *  words;
#if !defined(__LP64__)
    uint32_t __wordsPad;
#endif /* !defined(__LP64__) */
    unsigned int __words[5];
};
#pragma pack(4)
struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseIntegerOperatorsMore_QueueNames  ""

#define IIGVerifyCaseIntegerOperatorsMore_MethodNames  ""

#define IIGVerifyCaseIntegerOperatorsMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseIntegerOperatorsMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseIntegerOperatorsMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseIntegerOperatorsMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t
OSClassDescription_IIGVerifyCaseIntegerOperatorsMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t),
        .name                    = "IIGVerifyCaseIntegerOperatorsMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseIntegerOperatorsMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseIntegerOperatorsMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseIntegerOperatorsMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseIntegerOperatorsMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseIntegerOperatorsMore_QueueNames,
    .methodNames     = IIGVerifyCaseIntegerOperatorsMore_MethodNames,
    .metaMethodNames = IIGVerifyCaseIntegerOperatorsMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseIntegerOperatorsMoreMetaClass;

static kern_return_t
IIGVerifyCaseIntegerOperatorsMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseIntegerOperatorsMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseIntegerOperatorsMore.base,
    .metaPointer       = &gIIGVerifyCaseIntegerOperatorsMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseIntegerOperatorsMore),

    .resv2             = {0},

    .New               = &IIGVerifyCaseIntegerOperatorsMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseIntegerOperatorsMore_Declaration;
const void * const
gIIGVerifyCaseIntegerOperatorsMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseIntegerOperatorsMore_Class;

static kern_return_t
IIGVerifyCaseIntegerOperatorsMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseIntegerOperatorsMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseIntegerOperatorsMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::_Dispatch(IIGVerifyCaseIntegerOperatorsMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseIntegerOperatorsMore_InlineShift_ID:
        {
            ret = IIGVerifyCaseIntegerOperatorsMore::InlineShift_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerOperatorsMore::InlineShift_Handler, *self, &IIGVerifyCaseIntegerOperatorsMore::InlineShift_Impl));
            break;
        }
        case IIGVerifyCaseIntegerOperatorsMore_InlineDivide_ID:
        {
            ret = IIGVerifyCaseIntegerOperatorsMore::InlineDivide_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerOperatorsMore::InlineDivide_Handler, *self, &IIGVerifyCaseIntegerOperatorsMore::InlineDivide_Impl));
            break;
        }
        case IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_ID:
        {
            ret = IIGVerifyCaseIntegerOperatorsMore::InlineRemainder_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerOperatorsMore::InlineRemainder_Handler, *self, &IIGVerifyCaseIntegerOperatorsMore::InlineRemainder_Impl));
            break;
        }
        case IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_ID:
        {
            ret = IIGVerifyCaseIntegerOperatorsMore::InlineAndMask_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerOperatorsMore::InlineAndMask_Handler, *self, &IIGVerifyCaseIntegerOperatorsMore::InlineAndMask_Impl));
            break;
        }
        case IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_ID:
        {
            ret = IIGVerifyCaseIntegerOperatorsMore::OutputBitwise_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerOperatorsMore::OutputBitwise_Handler, *self, &IIGVerifyCaseIntegerOperatorsMore::OutputBitwise_Impl));
            break;
        }
        case IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_ID:
        {
            ret = IIGVerifyCaseIntegerOperatorsMore::OutputEnumMixed_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseIntegerOperatorsMore::OutputEnumMixed_Handler, *self, &IIGVerifyCaseIntegerOperatorsMore::OutputEnumMixed_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseIntegerOperatorsMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseIntegerOperatorsMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineShift(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineShift_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerOperatorsMore_InlineShift_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineDivide(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineDivide_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerOperatorsMore_InlineDivide_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineRemainder(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineAndMask(
        const unsigned char * bytes,
        uint32_t bytesCount,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.bytes = NULL;

    if (bytesCount > (sizeof(msg->content.__bytes) / sizeof(msg->content.__bytes[0]))) return kIOReturnOverrun;
    bcopy(bytes, &msg->content.__bytes[0], bytesCount * sizeof(msg->content.__bytes[0]));

    msg->content.bytesCount = bytesCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::OutputBitwise(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::OutputEnumMixed(
        uint32_t wordsCount,
        unsigned int * words,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 1;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.wordsCount = wordsCount;

    if (*wordsCount > (sizeof(rpl->content.__words) / sizeof(rpl->content.__words[0]))) return kIOReturnOverrun;
    msg->content.wordsCount = *wordsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        if (rpl->content.wordsCount < *wordsCount) *wordsCount = rpl->content.wordsCount;
        bcopy(&rpl->content.__words[0], words, *wordsCount * sizeof(rpl->content.__words[0]));
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineShift_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineShift_Handler func)
{
    IIGVerifyCaseIntegerOperatorsMore_InlineShift_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerOperatorsMore_InlineShift_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineShift_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineShift_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineDivide_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineDivide_Handler func)
{
    IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineDivide_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineDivide_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineRemainder_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineRemainder_Handler func)
{
    IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineRemainder_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::InlineAndMask_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InlineAndMask_Handler func)
{
    IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t bytesCount = (sizeof(MESSAGE_CONTENT(__bytes)) / sizeof(MESSAGE_CONTENT(__bytes[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(bytesCount) >= 0 && bytesCount > MESSAGE_CONTENT(bytesCount)) bytesCount = MESSAGE_CONTENT(bytesCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        &MESSAGE_CONTENT(__bytes[0]),
        bytesCount);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_InlineAndMask_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::OutputBitwise_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputBitwise_Handler func)
{
    IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_OutputBitwise_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseIntegerOperatorsMore::OutputEnumMixed_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        OutputEnumMixed_Handler func)
{
    IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Invocation rpc = { _rpc };
    IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg *         message = rpc.message;
    const IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t wordsCount = (sizeof(MESSAGE_CONTENT(__words)) / sizeof(MESSAGE_CONTENT(__words[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(wordsCount) >= 0 && wordsCount > MESSAGE_CONTENT(wordsCount)) wordsCount = MESSAGE_CONTENT(wordsCount);
#pragma clang diagnostic pop

    if (1 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        wordsCount,
        &reply->content.__words[0]);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseIntegerOperatorsMore_OutputEnumMixed_Rpl_ObjRefs;

    return (ret);
}



