/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCasePortAliasMore.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCasePortAliasMore.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCasePortAliasMore.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCasePortAliasMore_SendPlain_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCasePortAliasMore_SendPlain_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t port__descriptor;
};
struct IIGVerifyCasePortAliasMore_SendPlain_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t port__descriptor;
    IIGVerifyCasePortAliasMore_SendPlain_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePortAliasMore_SendPlain_Msg_ObjRefs (1)

struct IIGVerifyCasePortAliasMore_SendPlain_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePortAliasMore_SendPlain_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePortAliasMore_SendPlain_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePortAliasMore_SendPlain_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePortAliasMore_SendPlain_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePortAliasMore_SendPlain_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePortAliasMore_SendPlain_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePortAliasMore_SendPlain_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePortAliasMore_SendPlain_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePortAliasMore_SendPlain_Invocation;
struct IIGVerifyCasePortAliasMore_SendAlias_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
};
#pragma pack(4)
struct IIGVerifyCasePortAliasMore_SendAlias_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t port__descriptor;
};
struct IIGVerifyCasePortAliasMore_SendAlias_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t port__descriptor;
    IIGVerifyCasePortAliasMore_SendAlias_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCasePortAliasMore_SendAlias_Msg_ObjRefs (1)

struct IIGVerifyCasePortAliasMore_SendAlias_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCasePortAliasMore_SendAlias_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCasePortAliasMore_SendAlias_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCasePortAliasMore_SendAlias_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCasePortAliasMore_SendAlias_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCasePortAliasMore_SendAlias_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCasePortAliasMore_SendAlias_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCasePortAliasMore_SendAlias_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCasePortAliasMore_SendAlias_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCasePortAliasMore_SendAlias_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCasePortAliasMore_QueueNames  ""

#define IIGVerifyCasePortAliasMore_MethodNames  ""

#define IIGVerifyCasePortAliasMoreMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCasePortAliasMore_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCasePortAliasMore_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCasePortAliasMore_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCasePortAliasMoreMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCasePortAliasMore_t
OSClassDescription_IIGVerifyCasePortAliasMore =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCasePortAliasMore_t),
        .name                    = "IIGVerifyCasePortAliasMore",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePortAliasMore_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePortAliasMore_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCasePortAliasMore_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePortAliasMore_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCasePortAliasMore_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePortAliasMore_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCasePortAliasMoreMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCasePortAliasMore_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCasePortAliasMore_QueueNames,
    .methodNames     = IIGVerifyCasePortAliasMore_MethodNames,
    .metaMethodNames = IIGVerifyCasePortAliasMoreMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCasePortAliasMoreMetaClass;

static kern_return_t
IIGVerifyCasePortAliasMore_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCasePortAliasMore_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCasePortAliasMore.base,
    .metaPointer       = &gIIGVerifyCasePortAliasMoreMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCasePortAliasMore),

    .resv2             = {0},

    .New               = &IIGVerifyCasePortAliasMore_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCasePortAliasMore_Declaration;
const void * const
gIIGVerifyCasePortAliasMore_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCasePortAliasMore_Class;

static kern_return_t
IIGVerifyCasePortAliasMore_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCasePortAliasMoreMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCasePortAliasMoreMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCasePortAliasMore) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCasePortAliasMore::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCasePortAliasMore::_Dispatch(IIGVerifyCasePortAliasMore * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCasePortAliasMore_SendPlain_ID:
        {
            ret = IIGVerifyCasePortAliasMore::SendPlain_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePortAliasMore::SendPlain_Handler, *self, &IIGVerifyCasePortAliasMore::SendPlain_Impl));
            break;
        }
        case IIGVerifyCasePortAliasMore_SendAlias_ID:
        {
            ret = IIGVerifyCasePortAliasMore::SendAlias_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCasePortAliasMore::SendAlias_Handler, *self, &IIGVerifyCasePortAliasMore::SendAlias_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCasePortAliasMore::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCasePortAliasMoreMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCasePortAliasMore::SendPlain(
        mach_port_t port,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePortAliasMore_SendPlain_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePortAliasMore_SendPlain_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePortAliasMore_SendPlain_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePortAliasMore_SendPlain_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePortAliasMore_SendPlain_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePortAliasMore_SendPlain_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->port__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->port__descriptor.disposition = MACH_MSG_TYPE_COPY_SEND;
    msg->port__descriptor.name = port;
#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePortAliasMore_SendPlain_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePortAliasMore_SendPlain_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePortAliasMore::SendAlias(
        IIGVerifyAliasPort port,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCasePortAliasMore_SendAlias_Msg_With_Content msg;
        struct
        {
            IIGVerifyCasePortAliasMore_SendAlias_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCasePortAliasMore_SendAlias_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCasePortAliasMore_SendAlias_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCasePortAliasMore_SendAlias_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCasePortAliasMore_SendAlias_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 2;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->port__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;
    msg->port__descriptor.disposition = MACH_MSG_TYPE_COPY_SEND;
    msg->port__descriptor.name = port;
#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCasePortAliasMore_SendAlias_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCasePortAliasMore_SendAlias_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCasePortAliasMore::SendPlain_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SendPlain_Handler func)
{
    IIGVerifyCasePortAliasMore_SendPlain_Invocation rpc = { _rpc };
    IIGVerifyCasePortAliasMore_SendPlain_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePortAliasMore_SendPlain_Msg *         message = rpc.message;
    const IIGVerifyCasePortAliasMore_SendPlain_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePortAliasMore_SendPlain_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePortAliasMore_SendPlain_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePortAliasMore_SendPlain_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        message->port__descriptor.name);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePortAliasMore_SendPlain_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePortAliasMore_SendPlain_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCasePortAliasMore::SendAlias_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        SendAlias_Handler func)
{
    IIGVerifyCasePortAliasMore_SendAlias_Invocation rpc = { _rpc };
    IIGVerifyCasePortAliasMore_SendAlias_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCasePortAliasMore_SendAlias_Msg *         message = rpc.message;
    const IIGVerifyCasePortAliasMore_SendAlias_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCasePortAliasMore_SendAlias_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;

    if (2 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCasePortAliasMore_SendAlias_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCasePortAliasMore_SendAlias_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);

    ret = (*func)(target,
        message->port__descriptor.name);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCasePortAliasMore_SendAlias_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCasePortAliasMore_SendAlias_Rpl_ObjRefs;

    return (ret);
}



