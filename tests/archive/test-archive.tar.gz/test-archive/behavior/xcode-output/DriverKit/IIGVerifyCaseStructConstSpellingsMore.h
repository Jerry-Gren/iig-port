/* iig(DriverKit-440) generated from IIGVerifyCaseStructConstSpellingsMore.iig */

/* IIGVerifyCaseStructConstSpellingsMore.iig:1-13 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASESTRUCTCONSTSPELLINGSMORE_H
#define _DRIVERKIT_IIGVerifyCASESTRUCTCONSTSPELLINGSMORE_H

struct IIGVerifyConstStructMore {
	uint64_t value;
};

typedef IIGVerifyConstStructMore IIGVerifyAliasStructMore;
typedef IIGVerifyConstStructMore * IIGVerifyAliasStructPointerMore;
typedef const IIGVerifyConstStructMore * IIGVerifyAliasConstStructPointerMore;

/* source class IIGVerifyCaseStructConstSpellingsMore IIGVerifyCaseStructConstSpellingsMore.iig:14-36 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseStructConstSpellingsMore : public OSObject
{
public:
	virtual kern_return_t
	LeadingConst(const IIGVerifyConstStructMore * value) LOCAL;

	virtual kern_return_t
	TrailingConst(IIGVerifyConstStructMore const * value) LOCAL;

	virtual kern_return_t
	AliasLeadingConst(const IIGVerifyAliasStructMore * value) LOCAL;

	virtual kern_return_t
	AliasTrailingConst(IIGVerifyAliasStructMore const * value) LOCAL;

	virtual kern_return_t
	TopLevelConst(IIGVerifyAliasStructPointerMore const value) LOCAL;

	virtual kern_return_t
	LeadingTopLevelConst(const IIGVerifyAliasStructPointerMore value) LOCAL;

	virtual kern_return_t
	HiddenPointeeConst(IIGVerifyAliasConstStructPointerMore value) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseStructConstSpellingsMore IIGVerifyCaseStructConstSpellingsMore.iig:14-36 */

#define IIGVerifyCaseStructConstSpellingsMore_LeadingConst_ID            0xeae31921b16967c1ULL
#define IIGVerifyCaseStructConstSpellingsMore_TrailingConst_ID            0xb349a55834b49443ULL
#define IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_ID            0xcb2a7fd2200ce086ULL
#define IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_ID            0xd5ca413594d31740ULL
#define IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_ID            0xcac0e2bac84d69bcULL
#define IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_ID            0x9b9fc037f7f6c57bULL
#define IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_ID            0xf4106b8d00c4baa6ULL

#define IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Args \
        const IIGVerifyConstStructMore * value

#define IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Args \
        const IIGVerifyConstStructMore * value

#define IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Args \
        const IIGVerifyAliasStructMore * value

#define IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Args \
        const IIGVerifyAliasStructMore * value

#define IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Args \
        const IIGVerifyAliasStructPointerMore value

#define IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Args \
        const IIGVerifyAliasStructPointerMore value

#define IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Args \
        IIGVerifyAliasConstStructPointerMore value

#define IIGVerifyCaseStructConstSpellingsMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseStructConstSpellingsMore * self, const IORPC rpc);\
\
    kern_return_t\
    LeadingConst(\
        const IIGVerifyConstStructMore * value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TrailingConst(\
        const IIGVerifyConstStructMore * value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasLeadingConst(\
        const IIGVerifyAliasStructMore * value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    AliasTrailingConst(\
        const IIGVerifyAliasStructMore * value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    TopLevelConst(\
        const IIGVerifyAliasStructPointerMore value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    LeadingTopLevelConst(\
        const IIGVerifyAliasStructPointerMore value,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    HiddenPointeeConst(\
        IIGVerifyAliasConstStructPointerMore value,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    LeadingConst_Impl(IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Args);\
\
    kern_return_t\
    TrailingConst_Impl(IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Args);\
\
    kern_return_t\
    AliasLeadingConst_Impl(IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Args);\
\
    kern_return_t\
    AliasTrailingConst_Impl(IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Args);\
\
    kern_return_t\
    TopLevelConst_Impl(IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Args);\
\
    kern_return_t\
    LeadingTopLevelConst_Impl(IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Args);\
\
    kern_return_t\
    HiddenPointeeConst_Impl(IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*LeadingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_LeadingConst_Args);\
    static kern_return_t\
    LeadingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        LeadingConst_Handler func);\
\
    typedef kern_return_t (*TrailingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_TrailingConst_Args);\
    static kern_return_t\
    TrailingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TrailingConst_Handler func);\
\
    typedef kern_return_t (*AliasLeadingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_AliasLeadingConst_Args);\
    static kern_return_t\
    AliasLeadingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasLeadingConst_Handler func);\
\
    typedef kern_return_t (*AliasTrailingConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_AliasTrailingConst_Args);\
    static kern_return_t\
    AliasTrailingConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        AliasTrailingConst_Handler func);\
\
    typedef kern_return_t (*TopLevelConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_TopLevelConst_Args);\
    static kern_return_t\
    TopLevelConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        TopLevelConst_Handler func);\
\
    typedef kern_return_t (*LeadingTopLevelConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_LeadingTopLevelConst_Args);\
    static kern_return_t\
    LeadingTopLevelConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        LeadingTopLevelConst_Handler func);\
\
    typedef kern_return_t (*HiddenPointeeConst_Handler)(OSMetaClassBase * target, IIGVerifyCaseStructConstSpellingsMore_HiddenPointeeConst_Args);\
    static kern_return_t\
    HiddenPointeeConst_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        HiddenPointeeConst_Handler func);\
\


#define IIGVerifyCaseStructConstSpellingsMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseStructConstSpellingsMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseStructConstSpellingsMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseStructConstSpellingsMore_Class;

class IIGVerifyCaseStructConstSpellingsMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseStructConstSpellingsMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseStructConstSpellingsMore_IVars;
struct IIGVerifyCaseStructConstSpellingsMore_LocalIVars;

class IIGVerifyCaseStructConstSpellingsMore : public OSObject, public IIGVerifyCaseStructConstSpellingsMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseStructConstSpellingsMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseStructConstSpellingsMore_DECLARE_IVARS
IIGVerifyCaseStructConstSpellingsMore_DECLARE_IVARS
#else /* IIGVerifyCaseStructConstSpellingsMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseStructConstSpellingsMore_IVars * ivars;
        IIGVerifyCaseStructConstSpellingsMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseStructConstSpellingsMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseStructConstSpellingsMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseStructConstSpellingsMore_Methods
    IIGVerifyCaseStructConstSpellingsMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseStructConstSpellingsMore.iig:38- */

#endif /* _DRIVERKIT_IIGVerifyCASESTRUCTCONSTSPELLINGSMORE_H */
