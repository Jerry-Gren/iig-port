/* iig(DriverKit-440) generated from IIGVerifyCaseObjectAliasMore.iig */

/* IIGVerifyCaseObjectAliasMore.iig:1-9 */
#include <DriverKit/OSObject.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEOBJECTALIASMORE_H
#define _DRIVERKIT_IIGVerifyCASEOBJECTALIASMORE_H

typedef OSObject * IIGVerifyAliasObject;
typedef OSObject ** IIGVerifyAliasObjectOut;
typedef OSObject * IIGVerifyAliasObjectArray[3];

/* source class IIGVerifyCaseObjectAliasMore IIGVerifyCaseObjectAliasMore.iig:10-21 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseObjectAliasMore : public OSObject
{
public:
	virtual kern_return_t
	InputAlias(IIGVerifyAliasObject object) LOCAL;

	virtual kern_return_t
	OutputAlias(IIGVerifyAliasObjectOut object) LOCAL;

	virtual kern_return_t
	ArrayAlias(IIGVerifyAliasObjectArray objects,
	    uint32_t objectsCount) LOCAL;
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseObjectAliasMore IIGVerifyCaseObjectAliasMore.iig:10-21 */

#define IIGVerifyCaseObjectAliasMore_InputAlias_ID            0xeb41c45510aa5308ULL
#define IIGVerifyCaseObjectAliasMore_OutputAlias_ID            0xa0a8310431173f1eULL
#define IIGVerifyCaseObjectAliasMore_ArrayAlias_ID            0xb89e2832bc9ece7cULL

#define IIGVerifyCaseObjectAliasMore_InputAlias_Args \
        IIGVerifyAliasObject object

#define IIGVerifyCaseObjectAliasMore_OutputAlias_Args \
        IIGVerifyAliasObjectOut object

#define IIGVerifyCaseObjectAliasMore_ArrayAlias_Args \
        OSObject ** objects, \
        uint32_t objectsCount

#define IIGVerifyCaseObjectAliasMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseObjectAliasMore * self, const IORPC rpc);\
\
    kern_return_t\
    InputAlias(\
        IIGVerifyAliasObject object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    OutputAlias(\
        IIGVerifyAliasObjectOut object,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    ArrayAlias(\
        OSObject ** objects,\
        uint32_t objectsCount,\
        OSDispatchMethod supermethod = NULL);\
\
\
protected:\
    /* _Impl methods */\
\
    kern_return_t\
    InputAlias_Impl(IIGVerifyCaseObjectAliasMore_InputAlias_Args);\
\
    kern_return_t\
    OutputAlias_Impl(IIGVerifyCaseObjectAliasMore_OutputAlias_Args);\
\
    kern_return_t\
    ArrayAlias_Impl(IIGVerifyCaseObjectAliasMore_ArrayAlias_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef kern_return_t (*InputAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectAliasMore_InputAlias_Args);\
    static kern_return_t\
    InputAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        InputAlias_Handler func);\
\
    typedef kern_return_t (*OutputAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectAliasMore_OutputAlias_Args);\
    static kern_return_t\
    OutputAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        OutputAlias_Handler func);\
\
    typedef kern_return_t (*ArrayAlias_Handler)(OSMetaClassBase * target, IIGVerifyCaseObjectAliasMore_ArrayAlias_Args);\
    static kern_return_t\
    ArrayAlias_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        ArrayAlias_Handler func);\
\


#define IIGVerifyCaseObjectAliasMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define IIGVerifyCaseObjectAliasMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseObjectAliasMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseObjectAliasMore_Class;

class IIGVerifyCaseObjectAliasMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseObjectAliasMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseObjectAliasMore_IVars;
struct IIGVerifyCaseObjectAliasMore_LocalIVars;

class IIGVerifyCaseObjectAliasMore : public OSObject, public IIGVerifyCaseObjectAliasMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseObjectAliasMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseObjectAliasMore_DECLARE_IVARS
IIGVerifyCaseObjectAliasMore_DECLARE_IVARS
#else /* IIGVerifyCaseObjectAliasMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseObjectAliasMore_IVars * ivars;
        IIGVerifyCaseObjectAliasMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseObjectAliasMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseObjectAliasMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseObjectAliasMore_Methods
    IIGVerifyCaseObjectAliasMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseObjectAliasMore.iig:23- */

#endif /* _DRIVERKIT_IIGVerifyCASEOBJECTALIASMORE_H */
