/* iig(DriverKit-440) generated from IIGVerifyCaseActionQueuesMore.iig */

/* IIGVerifyCaseActionQueuesMore.iig:1-8 */
#include <DriverKit/OSAction.h>  /* .iig include */

#ifndef _DRIVERKIT_IIGVerifyCASEACTIONQUEUESMORE_H
#define _DRIVERKIT_IIGVerifyCASEACTIONQUEUESMORE_H

#define kIIGVerifyCaseActionQueueA "IIGVerifyCaseActionQueueA"
#define kIIGVerifyCaseActionQueueB "IIGVerifyCaseActionQueueB"

/* source class IIGVerifyCaseActionQueuesMore IIGVerifyCaseActionQueuesMore.iig:9-24 */

#if __DOCUMENTATION__
#define KERNEL IIG_KERNEL

class KERNEL IIGVerifyCaseActionQueuesMore : public OSObject
{
public:
	virtual void
	CompletionOnQueue(OSAction * action TARGET,
	    uint64_t token) REPLY LOCAL QUEUENAME(kIIGVerifyCaseActionQueueA);

	virtual kern_return_t
	SubmitOnQueue(OSAction * completion TYPE(IIGVerifyCaseActionQueuesMore::CompletionOnQueue),
	    uint64_t token) LOCAL QUEUENAME(kIIGVerifyCaseActionQueueB);

	virtual void
	KernelCompletionOnQueue(OSAction * action TARGET,
	    uint64_t token)
	    KERNEL
	    TYPE(IIGVerifyCaseActionQueuesMore::CompletionOnQueue);
};

#undef KERNEL
#else /* __DOCUMENTATION__ */

/* generated class IIGVerifyCaseActionQueuesMore IIGVerifyCaseActionQueuesMore.iig:9-24 */

#define IIGVerifyCaseActionQueuesMore_CompletionOnQueue_ID            0xa149cb132a5c655bULL
#define IIGVerifyCaseActionQueuesMore_SubmitOnQueue_ID            0xe07aba63a1569872ULL
#define IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_ID            0xde29aad43f09fdb7ULL

#define IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Args \
        OSAction * completion, \
        uint64_t token

#define IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Args \
        OSAction * action, \
        uint64_t token

#define IIGVerifyCaseActionQueuesMore_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(IIGVerifyCaseActionQueuesMore * self, const IORPC rpc);\
\
    kern_return_t\
    CompletionOnQueue(\
        IORPC rpc,\
        OSAction * action,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    SubmitOnQueue(\
        OSAction * completion,\
        uint64_t token,\
        OSDispatchMethod supermethod = NULL);\
\
    kern_return_t\
    CreateActionKernelCompletionOnQueue(size_t referenceSize, OSAction ** action);\
\
\
protected:\
    /* _Impl methods */\
\
    void\
    CompletionOnQueue_Impl(IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Args);\
\
    kern_return_t\
    SubmitOnQueue_Impl(IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Args);\
\
\
public:\
    /* _Invoke methods */\
\
    typedef void (*CompletionOnQueue_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionQueuesMore_CompletionOnQueue_Args);\
    static kern_return_t\
    CompletionOnQueue_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionOnQueue_Handler func,\
        const OSMetaClass * targetActionClass);\
\
    static kern_return_t\
    CompletionOnQueue_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        CompletionOnQueue_Handler func);\
\
    typedef kern_return_t (*SubmitOnQueue_Handler)(OSMetaClassBase * target, IIGVerifyCaseActionQueuesMore_SubmitOnQueue_Args);\
    static kern_return_t\
    SubmitOnQueue_Invoke(const IORPC rpc,\
        OSMetaClassBase * target,\
        SubmitOnQueue_Handler func);\
\


#define IIGVerifyCaseActionQueuesMore_KernelMethods \
\
protected:\
    /* _Impl methods */\
\
    void\
    KernelCompletionOnQueue_Impl(IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Args);\
\


#define IIGVerifyCaseActionQueuesMore_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gIIGVerifyCaseActionQueuesMoreMetaClass;
extern const OSClassLoadInformation IIGVerifyCaseActionQueuesMore_Class;

class IIGVerifyCaseActionQueuesMoreMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

#if !KERNEL

class  IIGVerifyCaseActionQueuesMoreInterface : public OSInterface
{
public:
};

struct IIGVerifyCaseActionQueuesMore_IVars;
struct IIGVerifyCaseActionQueuesMore_LocalIVars;

class IIGVerifyCaseActionQueuesMore : public OSObject, public IIGVerifyCaseActionQueuesMoreInterface
{
#if !KERNEL
    friend class IIGVerifyCaseActionQueuesMoreMetaClass;
#endif /* !KERNEL */

#if !KERNEL
public:
#ifdef IIGVerifyCaseActionQueuesMore_DECLARE_IVARS
IIGVerifyCaseActionQueuesMore_DECLARE_IVARS
#else /* IIGVerifyCaseActionQueuesMore_DECLARE_IVARS */
    union
    {
        IIGVerifyCaseActionQueuesMore_IVars * ivars;
        IIGVerifyCaseActionQueuesMore_LocalIVars * lvars;
    };
#endif /* IIGVerifyCaseActionQueuesMore_DECLARE_IVARS */
#endif /* !KERNEL */

#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gIIGVerifyCaseActionQueuesMoreMetaClass; };
#endif /* KERNEL */

    using super = OSObject;

#if !KERNEL
    IIGVerifyCaseActionQueuesMore_Methods
    IIGVerifyCaseActionQueuesMore_VirtualMethods
#endif /* !KERNEL */

};
#endif /* !KERNEL */


#define OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Methods \
\
public:\
\
    virtual kern_return_t\
    Dispatch(const IORPC rpc) APPLE_KEXT_OVERRIDE;\
\
    static kern_return_t\
    _Dispatch(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue * self, const IORPC rpc);\
\
\
protected:\
    /* _Impl methods */\
\
\
public:\
    /* _Invoke methods */\
\


#define OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_KernelMethods \
\
protected:\
    /* _Impl methods */\
\


#define OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_VirtualMethods \
\
public:\
\


#if !KERNEL

extern OSMetaClass          * gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass;
extern const OSClassLoadInformation OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Class;

class OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass : public OSMetaClass
{
public:
    virtual kern_return_t
    New(OSObject * instance) override;
    virtual kern_return_t
    Dispatch(const IORPC rpc) override;
};

#endif /* !KERNEL */

class  __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueInterface : public OSInterface
{
public:
};

struct OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_IVars;
struct OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_LocalIVars;

class __attribute__((availability(driverkit,introduced=20,message="Type-safe OSAction factory methods are available in DriverKit 20 and newer"))) OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue : public OSAction, public OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueInterface
{
#if KERNEL
    OSDeclareDefaultStructorsWithDispatch(OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue);
#endif /* KERNEL */

#if !KERNEL
    friend class OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass;
#endif /* !KERNEL */

public:
#ifdef OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_DECLARE_IVARS
OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_DECLARE_IVARS
#else /* OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_DECLARE_IVARS */
    union
    {
        OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_IVars * ivars;
        OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_LocalIVars * lvars;
    };
#endif /* OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_DECLARE_IVARS */
#if !KERNEL
    static OSMetaClass *
    sGetMetaClass() { return gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass; };
    virtual const OSMetaClass *
    getMetaClass() const APPLE_KEXT_OVERRIDE { return gOSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueueMetaClass; };
#endif /* KERNEL */

    using super = OSAction;

#if !KERNEL
    OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_Methods
#endif /* !KERNEL */

    OSAction_IIGVerifyCaseActionQueuesMore_KernelCompletionOnQueue_VirtualMethods
};

#endif /* !__DOCUMENTATION__ */

/* IIGVerifyCaseActionQueuesMore.iig:26- */

#endif /* _DRIVERKIT_IIGVerifyCASEACTIONQUEUESMORE_H */
