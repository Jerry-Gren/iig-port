/* iig(DriverKit-440 Jan  9 2026 10:49:41) generated from IIGVerifyCaseStaticArrays.iig */

#undef	IIG_IMPLEMENTATION
#define	IIG_IMPLEMENTATION 	IIGVerifyCaseStaticArrays.iig

#if KERNEL
#include <libkern/c++/OSString.h>
#else
#include <DriverKit/DriverKit.h>
#endif /* KERNEL */
#include <DriverKit/IOReturn.h>
#include <DriverKit/IIGVerifyCaseStaticArrays.h>


#if __has_builtin(__builtin_load_member_function_pointer)
#define SimpleMemberFunctionCast(cfnty, self, func) (cfnty)__builtin_load_member_function_pointer(self, func)
#else
#define SimpleMemberFunctionCast(cfnty, self, func) ({ union { typeof(func) memfun; cfnty cfun; } pair; pair.memfun = func; pair.cfun; })
#endif


struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[4];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[4];
};
struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[4];
    IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_ObjRefs (5)

struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Invocation;
struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __descriptors[3];
    uint32_t  descriptorsCount;
};
#pragma pack(4)
struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t descriptors__descriptor[3];
};
struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t descriptors__descriptor[3];
    IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_ObjRefs (4)

struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_Content
{
    IORPCMessage __hdr;
    OSObjectRef  memory;
};
#pragma pack(4)
struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t memory__descriptor;
};
struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t memory__descriptor;
    IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_ObjRefs (1)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Invocation;
struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_Content
{
    IORPCMessage __hdr;
    OSObjectRef  __object;
    OSObjectRef __objects[2];
    uint32_t  objectsCount;
};
#pragma pack(4)
struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[2];
};
struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_With_Content
{
    IORPCMessageMach           mach;
    mach_msg_port_descriptor_t __object__descriptor;
    mach_msg_port_descriptor_t objects__descriptor[2];
    IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_ObjRefs (3)

struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_Content
{
    IORPCMessage __hdr;
};
#pragma pack(4)
struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl
{
    IORPCMessageMach           mach;
};
struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_With_Content
{
    IORPCMessageMach           mach;
    IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_Content content;
};
#pragma pack()
#define IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_ObjRefs (0)


typedef union
{
    const IORPC rpc;
    struct
    {
#ifdef KERNEL
        const struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg * message;
#else /* KERNEL */
        const struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_With_Content * message;
#endif /* KERNEL */
        struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_With_Content       * reply;
        uint32_t sendSize;
        uint32_t replySize;
#ifdef KERNEL
        const struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_Content * kernelContent;
#endif /* KERNEL */
    };
} IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Invocation;
#if !KERNEL
extern OSMetaClass * gOSContainerMetaClass;
extern OSMetaClass * gOSDataMetaClass;
extern OSMetaClass * gOSNumberMetaClass;
extern OSMetaClass * gOSStringMetaClass;
extern OSMetaClass * gOSBooleanMetaClass;
extern OSMetaClass * gOSDictionaryMetaClass;
extern OSMetaClass * gOSArrayMetaClass;
extern OSMetaClass * gOSSetMetaClass;
extern OSMetaClass * gOSOrderedSetMetaClass;
extern OSMetaClass * gIODispatchQueueMetaClass;
extern OSMetaClass * gIOServiceMetaClass;
extern OSMetaClass * gIOMemoryMapMetaClass;
#endif /* !KERNEL */

#if !KERNEL

#define IIGVerifyCaseStaticArrays_QueueNames  ""

#define IIGVerifyCaseStaticArrays_MethodNames  ""

#define IIGVerifyCaseStaticArraysMetaClass_MethodNames  ""

struct OSClassDescription_IIGVerifyCaseStaticArrays_t
{
    OSClassDescription base;
    uint64_t           methodOptions[2 * 0];
    uint64_t           metaMethodOptions[2 * 0];
    char               queueNames[sizeof(IIGVerifyCaseStaticArrays_QueueNames)];
    char               methodNames[sizeof(IIGVerifyCaseStaticArrays_MethodNames)];
    char               metaMethodNames[sizeof(IIGVerifyCaseStaticArraysMetaClass_MethodNames)];
};

const struct OSClassDescription_IIGVerifyCaseStaticArrays_t
OSClassDescription_IIGVerifyCaseStaticArrays =
{
    .base =
    {
        .descriptionSize         = sizeof(OSClassDescription_IIGVerifyCaseStaticArrays_t),
        .name                    = "IIGVerifyCaseStaticArrays",
        .superName               = "OSObject",
        .methodOptionsSize       = 2 * sizeof(uint64_t) * 0,
        .methodOptionsOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticArrays_t, methodOptions),
        .metaMethodOptionsSize   = 2 * sizeof(uint64_t) * 0,
        .metaMethodOptionsOffset = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticArrays_t, metaMethodOptions),
        .queueNamesSize       = sizeof(IIGVerifyCaseStaticArrays_QueueNames),
        .queueNamesOffset     = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticArrays_t, queueNames),
        .methodNamesSize         = sizeof(IIGVerifyCaseStaticArrays_MethodNames),
        .methodNamesOffset       = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticArrays_t, methodNames),
        .metaMethodNamesSize     = sizeof(IIGVerifyCaseStaticArraysMetaClass_MethodNames),
        .metaMethodNamesOffset   = __builtin_offsetof(struct OSClassDescription_IIGVerifyCaseStaticArrays_t, metaMethodNames),
        .flags                   = 1*kOSClassCanRemote,
        .resv1                   = {0},
    },
    .methodOptions =
    {
    },
    .metaMethodOptions =
    {
    },
    .queueNames      = IIGVerifyCaseStaticArrays_QueueNames,
    .methodNames     = IIGVerifyCaseStaticArrays_MethodNames,
    .metaMethodNames = IIGVerifyCaseStaticArraysMetaClass_MethodNames,
};

OSMetaClass * gIIGVerifyCaseStaticArraysMetaClass;

static kern_return_t
IIGVerifyCaseStaticArrays_New(OSMetaClass * instance);

const OSClassLoadInformation
IIGVerifyCaseStaticArrays_Class = 
{
    .description       = &OSClassDescription_IIGVerifyCaseStaticArrays.base,
    .metaPointer       = &gIIGVerifyCaseStaticArraysMetaClass,
    .version           = 1,
    .instanceSize      = sizeof(IIGVerifyCaseStaticArrays),

    .resv2             = {0},

    .New               = &IIGVerifyCaseStaticArrays_New,
    .resv3             = {0},

};

extern const void * const
gIIGVerifyCaseStaticArrays_Declaration;
const void * const
gIIGVerifyCaseStaticArrays_Declaration
__attribute__((used,visibility("hidden"),section("__DATA_CONST,__osclassinfo,regular,no_dead_strip"),no_sanitize("address")))
    = &IIGVerifyCaseStaticArrays_Class;

static kern_return_t
IIGVerifyCaseStaticArrays_New(OSMetaClass * instance)
{
    if (!new(instance) IIGVerifyCaseStaticArraysMetaClass) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

kern_return_t
IIGVerifyCaseStaticArraysMetaClass::New(OSObject * instance)
{
    if (!new(instance) IIGVerifyCaseStaticArrays) return (kIOReturnNoMemory);
    return (kIOReturnSuccess);
}

#endif /* !KERNEL */

#ifdef KERNEL
#define MESSAGE_CONTENT(__field) (messageContent->__field)
#else /* KERNEL */
#define MESSAGE_CONTENT(__field) (message->content.__field)
#endif /* KERNEL */

kern_return_t
IIGVerifyCaseStaticArrays::Dispatch(const IORPC rpc)
{
    return _Dispatch(this, rpc);
}

kern_return_t
IIGVerifyCaseStaticArrays::_Dispatch(IIGVerifyCaseStaticArrays * self, const IORPC rpc)
{
    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
        case IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_ID:
        {
            ret = IIGVerifyCaseStaticArrays::InstanceObjectCountBefore_Invoke(rpc, self, SimpleMemberFunctionCast(IIGVerifyCaseStaticArrays::InstanceObjectCountBefore_Handler, *self, &IIGVerifyCaseStaticArrays::InstanceObjectCountBefore_Impl));
            break;
        }

        default:
            ret = OSObject::_Dispatch(self, rpc);
            break;
    }

    return (ret);
}

#if KERNEL
kern_return_t
IIGVerifyCaseStaticArrays::MetaClass::Dispatch(const IORPC rpc)
{
#else /* KERNEL */
kern_return_t
IIGVerifyCaseStaticArraysMetaClass::Dispatch(const IORPC rpc)
{
#endif /* !KERNEL */

    kern_return_t ret = kIOReturnUnsupported;
#ifdef KERNEL
    IORPCMessage * msg = rpc.kernelContent;
#else /* KERNEL */
    IORPCMessage * msg = IORPCMessageFromMach(rpc.message, false);
#endif /* KERNEL */

    switch (msg->msgid)
    {
#if KERNEL
        case IIGVerifyCaseStaticArrays_StaticObjectCountBefore_ID:
            ret = IIGVerifyCaseStaticArrays::StaticObjectCountBefore_Invoke(rpc, &IIGVerifyCaseStaticArrays::StaticObjectCountBefore_Impl);
            break;
#endif /* !KERNEL */
#if KERNEL
        case IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_ID:
            ret = IIGVerifyCaseStaticArrays::StaticDescriptorCountAfter_Invoke(rpc, &IIGVerifyCaseStaticArrays::StaticDescriptorCountAfter_Impl);
            break;
#endif /* !KERNEL */

        default:
            ret = OSMetaClassBase::Dispatch(rpc);
            break;
    }

    return (ret);
}

kern_return_t
IIGVerifyCaseStaticArrays::StaticObjectCountBefore_Call(
        uint32_t objectsCount,
        OSObject ** const objects)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticArrays_StaticObjectCountBefore_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseStaticArrays);
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 5;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.objectsCount = objectsCount;

    for (unsigned int idx = 0; idx < 4; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseStaticArrays)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStaticArrays_StaticObjectCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStaticArrays::StaticDescriptorCountAfter_Call(
        IOMemoryDescriptor ** const descriptors,
        uint32_t descriptorsCount,
        IOMemoryDescriptor ** memory)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 0*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_ID;
    msg->content.__object = (OSObjectRef) OSTypeID(IIGVerifyCaseStaticArrays);
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 4;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    for (unsigned int idx = 0; idx < 3; idx++) msg->descriptors__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (descriptorsCount > (sizeof(msg->content.__descriptors) / sizeof(msg->content.__descriptors[0]))) return kIOReturnOverrun;
    bcopy(descriptors, &msg->content.__descriptors[0], descriptorsCount * sizeof(msg->content.__descriptors[0]));

    msg->content.descriptorsCount = descriptorsCount;

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    ret = OSMTypeID(IIGVerifyCaseStaticArrays)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 1) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
        *memory = OSDynamicCast(IOMemoryDescriptor, (OSObject *) rpl->content.memory);
        if (rpl->content.memory && !*memory) ret = kIOReturnBadArgument;
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStaticArrays::InstanceObjectCountBefore(
        uint32_t objectsCount,
        IOBufferMemoryDescriptor ** const objects,
        OSDispatchMethod supermethod)
{
    kern_return_t ret;
    union
    {
        IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_With_Content msg;
        struct
        {
            IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_With_Content rpl;
            mach_msg_max_trailer_t trailer;
        } rpl;
    } buf;
    struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_With_Content * msg = &buf.msg;
    struct IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_With_Content * rpl = &buf.rpl.rpl;

    memset(msg, 0, sizeof(*msg));
    msg->mach.msgh.msgh_id   = kIORPCVersion190615;
    msg->mach.msgh.msgh_size = sizeof(*msg);
    msg->content.__hdr.flags = 0*kIORPCMessageOneway
                             | 1*kIORPCMessageSimpleReply
                             | 0*kIORPCMessageLocalHost
                             | 0*kIORPCMessageOnqueue;
    msg->content.__hdr.msgid = IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_ID;
    msg->content.__object = (OSObjectRef) this;
    msg->content.__hdr.objectRefs = IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_ObjRefs;
    msg->mach.msgh_body.msgh_descriptor_count = 3;

    msg->__object__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    msg->content.objectsCount = objectsCount;

    for (unsigned int idx = 0; idx < 2; idx++) msg->objects__descriptor[idx].type = MACH_MSG_PORT_DESCRIPTOR;
    if (objectsCount > (sizeof(msg->content.__objects) / sizeof(msg->content.__objects[0]))) return kIOReturnOverrun;
    bcopy(objects, &msg->content.__objects[0], objectsCount * sizeof(msg->content.__objects[0]));

#ifdef KERNEL
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl), .kernelContent = &buf.msg.content.__hdr };
#else /* KERNEL */
    IORPC rpc = { .message = &buf.msg.mach, .reply = &buf.rpl.rpl.mach, .sendSize = sizeof(buf.msg), .replySize = sizeof(buf.rpl) };
#endif /* KERNEL */
    if (supermethod) ret = supermethod((OSObject *)this, rpc);
    else             ret = ((OSObject *)this)->Invoke(rpc);

    if (kIOReturnSuccess == ret)
    do {
        {
            if (rpl->mach.msgh.msgh_size                  != sizeof(*rpl)) { ret = kIOReturnIPCError; break; };
            if (rpl->content.__hdr.msgid                  != IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_ID) { ret = kIOReturnIPCError; break; };
            if (rpl->mach.msgh_body.msgh_descriptor_count != 0) { ret = kIOReturnIPCError; break; };
            if (IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_ObjRefs   != rpl->content.__hdr.objectRefs) { ret = kIOReturnIPCError; break; };
        }
    }
    while (false);
    if (kIOReturnSuccess == ret)
    {
    }


    return (ret);
}

kern_return_t
IIGVerifyCaseStaticArrays::StaticObjectCountBefore_Invoke(const IORPC _rpc,
        StaticObjectCountBefore_Handler func)
{
    IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop
#if !__LP64__
    OSObject * objects[4] = {};
#else /* !__LP64__ */
    OSObject ** objects;
#endif /* __LP64__ */

    if (5 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (OSObject *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (OSObject **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(OSObject, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(        objectsCount,
        objects);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStaticArrays_StaticObjectCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStaticArrays_StaticObjectCountBefore_Rpl_ObjRefs;

    return (ret);
}

kern_return_t
IIGVerifyCaseStaticArrays::StaticDescriptorCountAfter_Invoke(const IORPC _rpc,
        StaticDescriptorCountAfter_Handler func)
{
    IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
#if !__LP64__
    IOMemoryDescriptor * descriptors[3] = {};
#else /* !__LP64__ */
    IOMemoryDescriptor ** descriptors;
#endif /* __LP64__ */
    uint32_t descriptorsCount = (sizeof(MESSAGE_CONTENT(__descriptors)) / sizeof(MESSAGE_CONTENT(__descriptors[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(descriptorsCount) >= 0 && descriptorsCount > MESSAGE_CONTENT(descriptorsCount)) descriptorsCount = MESSAGE_CONTENT(descriptorsCount);
#pragma clang diagnostic pop

    if (4 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < descriptorsCount; idx++)
    {
        descriptors[idx] = (IOMemoryDescriptor *)(uintptr_t)MESSAGE_CONTENT(__descriptors[idx]);
    }
#else /* !__LP64__ */
    descriptors = (IOMemoryDescriptor **)(uintptr_t) &MESSAGE_CONTENT(__descriptors[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < descriptorsCount; idx++)
    {
        if (descriptors[idx] && !OSDynamicCast(IOMemoryDescriptor, descriptors[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(        descriptors,
        descriptorsCount,
        (IOMemoryDescriptor **)&reply->content.memory);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 1;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStaticArrays_StaticDescriptorCountAfter_Rpl_ObjRefs;
    reply->memory__descriptor.type = MACH_MSG_PORT_DESCRIPTOR;

    return (ret);
}

kern_return_t
IIGVerifyCaseStaticArrays::InstanceObjectCountBefore_Invoke(const IORPC _rpc,
        OSMetaClassBase * target,
        InstanceObjectCountBefore_Handler func)
{
    IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Invocation rpc = { _rpc };
    IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_With_Content * reply = rpc.reply;
#ifdef KERNEL
    const IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg *         message = rpc.message;
    const IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_Content * messageContent = rpc.kernelContent;
#else /* KERNEL */
    const IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_With_Content * message = rpc.message;
#endif /* KERNEL */
#if __has_builtin(__builtin_assume)
    __builtin_assume(reply != NULL);
#endif /* __has_builtin(__builtin_assume) */
    kern_return_t ret;
    uint32_t objectsCount = (sizeof(MESSAGE_CONTENT(__objects)) / sizeof(MESSAGE_CONTENT(__objects[0])));
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wtautological-unsigned-zero-compare"
    if (MESSAGE_CONTENT(objectsCount) >= 0 && objectsCount > MESSAGE_CONTENT(objectsCount)) objectsCount = MESSAGE_CONTENT(objectsCount);
#pragma clang diagnostic pop
#if !__LP64__
    IOBufferMemoryDescriptor * objects[2] = {};
#else /* !__LP64__ */
    IOBufferMemoryDescriptor ** objects;
#endif /* __LP64__ */

    if (3 != message->mach.msgh_body.msgh_descriptor_count) return (kIOReturnIPCError);
    if (IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_ObjRefs != MESSAGE_CONTENT(__hdr.objectRefs)) return (kIOReturnIPCError);
    if (rpc.sendSize < sizeof(IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Msg_With_Content)) return (kIOReturnIPCError);
    if (reply != NULL && rpc.replySize < sizeof(*reply)) return (kIOReturnIPCError);
#if !__LP64__
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        objects[idx] = (IOBufferMemoryDescriptor *)(uintptr_t)MESSAGE_CONTENT(__objects[idx]);
    }
#else /* !__LP64__ */
    objects = (IOBufferMemoryDescriptor **)(uintptr_t) &MESSAGE_CONTENT(__objects[0]);
#endif /* __LP64__ */
    for (unsigned int idx = 0; idx < objectsCount; idx++)
    {
        if (objects[idx] && !OSDynamicCast(IOBufferMemoryDescriptor, objects[idx])) return (kIOReturnBadArgument);
    }

    ret = (*func)(target,
        objectsCount,
        objects);

    if (kIOReturnSuccess != ret) return (ret);

    reply->content.__hdr.msgid = IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_ID;
    reply->content.__hdr.flags = kIORPCMessageOneway;
    reply->mach.msgh.msgh_id   = kIORPCVersion190615Reply;
    reply->mach.msgh.msgh_size = sizeof(*reply);
    reply->mach.msgh_body.msgh_descriptor_count = 0;
    reply->content.__hdr.objectRefs = IIGVerifyCaseStaticArrays_InstanceObjectCountBefore_Rpl_ObjRefs;

    return (ret);
}



